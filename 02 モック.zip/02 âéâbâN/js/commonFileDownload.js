// 以下、変数
/** ファイルダウンロード画面Form */
var objFileDownloadForm = null;
/** ファイルダウンロード画面Span */
var objFileDownloadBox = null;
/** ファイルダウンロード画面Span（隠し） */
var objFileDownloadBoxHidden = null;
/** ファイルダウンロード画面の一覧表で選択されているファイル名の配列 */
var fileDownloadSelectedFileNameArray = null;
/** ファイルダウンロードの実行中 */
var isFileDownloading = false;
// 以下、定数
/** ファイルダウンロード画面のフォーム名 */
var file_download_name_form = "formFileDownload";
/** ファイルダウンロード画面のメッセージ表示欄の名前 */
var file_download_name_span_message = "spanFileDownloadMessage";
/** ファイルダウンロード画面の一覧表テーブルの名前 */
var file_download_name_table_ichiran = "tableFileDownload";
/** ファイルダウンロード画面のエラー色 */
var file_download_color_error = "#FF3030";
/** ファイルダウンロード画面の作成状況名 作成完了 */
var file_download_sakusei_jokyo_mei_sakuseikanryo = "作成済";
/** ファイルダウンロード画面の作成状況名 ダウンロード済み */
var file_download_sakusei_jokyo_mei_downloadzumi = "ダウンロード済";
/** ファイルダウンロード画面の作成状況名 作成中 */
var file_download_sakusei_jokyo_mei_sakuseichu = "作成中";
/** ファイルダウンロード画面の作成状況名 作成中 */
var file_download_sakusei_jokyo_mei_taikichu = "未作成";
/** ファイルダウンロード画面のダウンロード可否 可能 */
var file_download_can_download_true = "1";

/* 以下、ファイルダウンロード画面用 */
/**
 * ファイルダウンロード画面を開く
 */
function openFileDownload() {

	if (objFileDownloadForm != null) {
		// ファイルダウンロード画面が開いている場合、閉じる
		if (objFileDownloadBox != null) {
			objFileDownloadBox.style.display = 'none';
		}
		if (objFileDownloadBoxHidden != null) {
			objFileDownloadBoxHidden.style.display = 'none';
		}
		// 変数をクリア
		objFileDownloadForm = null;
		objFileDownloadBox = null;
		objFileDownloadBoxHidden = null;
	} else {
		// ファイルダウンロード画面が閉じている場合、開く
		// ファイルダウンロード画面のフォーム、spanを取得
		objFileDownloadForm = document.forms[file_download_name_form];
		objFileDownloadBox = document.getElementById("boxFileDownload");
		objFileDownloadBoxHidden = document
				.getElementById("boxFileDownloadHidden");
		if (objFileDownloadForm == null || objFileDownloadBox == null
				|| objFileDownloadBoxHidden == null) {
			// alert("form,Box,BoxHiddenが存在しない");
			return;
		}
		// ファイルダウンロード画面をクリア
		fileDownloadClear();
		// ファイルダウンロード画面を開く
		objFileDownloadBox.style.display = '';
		objFileDownloadBoxHidden.style.display = '';
		// 最新表示を実行する
		fileDownloadNew();
	}

}

/**
 * ファイルダウンロード画面のボタン処理 ダウンロード
 */
function fileDownloadExec() {

	var objFileNameParent = dwrGetFileDownloadForm().elements["hdnDownloadFileName"];
	// チェック
	if (objFileNameParent == null) {
//		alert("ファイル名がない");
		return;
	}

	// 選択しているファイル名を取得、作成状況を「ダウンロード済み」に更新
	var array = fileDownloadGetSelectedFileName(file_download_sakusei_jokyo_mei_downloadzumi);
	var fileNameArray = array[0];
	var fileCountDLButtonOn = array[1];

	// チェック
	if (fileNameArray == null || fileNameArray.length == 0) {
		alert("ファイルを選択してください。");
		return;
	}

	// ファイル名を主画面の隠しフィールドにセット
	// カンマ区切りの文字列となる
	objFileNameParent.value = fileNameArray;

	// 対象のファイルがなくなった場合には、
	// 主画面のダウンロード画面へボタンをOFF状態にし、ファイル有りのメッセージをクリアする
	if (fileCountDLButtonOn <= 0) {
		var objDLButtonParent = dwrGetFileDownloadForm().elements["downloadOpenButton"];
		// alert("fileCountDLButtonOn="+fileCountDLButtonOn+ ",
		// objDLButtonParent="+objDLButtonParent + ",
		// objDLButtonParent.style.color="+objDLButtonParent.style.color + ",
		// objDLButtonParent.style.backgroundColor="+objDLButtonParent.style.backgroundColor);
		if (objDLButtonParent != null) {
			if (objDLButtonParent.className == "DLbtnOn") {
				objDLButtonParent.className = "DLbtnOff";
			}
		}
		var objDLMessageParent = document.getElementById("downloadOpenMessage");
		// alert("objDLMessageParent="+objDLMessageParent);
		if (objDLMessageParent != null) {
			// alert("objDLMessageParent.innerHTML="+objDLMessageParent.innerHTML);
			objDLMessageParent.innerHTML = "";
		}
	}

	// ファイルダウンロードを実行
	fileDownloadGoDownLoad(objFileNameParent);

}

function fileDownloadGoDownLoad(objFileNameParent) {

	FileDownloadService.check(objFileNameParent.value, {
		callback : respFileDownloadCheckByDwr,
		errorHandler : respFileDownloadCheckByDwrOnError,
		warningHandler : respFileDownloadCheckByDwrOnWarning,
		exceptionHandler : respFileDownloadCheckByDwrOnException
	});

}

/**
 * 検索のエラー処理（サーバー処理の後）
 * 
 * @param message
 *            メッセージ
 * @param error
 *            エラー
 */
function respFileDownloadCheckByDwrOnError(message, error) {
	//alert("ファイルをダウンロードできません。");
	var displayMessage = "ファイルをダウンロードできません。";
	// メッセージを表示
	fileDownloadSetMessage(displayMessage, true);
	// 「閉じる」以外のボタンは使用不可のままにする
}

/**
 * 検索の例外処理（サーバー処理の後）
 * 
 * @param message
 *            メッセージ
 * @param exception
 *            例外
 */
function respFileDownloadCheckByDwrOnException(message, exception) {
	//alert("ファイルをダウンロードできません。");
	var displayMessage = "ファイルをダウンロードできません。";
	// メッセージを表示
	fileDownloadSetMessage(displayMessage, true);
	// 「閉じる」以外のボタンは使用不可のままにする
}

/**
 * 検索の警告処理（サーバー処理の後）
 * 
 * @param message
 *            メッセージ
 * @param warning
 *            警告
 */
function respFileDownloadCheckByDwrOnWarning(message, warning) {
	//alert("ファイルをダウンロードできません。");
	var displayMessage = "ファイルをダウンロードできません。";
	if (warning.name == "dwr.engine.missingData") {
		// ログオンチェックエラー、IPアドレスチェックエラーの場合は、ServletFilterで空の戻りをしている。
		displayMessage = "ログオンしてください。";
	}
	// メッセージを表示
	fileDownloadSetMessage(displayMessage, true);
	// 「閉じる」以外のボタンは使用不可のままにする
}

/**
 * ファイルダウンロードのチェック処理正常終了 リンク経由でファイルダウンロードをさせたい
 */
function respFileDownloadCheckByDwr(resp) {

	// ダウンロード後に閉じるかどうかを取得
	var objCheckAutoClose = fileDownloadGetAutoClose();
	if (objCheckAutoClose != null && objCheckAutoClose.checked) {
		openFileDownload();
	}

	
	dwrGetFileDownloadForm().action = "/hanbai/common/fileDownload/commonFileDownload";
	dwrGetFileDownloadForm().method = "post";
	dwrGetFileDownloadForm().submit();

}

/**
 * ファイルダウンロード画面のボタン処理 最新表示
 */
function fileDownloadNew() {
	// alert("fileDownloadNew");
	if (objFileDownloadForm == null) {
		// alert("フォームが存在しない");
		return;
	}
	// メッセージを表示
	fileDownloadSetMessage("ただ今一覧表を表示中です。しばらくお待ち下さい。");
	// ボタンを使用不可にする
	fileDownloadSetButtonDisabledDownloadExec(true);

	// 画面初期値設定
	jokenInitialize();
	
	FileDownloadService.getJokenElementsInit({
		callback : respFileDownloadGetJokenElementsByDwr,
		errorHandler : respFileDownloadNewByDwrOnError,
		warningHandler : respFileDownloadNewByDwrOnWarning,
		exceptionHandler : respFileDownloadNewByDwrOnException
	});

	// 検索
	FileDownloadService.search(
			document.getElementById("fldFileDownloadSystem").value, document
					.getElementById("fldFileDownloadFileShuruiKbn").value,
			null, getFldFileDownloadOnlyValue(), document
					.getElementById("fldFileDownloadSakuseiFrom").value,
			document.getElementById("fldFileDownloadSakuseiTo").value, {
				callback : respFileDownloadNewByDwr,
				errorHandler : respFileDownloadNewByDwrOnError,
				warningHandler : respFileDownloadNewByDwrOnWarning,
				exceptionHandler : respFileDownloadNewByDwrOnException
			});

}

/**
 * 検索ボタン押下時の処理を行う。
 */
function fileDownloadSearch() {
	// alert("fileDownloadNew");
	if (objFileDownloadForm == null) {
		// alert("フォームが存在しない");
		return;
	}
	// メッセージを表示
	fileDownloadSetMessage("ただ今一覧表を表示中です。しばらくお待ち下さい。");
	// ボタンを使用不可にする
	fileDownloadSetButtonDisabledDownloadExec(true);

	// 検索
	FileDownloadService.search(
			document.getElementById("fldFileDownloadSystem").value, document
					.getElementById("fldFileDownloadFileShuruiKbn").value,
					getChoicePrints(), getFldFileDownloadOnlyValue(), document
					.getElementById("fldFileDownloadSakuseiFrom").value,
			document.getElementById("fldFileDownloadSakuseiTo").value, {
				callback : respFileDownloadNewByDwr,
				errorHandler : respFileDownloadNewByDwrOnError,
				warningHandler : respFileDownloadNewByDwrOnWarning,
				exceptionHandler : respFileDownloadNewByDwrOnException
			});

}

/**
 * 選択された帳票の配列を返す
 * @returns {Array}
 */
function getChoicePrints() {
	
	var objs = document.getElementsByName("choicePrintid");
	var prints = [];
	for(var i = 0; i < objs.length; i++) {
		if(objs[i].checked) {
			prints.push(objs[i].value);
		}
	}

	return prints;
}


/**
 * クリアボタン押下時の処理を行う。
 */
function fileDownloadClear() {
	// alert("fileDownloadNew");
	if (objFileDownloadForm == null) {
		// alert("フォームが存在しない");
		return;
	}

	// ボタンを使用不可にする
	fileDownloadSetButtonDisabledDownloadExec(true);

	// 画面初期値設定
	jokenInitialize();

	FileDownloadService.getJokenElementsInit({
		callback : respFileDownloadGetJokenElementsByDwr,
		errorHandler : respFileDownloadNewByDwrOnError,
		warningHandler : respFileDownloadNewByDwrOnWarning,
		exceptionHandler : respFileDownloadNewByDwrOnException
	});

	ichiranClear();
	fileDownloadSetMessage("条件を入力し、検索ボタンを押してください。 ");
//	fileDownloadSetButtonDisabledDownloadExec(false);
}

/**
 * 作成日FROM-TOの初期値を設定する。
 */
function setInitSakuseiDateFromTo() {

	var date = new Date();
	date.setDate(date.getDate() - 1);
	document.getElementById("fldFileDownloadSakuseiFrom").value = $.format
			.date(date, "yyyyMMdd");
	document.getElementById("fldFileDownloadSakuseiTo").value = $.format.date(
			new Date(), "yyyyMMdd");

}

/**
 * 条件部を初期値にする。
 */
function jokenInitialize() {
	
	document.getElementById("fldFileDownloadSystem").value = "all";
	document.getElementById("fldFileDownloadFileShuruiKbn").value = "all";
	
	document.getElementById("chkAutoClose").checked = true;
	setInitSakuseiDateFromTo();
	document.getElementById("chkSelectAll").checked = false;

	var fldFileDownloadOnlys = document.getElementsByName("fldFileDownloadOnly");
	for(var i = 0; i < fldFileDownloadOnlys.length; i++) {
		if(fldFileDownloadOnlys[i].value == "accid") {
			fldFileDownloadOnlys[i].checked = true;
			break;
		}
	}
	
}

/**
 * 作成依頼者でどれが設定されているかを返す。
 * 
 * @returns 設定されているラジオボタンの値
 */
function getFldFileDownloadOnlyValue() {

	var obj = document.getElementsByName("fldFileDownloadOnly");
	for (var i = 0; i < obj.length; i++) {
		if (obj[i].checked) {
			return obj[i].value;
		}
	}

	return "";
}

/**
 * システムプルダウン切り替え時の処理を行う。
 */
function fileDownloadChangePrint() {

	if (objFileDownloadForm == null) {
		return;
	}
	// ボタンを使用不可にする
	fileDownloadSetButtonDisabledDownloadExec(true);

	system = document.getElementById("fldFileDownloadSystem").value;
	fileShuruiKbn = document.getElementById("fldFileDownloadFileShuruiKbn").value;

	FileDownloadService.getJokenElementsChangeSystem(system, fileShuruiKbn, {
		callback : respFileDownloadGetJokenElementsChangeSystemByDwr,
		errorHandler : respFileDownloadNewByDwrOnError,
		warningHandler : respFileDownloadNewByDwrOnWarning,
		exceptionHandler : respFileDownloadNewByDwrOnException
	});

	fileDownloadSetButtonDisabledDownloadExec(false);
}

/**
 * 帳票種類プルダウン切り替え時の処理を行う。
 */
function fileDownloadChangeFileShuruiKbn() {

	if (objFileDownloadForm == null) {
		return;
	}
	// ボタンを使用不可にする
	fileDownloadSetButtonDisabledDownloadExec(true);

	// 使用可能なサブシステム、帳票一覧を取得
	system = document.getElementById("fldFileDownloadSystem").value;
	fileShuruiKbn = document.getElementById("fldFileDownloadFileShuruiKbn").value;

	FileDownloadService
			.getJokenElementsChangeFileShuruiKbn(
					system,
					fileShuruiKbn,
					{
						callback : respFileDownloadGetJokenElementsChangeFileShuruiKbnByDwr,
						errorHandler : respFileDownloadNewByDwrOnError,
						warningHandler : respFileDownloadNewByDwrOnWarning,
						exceptionHandler : respFileDownloadNewByDwrOnException
					});

	fileDownloadSetButtonDisabledDownloadExec(false);
}

/**
 * 検索のエラー処理（サーバー処理の後）
 * 
 * @param message
 *            メッセージ
 * @param error
 *            エラー
 */
function respFileDownloadNewByDwrOnError(message, error) {
//	alert("onError:" + error);
	var displayMessage = "検索結果を表示できません。";
	// メッセージを表示
	fileDownloadSetMessage(displayMessage, true);
	// 「閉じる」以外のボタンは使用不可のままにする
}

/**
 * 検索の例外処理（サーバー処理の後）
 * 
 * @param message
 *            メッセージ
 * @param exception
 *            例外
 */
function respFileDownloadNewByDwrOnException(message, exception) {
//	alert("onException");
	var displayMessage = "検索結果を表示できません。";
	// メッセージを表示
	fileDownloadSetMessage(displayMessage, true);
	// 「閉じる」以外のボタンは使用不可のままにする
}

/**
 * 検索の警告処理（サーバー処理の後）
 * 
 * @param message
 *            メッセージ
 * @param warning
 *            警告
 */
function respFileDownloadNewByDwrOnWarning(message, warning) {
//	alert("onWarning");
	var displayMessage = "検索結果を表示できません。";
	if (warning.name == "dwr.engine.missingData") {
		// ログオンチェックエラー、IPアドレスチェックエラーの場合は、ServletFilterで空の戻りをしている。
		displayMessage = "ログオンしてください。";
	}
	// メッセージを表示
	fileDownloadSetMessage(displayMessage, true);
	// 「閉じる」以外のボタンは使用不可のままにする
}

/**
 * 最新表示処理（サーバー処理の後） 検索結果を画面に表示する
 * 
 * @param resp
 *            サーバー処理の戻り値
 */
function respFileDownloadGetJokenElementsByDwr(resp) {
	if (objFileDownloadForm == null) {
		// alert("検索中に画面が閉じられた。");
		return;
	}

	// プルダウンｓｅｌｅｃｔ用
	system = document.getElementById("fldFileDownloadSystem").value;

	// システムプルダウン生成
	var varFldFileDownloadSystem = document
			.getElementById("fldFileDownloadSystem");
	DWRUtil.removeAllOptions(varFldFileDownloadSystem);
	DWRUtil.addOptions(varFldFileDownloadSystem, resp.systemList, "menuId",
			"menuNm");
	var m = resp.systemList.length;
	var i = 0;
	for (i = 0; m > i; i++) {
		if (varFldFileDownloadSystem.options[i].value == system) {
			varFldFileDownloadSystem.options[i].selected = true;
			break;
		}
	}

	// ファイル種別プルダウン生成
	createFileShuruiKbn(resp.fileShuruiKbnList);

	// 帳票チェックボックス生成
	createPrintsCheckbox(resp.printList);

}

/**
 * システムプルダウン切り替え時の帳票種別、帳票チェックボックス一覧再生成を行う。
 * 
 * @param resp
 *            サーバー処理の戻り値
 */
function respFileDownloadGetJokenElementsChangeSystemByDwr(resp) {

	if (objFileDownloadForm == null) {
		// alert("検索中に画面が閉じられた。");
		return;
	}

	// ファイル種別プルダウン生成
	createFileShuruiKbn(resp.fileShuruiKbnList);

	// 帳票チェックボックス生成
	createPrintsCheckbox(resp.printList);

}

/**
 * 帳票種別切り替え時の帳票チェックボックス一覧再生成を行う。
 * 
 * @param resp
 *            サーバー処理の戻り値
 */
function respFileDownloadGetJokenElementsChangeFileShuruiKbnByDwr(resp) {

	if (objFileDownloadForm == null) {
		// alert("検索中に画面が閉じられた。");
		return;
	}

	createPrintsCheckbox(resp.printList);

}

/**
 * ファイル種別プルダウンを生成する。
 * 
 * @param fileShuruiKbnList
 *            ファイル種別リスト
 */
function createFileShuruiKbn(fileShuruiKbnList) {

	fileShuruiKbn = document.getElementById("fldFileDownloadFileShuruiKbn").value;

	// ファイル種別プルダウン生成
	var varFldFileDownloadFileShuruiKbn = document
			.getElementById("fldFileDownloadFileShuruiKbn");
	DWRUtil.removeAllOptions(varFldFileDownloadFileShuruiKbn);
	DWRUtil.addOptions(varFldFileDownloadFileShuruiKbn, fileShuruiKbnList,
			"fileShuruiKbn", "fileShuruiKbnNm");
	var n = fileShuruiKbnList.length;
	var j = 0;
	for (j = 0; n > j; j++) {
		if (varFldFileDownloadFileShuruiKbn.options[j].value == fileShuruiKbn) {
			varFldFileDownloadFileShuruiKbn.options[j].selected = true;
			break;
		}
	}

}

/**
 * 帳票チェックボックスを生成する。
 * 
 * @param printList
 *            帳票を格納したリスト
 */
function createPrintsCheckbox(printList) {

	// 帳票チェックボックス生成
	var varFldFileDownloadPrints = $("div.fldFileDownloadPrints");
	varFldFileDownloadPrints.empty();
	var o = printList.length;
	var k = 0;

	if(o == 0) {
		fileDownloadSetMessage("ダウンロード可能な帳票がありません。", true);
	}
	
	for (k = 0; o > k; k++) {

		var checkboxstr = '<label style="display:inline-block; width:170px;">'
				+ '<input type="checkbox" name="choicePrintid" value="'
				+ escapeHTML(printList[k].printId) + '" id="choicePrintid">'
				+ escapeHTML(printList[k].printRyknm) + '</label>';
		varFldFileDownloadPrints.append(checkboxstr);
	}

}

// HTMLエスケープ
function escapeHTML(html) {
	return jQuery('<div>').text(html).html();
}

/**
 * 最新表示処理（サーバー処理の後） 検索結果を画面に表示する
 * 
 * @param resp
 *            サーバー処理の戻り値
 */
function respFileDownloadNewByDwr(resp) {
	// alert("respFileDownloadNewByDwr start
	// fileNameArray=["+fileDownloadSelectedFileNameArray+"], resp=["+resp+"]");
	if (objFileDownloadForm == null) {
		// alert("検索中に画面が閉じられた。");
		return;
	}

	// alert("respFileDownloadNewByDwr 1");
	var respIndex = 0; // 検索結果の配列のインデックス

	// alert("respFileDownloadNewByDwr 2");
	// メッセージを取得
	var message = resp[respIndex++];
	// alert("respFileDownloadNewByDwr message="+message);

	// エラー発生フィールドのインデックスを取得
	var errorObjectName = resp[respIndex++];
	var isError = false;
	if (errorObjectName != null) {
		isError = true;
		fileDownloadSetMessage(message, isError);
	} else if(message != null){
		fileDownloadSetMessage(message);
	} else {
		fileDownloadSetMessage("検索しました。");

	}

	fileDownloadSelectedFileNameArray = null;

	var selectCount = resp[respIndex++]; // 検索結果のレコード数

	if (selectCount > 0) {

		// 一覧表を表示
		var pObj = document.getElementById("tableFileDownload").parentNode; // 一覧表の親ノード
		// 一覧表テーブル全体を、サーバから受信したHTMLで上書き
		pObj.innerHTML = resp[respIndex++];

		// ボタンを使用可にする
		fileDownloadSetButtonDisabledDownloadExec(false);

	} else {
		ichiranClear();
	}

	
	
}

/**
 * 一覧をクリアする。
 */
function ichiranClear() {
	// 一覧表をクリア
	var objIchiran = document.getElementById("tableFileDownload");
	var rowCount = objIchiran.rows.length;
	for (var rowIndex = 0; rowIndex < rowCount; rowIndex++) {
		objIchiran.deleteRow(0);
	}
	
	// ダウンロードできるファイルが存在しない場合は、ダウンロードボタンを使用不可にする
	fileDownloadSetButtonDisabledDownloadExec(true);
}

/**
 * ファイルダウンロード画面のメッセージ表示欄にメッセージをセットする
 * 
 * @param message
 *            メッセージ
 * @param isError
 *            エラーの場合true
 */
function fileDownloadSetMessage(message, isError) {
	if (arguments.length < 2) {
		isError = false;
	}
	var objMessage = document.getElementById(file_download_name_span_message);
	if (objMessage != null) {
		objMessage.innerHTML = message;
		if (isError) {
			objMessage.style.color = file_download_color_error;
		} else {
			objMessage.style.color = "";
		}
	} else {
		// alert("メッセージ欄が存在しない。"+file_download_name_span_message);
	}
}

/**
 * ダウンロードボタンを使用可能／使用不可にする
 * 
 * @param disabled
 *            使用不可にする場合true、使用可能にする場合false
 */
function fileDownloadSetButtonDisabledDownloadExec(disabled) {
	objFileDownloadForm.elements["btnDownloadExec"].disabled = disabled;
}

/**
 * ファイルダウンロード画面のボタン処理 キャンセル
 */
function fileDownloadCancel() {
	openFileDownload();
}

/**
 * ファイルダウンロード画面の処理 全て選択／解除
 */
function fileDownloadSelectAll(obj) {
	var objs = document.getElementsByName("fileDownloadChoice");
//	 alert(objs.length);
//	 alert(obj.checked);
	for (i = 0; i < objs.length; i++) {
		objs[i].checked = obj.checked;
	}
}
/**
 * ファイルダウンロード画面のダウンロード後に閉じるチェックボックスを取得する
 */
function fileDownloadGetAutoClose() {
	return objFileDownloadForm.elements["chkAutoClose"];
}

// 以下、他のfunctionから呼び出されるprivateな処理 -----------------------------

/**
 * 一覧表で選択しているファイルを取得する
 * 
 * @param jokyoNew
 *            選択しているファイルの新しい作成状況 作成状況を変更しない場合はnullを指定
 * @return { 選択しているファイル名の配列, ファイルダウンロード画面へボタンをONにするファイル数 }
 */
function fileDownloadGetSelectedFileName(jokyoNew) {
	// alert("fileDownloadGetSelectedFileName start");
	if (arguments.length < 1) {
		jokyoNew = null;
	}
	var fileNameArray = new Array();
	var fileNameIndex = 0;
	var objCheck = null;
	var objCode = null;
	var objIchiran = fileDownloadGetIchiran();
	var ichiranCount = objIchiran.rows.length;
	var jokyo = null;
	var fileCountDLOn = 0;
	// alert("fileDownloadGetSelectedFileName 1");
	// 一覧表の行毎に繰り返し
	for (var rowIndex = 0; rowIndex < ichiranCount; rowIndex++) {
		// 選択チェックボックスを取得
		// alert("fileDownloadGetSelectedFileName 2");
		objCheck = fileDownloadGetIchiranCheckBox(rowIndex);
		// alert("fileDownloadGetSelectedFileName 3");
		if (objCheck != null && objCheck.checked) {
			// チェックONの場合
			// alert("fileDownloadGetSelectedFileName 4");
			// ファイル名の隠しフィールドを取得
			objCode = fileDownloadGetIchiranCode(rowIndex)
			if (objCode != null) {
				// alert("fileDownloadGetSelectedFileName 5");
				// ファイル名を取得する
				fileNameArray[fileNameIndex] = objCode.value;
				// alert("fileDownloadGetSelectedFileName 6");
				// 選択チェックをOFFにする
				objCheck.checked = false;
				// 作成状況を更新する
				if (jokyoNew != null) {
					fileDownloadSetSakuseiJokyo(objIchiran, rowIndex, jokyoNew);
				}
				fileNameIndex++;
			}
		}
		// 作成状況を元に、ファイルダウンロード画面へボタンをONにするファイル数を加算
		if (jokyoNew != null) {
			// 作成状況を取得
			jokyo = fileDownloadGetSakuseiJokyo(objIchiran, rowIndex);
			// 作成状況が、作成完了／作成中／待機中のファイルを数える
			if (jokyo != null
					&& (jokyo == file_download_sakusei_jokyo_mei_sakuseikanryo
							|| jokyo == file_download_sakusei_jokyo_mei_sakuseichu || jokyo == file_download_sakusei_jokyo_mei_taikichu)) {
				fileCountDLOn++;
			}
		}
	}
	// alert("fileDownloadGetSelectedFileName. fileCountDLOn="+fileCountDLOn);
	// alert("fileDownloadGetSelectedFileName end.");
	return new Array(fileNameArray, fileCountDLOn);
}

/**
 * ファイルダウンロード画面のメッセージ表示欄にメッセージをセットする
 * 
 * @param message
 *            メッセージ
 * @param isError
 *            エラーの場合true
 */
function fileDownloadSetMessage(message, isError) {
	if (arguments.length < 2) {
		isError = false;
	}
	var objMessage = document.getElementById(file_download_name_span_message);
	if (objMessage != null) {
		objMessage.innerHTML = message;
		if (isError) {
			objMessage.style.color = file_download_color_error;
		} else {
			objMessage.style.color = "";
		}
	} else {
		// alert("メッセージ欄が存在しない。"+file_download_name_span_message);
	}
}

/**
 * ファイルダウンロード画面の一覧表を取得する
 * 
 * @return 一覧表
 */
function fileDownloadGetIchiran() {
	return document.getElementById(file_download_name_table_ichiran);
}

/**
 * ファイルダウンロード画面の一覧表の行選択チェックボックスを取得する
 * 
 * @param index
 *            行インデックス
 * @return 一覧表の行選択チェックボックス
 */
function fileDownloadGetIchiranCheckBox(index) {
	return objFileDownloadForm.elements[fileDownloadGetIchiranCheckBoxName(index)];
}

/**
 * ファイルダウンロード画面の一覧表の行選択チェックボックスの名前を取得する
 * 
 * @param index
 *            行インデックス
 * @return 一覧表の行選択チェックボックスの名前
 */
function fileDownloadGetIchiranCheckBoxName(index) {
	return "TBLchkSelect_" + index;
}

/**
 * ファイルダウンロード画面の一覧表のコードのテキストフィールドを取得する
 * 
 * @param index
 *            行インデックス
 * @return 一覧表のコードのテキストフィールド
 */
function fileDownloadGetIchiranCode(index) {
	return objFileDownloadForm.elements[fileDownloadGetIchiranCodeName(index)];
}

/**
 * ファイルダウンロード画面の一覧表のコードのテキストフィールドを取得する
 * 
 * @param index
 *            行インデックス
 * @return 一覧表のコードのテキストフィールドの名前
 */
function fileDownloadGetIchiranCodeName(index) {
	return "TBLcode_" + index;
}

/**
 * ファイルダウンロード画面の一覧表のコードの隠しフィールドのタグを取得する
 * 
 * @param rowIndex
 *            行インデックス
 * @param code
 *            コード値
 * @return 一覧表のコードの隠しフィールドのタグ
 */
function fileDownloadGetIchiranCodeTag(rowIndex, code) {
	return "<input type=\"hidden\" name=\""
			+ fileDownloadGetIchiranCodeName(rowIndex) + "\" id=\""
			+ fileDownloadGetIchiranCodeName(rowIndex) + "\" value=\"" + code
			+ "\">";
}

/**
 * ファイルダウンロード画面の一覧表の作成状況をセットする
 * 
 * @param table
 *            一覧表
 * @param index
 *            行インデックス
 * @param jokyo
 *            作成状況
 */
function fileDownloadSetSakuseiJokyo(table, index, jokyo) {
	var cell = table.rows[index].cells[6];
	if (cell != null) {
		cell.innerHTML = jokyo;
	}
}

/**
 * ファイルダウンロード画面の一覧表の作成状況をセットする
 * 
 * @param table
 *            一覧表
 * @param index
 *            行インデックス
 * @return 作成状況
 */
function fileDownloadGetSakuseiJokyo(table, index) {
	var jokyo = null;
	var cell = table.rows[index].cells[5];
	if (cell != null) {
		jokyo = cell.innerHTML;
	}
	return jokyo;
}

/**
 * ファイルダウンロード画面のダウンロード後に閉じるチェックボックスを取得する
 */
function fileDownloadGetAutoClose() {
	return objFileDownloadForm.elements["chkAutoClose"];
}

function dwrGetFileDownloadForm() {
	return document.forms[file_download_name_form];
}
