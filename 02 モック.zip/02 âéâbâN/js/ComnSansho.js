// -----------------------------------------------------------------------------
// 以下、参照画面のDWR用
// -----------------------------------------------------------------------------

// ▽ これらの値、コードは、
// SanshoDwr.java、SanshoDairiten.jsp、SanshoSalon.jsp、SanshoKokyaku.jsp、SanshoSeihin.jsp
// と同じであること

// 以下、変数
/** コードの貼り付け先のテキストフィールドの配列 */
var objSanshoTextArray = null;
/** コードの貼り付け先のテキストフィールド 販売会社コード */
var objSanshoTextHanbaigaisha = null;
/** 主画面テキストフィールド 科目コード */
var objSanshoTextKamoku = null;
/** 参照画面Form */
var objSanshoForm = null;
/** 参照画面Span */
var objSanshoBox = null;
/** 参照画面Span（隠し） */
var objSanshoBoxHidden = null;
/** 絞込み条件に使用する販売会社コード */
var sanshoHanbaigaishaCodeSave = "";
/** 絞込み条件に使用する科目コード */
var sanshoKamokuCodeSave = "";
// 以下、定数
/** 参照画面のフォーム名 科目 */
var sansho_name_form_kamoku = "formSanshoKamoku";
/** 参照画面のフォーム名 摘要 */
var sansho_name_form_tekiyo = "formSanshoTekiyo";

/** 参照画面のフォーム名 特約店 */
var sansho_name_form_tokuyakuten = "formSanshoTokuyakuten";
/** 参照画面のフォーム名 JDS */
var sansho_name_form_jds = "formSanshoJds";
/** 参照画面のフォーム名 印税 */
var sansho_name_form_inzei = "formSanshoInzei";
/** 参照画面のフォーム名 商品 */
var sansho_name_form_shohin = "formSanshoShohin";
/** 参照画面のフォーム名 Project */
var sansho_name_form_project = "formSanshoProject";
/** 参照画面のフォーム名 企画 */
var sansho_name_form_kikaku = "formSanshoKikaku";
/** 参照画面のフォーム名 配信 */
var sansho_name_form_haishin = "formSanshoHaishin";
/** 参照画面のフォーム名 アーチスト */
var sansho_name_form_artist = "formSanshoArtist";
/** 参照画面のフォーム名 支払 */
var sansho_name_form_shiharai = "formSanshoShiharai";
/** 参照画面のフォーム名 権利者 */
var sansho_name_form_kenrisha = "formSanshoKenrisha";
/** 参照画面のフォーム名 契約番号 */
var sansho_name_form_keiyaku = "formSanshoKeiyaku";
/** 参照画面のフォーム名 契約番号-枝番 */
var sansho_name_form_keiyakuEda = "formSanshoKeiyakuEda";
/** 参照画面のフォーム名 アドバンスコード */
var sansho_name_form_advance = "formSanshoAdvance";

/** 参照画面の販売会社コードテキストフィールドの名前 */
var sansho_name_txt_hanbaigaisha_code = "fldSanshoHanbaigaishaCode";
/** 参照画面の科目コードテキストフィールドの名前 */
var sansho_name_txt_kamoku_code = "fldSanshoTekiyoKamokuCode";

/** 参照画面のメッセージ表示欄の名前の接頭子 この後ろに"Kamoku"など種類が付く */
var sansho_name_span_message = "spanSanshoMessage";
/** 参照画面の一覧表テーブルの名前の接頭子 この後ろに"Kamoku"など種類が付く */
var sansho_name_table_ichiran = "tableSansho";
/** 参照画面の種類を示す区分 科目 */
var sansho_kbn_kamoku = "";
/** 参照画面の種類を示す区分 摘要 */
var sansho_kbn_tekiyo = "";
/** 参照画面の種類を示す区分 特約店 */
var sansho_kbn_tokuyakuten = "T";
/** 参照画面の種類を示す区分 JDS */
var sansho_kbn_jds = "J";
/** 参照画面の種類を示す区分 印税 */
var sansho_kbn_inzei = "I";
/** 参照画面の種類を示す区分 商品 */
var sansho_kbn_shohin = "S";
/** 参照画面の種類を示す区分 Project */
var sansho_kbn_project = "P";
/** 参照画面の種類を示す区分 企画 */
var sansho_kbn_kikaku = "K";
/** 参照画面の種類を示す区分 配信 */
var sansho_kbn_haishin = "H";
/** 参照画面の種類を示す区分 アーチスト */
var sansho_kbn_artist = "A";
/** 参照画面の種類を示す区分 支払 */
var sansho_kbn_shiharai = "SH";
/** 参照画面の種類を示す区分 権利者 */
var sansho_kbn_kenrisha = "KE";
/** 参照画面の種類を示す区分 契約番号 */
var sansho_kbn_keiyaku = "KEI";
/** 参照画面の種類を示す区分 契約番号-枝番 */
var sansho_kbn_keiyakuEda = "KEIEDA";
/** 参照画面の種類を示す区分 アドバンス */
var sansho_kbn_advance = "AD";
/** 参照画面のエラー色 */
var sansho_color_error = "#FF3030";
/** 行選択チェックをチェックONにした行のインデックスの配列 */
var sanshoSelectedIndexArray = new Array();
/** 参照画面の区切り文字(隠し) */
var sansho_DelimiterHidden = "";

// 以下、画面の種類に依らず共通の処理 -----------------------------------------
// 以下、画面のイベントで実行されるpublicな処理 --------------------------------

/**
 * 参照画面を開く／閉じる
 *
 * @param kbn
 *            参照画面の種類を示す区分 "K"：科目 "T"：特約店
 * @param nameTextArray
 *            コードの貼り付け先のテキストフィールドの名前の配列 最小でも1要素は必要
 * @param nameTextHanbaigaisha
 *            コードの貼り付け先のテキストフィールドの名前 販売会社コード フィールドが存在しない場合はnullを指定する
 * @param hanbaigaishaCode
 *            絞込み条件に使用する 販売会社コード
 * @param nameTextKamoku
 *            絞込み条件に使用する 科目コードのテキストフィールドの名前
 */
function openSansho(kbn, nameTextArray, nameTextHanbaigaisha, hanbaigaishaCode,
		nameTextKamoku) {
	// alert("openSansho ken="+kbn);
	// nameTextArray="+nameTextArray+",nameTextHanbaigaisha="+nameTextHanbaigaisha+",hanbaigaishaCode="+hanbaigaishaCode);
	if (objSanshoForm != null) {
		// 参照画面が開いている場合、閉じる
		if (objSanshoBox != null) {
			objSanshoBox.style.display = 'none';
		}
		if (objSanshoBoxHidden != null) {
			objSanshoBoxHidden.style.display = 'none';
		}
		// 変数をクリア
		objSanshoForm = null;
		objSanshoBox = null;
		objSanshoBoxHidden = null;
		objSanshoTextArray = null;
		objSanshoTextHanbaigaisha = null;
		objSanshoTextKamoku = null;
		sanshoHanbaigaishaCodeSave = "";
		sanshoKamokuCodeSave = "";
		sanshoSelectedIndexArray = new Array();
	} else {
		// 参照画面が閉じている場合、開く
		if (arguments.length < 5) {
			nameTextKamoku = null;
		}
		if (arguments.length < 4) {
			hanbaigaishaCode = null;
		}
		if (arguments.length < 3) {
			nameTextHanbaigaisha = null;
		}
		// 区分をチェック
		if (kbn != sansho_kbn_inzei && kbn != sansho_kbn_shohin && kbn != sansho_kbn_tokuyakuten && kbn != sansho_kbn_jds
                         && kbn != sansho_kbn_project && kbn != sansho_kbn_kikaku && kbn != sansho_kbn_haishin
                         && kbn != sansho_kbn_artist && kbn != sansho_kbn_shiharai && kbn != sansho_kbn_kenrisha
                         && kbn != sansho_kbn_keiyaku && kbn != sansho_kbn_keiyakuEda && kbn != sansho_kbn_advance) {
			// alert("kbnが不正 kbn=["+kbn+"]");
			return;
		}
		// 貼り付け先をチェック
		if (nameTextArray == null || nameTextArray.length == 0) {
			// alert("貼り付け先のテキストフィールドが指定されていない");
			return;
		}
		// 貼り付け先のテキストフィールドを取得
		objSanshoTextArray = new Array(nameTextArray.length);
		for (var i = 0; i < nameTextArray.length; i++) {
			if (nameTextArray[i] != null && nameTextArray[i] != "") {
				objSanshoTextArray[i] = dwrGetMainForm().elements[nameTextArray[i]];
			}
		}
		if (objSanshoTextArray[0] == null) {
			// alert("テキストFromが存在しない nameTextFrom=["+nameTextFrom+"]");
			return;
		}
		// 貼り付け先のテキストフィールド（販売会社）を取得
		if (nameTextHanbaigaisha != null && nameTextHanbaigaisha != "") {
			objSanshoTextHanbaigaisha = dwrGetMainForm().elements[nameTextHanbaigaisha];
		} else {
			objSanshoTextHanbaigaisha = null;
		}
		// 貼り付け先のテキストフィールド（科目コード）を取得
		if (nameTextKamoku != null && nameTextKamoku != "") {
			objSanshoTextKamoku = dwrGetMainForm().elements[nameTextKamoku];
		} else {
			objSanshoTextKamoku = null;
		}
		// 参照画面のフォーム、spanを取得
		var nameForm = "";
		var nameBox = "";
		var nameBoxHidden = "";
		if (kbn == sansho_kbn_kamoku) {
			nameForm = sansho_name_form_kamoku;
			nameBox = "boxSanshoKamoku";
			nameBoxHidden = "boxSanshoKamokuHidden";
		} else if (kbn == sansho_kbn_tekiyo) {
			nameForm = sansho_name_form_tekiyo;
			nameBox = "boxSanshoTekiyo";
			nameBoxHidden = "boxSanshoTekiyoHidden";
		} else if (kbn == sansho_kbn_tokuyakuten) {
			nameForm = sansho_name_form_tokuyakuten;
			nameBox = "boxSanshoTokuyakuten";
			nameBoxHidden = "boxSanshoTokuyakutenHidden";
		} else if (kbn == sansho_kbn_jds) {
			nameForm = sansho_name_form_jds;
			nameBox = "boxSanshoJds";
			nameBoxHidden = "boxSanshoJdsHidden";
		} else if (kbn == sansho_kbn_inzei) {
			nameForm = sansho_name_form_inzei;
			nameBox = "boxSanshoInzei";
			nameBoxHidden = "boxSanshoInzeiHidden";
		} else if (kbn == sansho_kbn_shohin) {
			nameForm = sansho_name_form_shohin;
			nameBox = "boxSanshoShohin";
			nameBoxHidden = "boxSanshoShohinHidden";
		} else if (kbn == sansho_kbn_project) {
			nameForm = sansho_name_form_project;
			nameBox = "boxSanshoProject";
			nameBoxHidden = "boxSanshoProjectHidden";
		} else if (kbn == sansho_kbn_kikaku) {
			nameForm = sansho_name_form_kikaku;
			nameBox = "boxSanshoKikaku";
			nameBoxHidden = "boxSanshoKikakuHidden";
                } else if (kbn == sansho_kbn_haishin) {
                        nameForm = sansho_name_form_haishin;
                        nameBox = "boxSanshoHaishin";
                        nameBoxHidden = "boxSanshoHaishinHidden";
		} else if (kbn == sansho_kbn_artist) {
			nameForm = sansho_name_form_artist;
			nameBox = "boxSanshoArtist";
			nameBoxHidden = "boxSanshoArtistHidden";
		} else if (kbn == sansho_kbn_shiharai) {
			nameForm = sansho_name_form_shiharai;
			nameBox = "boxSanshoShiharai";
			nameBoxHidden = "boxSanshoShiharaiHidden";
    } else if (kbn == sansho_kbn_kenrisha) {
			nameForm = sansho_name_form_kenrisha;
			nameBox = "boxSanshoKenrisha";
			nameBoxHidden = "boxSanshoKenrishaHidden";
		} else if (kbn == sansho_kbn_keiyaku) {
			nameForm = sansho_name_form_keiyaku;
			nameBox = "boxSanshoKeiyaku";
			nameBoxHidden = "boxSanshoKeiyakuHidden";
    }else if (kbn == sansho_kbn_keiyakuEda) {
			nameForm = sansho_name_form_keiyakuEda;
			nameBox = "boxSanshoKeiyakuEda";
			nameBoxHidden = "boxSanshoKeiyakuEdaHidden";
    }else if (kbn == sansho_kbn_advance) {
			nameForm = sansho_name_form_advance;
			nameBox = "boxSanshoAdvance";
			nameBoxHidden = "boxSanshoAdvanceHidden";
    }

		objSanshoForm = document.forms[nameForm];
		objSanshoBox = document.getElementById(nameBox);
		objSanshoBoxHidden = document.getElementById(nameBoxHidden);
		sansho_DelimiterHidden = objSanshoForm.elements["hdnDelimiter"].value;
		if (objSanshoForm == null || objSanshoBox == null
				|| objSanshoBoxHidden == null) {
			// alert("form,Box,BoxHiddenが存在しない");
			return;
		}
		// alert("objSanshoForm=["+objSanshoForm.id+"],objSanshoBox=["+objSanshoBox.id+"],objSanshoBoxHidden=["+objSanshoBoxHidden.id+"]");
		// 参照画面に販売会社コードを設定する
		if (kbn == sansho_kbn_shohin || kbn == sansho_kbn_inzei || kbn == sansho_kbn_tokuyakuten  || kbn == sansho_kbn_jds
                         || kbn == sansho_kbn_project || kbn == sansho_kbn_kikaku || kbn == sansho_kbn_haishin
                         || kbn == sansho_kbn_artist || kbn == sansho_kbn_shiharai || kbn == sansho_kbn_kenrisha
                         || kbn == sansho_kbn_keiyaku || kbn == sansho_kbn_keiyakuEda || kbn == sansho_kbn_advance) {

			// 引数で販売会社コードが指定されていない場合、
			// 主画面の販売会社コードのテキストフィールドから、値を取得する
			if ((hanbaigaishaCode == null || hanbaigaishaCode == "")
					&& objSanshoTextHanbaigaisha != null) {
				hanbaigaishaCode = objSanshoTextHanbaigaisha.value;
			}
			// 参照画面の販売会社コードのテキストフィールドに、値をセットする
			var objCodeHanbaigaisha = objSanshoForm.elements[sansho_name_txt_hanbaigaisha_code];
			if (objCodeHanbaigaisha != null) {
				objCodeHanbaigaisha.value = hanbaigaishaCode;
			}
			// 保持しておく
			sanshoHanbaigaishaCodeSave = hanbaigaishaCode;
		}
		// 参照画面に科目コードを設定する
		if (kbn == sansho_kbn_tekiyo) {
			// 参照画面が摘要の場合のみ
			var kamokuCode = "";
			// 主画面の科目コードのテキストフィールドを取得
			if (nameTextKamoku != null && nameTextKamoku != "") {
				objSanshoTextKamoku = dwrGetMainForm().elements[nameTextKamoku];
			} else {
				objSanshoTextKamoku = null;
			}
			// alert("objSanshoTextKamoku="+objSanshoTextKamoku);
			// 主画面の科目コードのテキストフィールドから、値を取得する
			if (objSanshoTextKamoku != null) {
				kamokuCode = objSanshoTextKamoku.value;
			}
			// alert("kamokuCode="+kamokuCode);
			// 参照画面の科目コードのテキストフィールドに、値をセットする
			var objCodeKamoku = objSanshoForm.elements[sansho_name_txt_kamoku_code];
			if (objCodeKamoku != null) {
				objCodeKamoku.value = kamokuCode;
			}
			// 保持しておく
			sanshoKamokuCodeSave = kamokuCode;
		}
		// 参照画面を開く
		objSanshoBox.style.display = '';
		objSanshoBoxHidden.style.display = '';
		// 参照画面を初期化
		sanshoClear();
		// 自動的に検索を実行
		// 科目の場合に、実行
		if ((kbn == sansho_kbn_kamoku && (hanbaigaishaCode != null && hanbaigaishaCode != ""))
				|| (kbn == sansho_kbn_tekiyo
						&& (hanbaigaishaCode != null && hanbaigaishaCode != "") && (kamokuCode != null && kamokuCode != ""))) {
			var objKensakuBtn = objSanshoForm.elements["btnKensaku"];
			if (objKensakuBtn != null) {
				objKensakuBtn.click();
			}
		}
	}
}

/**
 * 参照画面ボタン処理 ＯＫ
 */
function sanshoOK() {
	// alert("sanshoOK start");
	// チェック
	if (objSanshoForm == null || objSanshoTextArray == null
			|| objSanshoTextArray.length == 0 || objSanshoTextArray[0] == null) {
		// alert("テキストFrom、フォームが存在しない");
		return;
	}
	// alert("sanshoSelectedIndexArray="+sanshoSelectedIndexArray);

	if (sanshoSelectedIndexArray != null && sanshoSelectedIndexArray.length > 0) {

		// 行選択チェックをチェックONにした行のインデックスの配列
		// を元に処理する。
		// この配列は、ONの後にOFFにしたものも含んでいる。

		// 昇順に並び替え
		// 並び替え関数を指定する。指定しないと16,10という順番になることがある。
		sanshoSelectedIndexArray.sort(sanshoSelectedIndexArraySort);

		var rowIndex = -1;
		var rowIndexBefore = -1;
		var textIndex = 0;
		var objCheck = null;
		var objCode = null;
		var isPasted = false;
		var cntLength = 0;
		var cntPaste = 0;

		// 行のインデックスの配列の要素毎に繰り返し
		for (var arrayIndex = 0; arrayIndex < sanshoSelectedIndexArray.length; arrayIndex++) {
			// alert("arrayIndex="+arrayIndex);
			// 行インデックスを取得
			rowIndexBefore = rowIndex;
			rowIndex = sanshoSelectedIndexArray[arrayIndex];
			if (rowIndex == rowIndexBefore) {
				// 同じ行だったら読み飛ばし
				continue;
			}
			// 選択チェックボックスを取得
			objCheck = sanshoGetIchiranCheckBox(rowIndex);
			if (objCheck == null) {
				// チェックボックスが無くなったら繰り返しを終了
				break;
			}
			// alert("objCheck"+objCheck+","+objCheck.name+","+objCheck.checked);
			if (objCheck.checked == true) {
				// チェックONの場合
				// コードの隠しフィールドを取得
				objCode = sanshoGetIchiranCode(rowIndex);
				if (objCode != null) {
					// alert("objCode
					// "+objCode+","+objCode.name+","+objCode.value);
					if (sansho_DelimiterHidden == "") {
						if (objSanshoTextArray[textIndex] != null) {
							objSanshoTextArray[textIndex].value = objCode.value;
							isPasted = true;
							textIndex++;
							if (textIndex >= objSanshoTextArray.length) {
								if (objSanshoTextKamoku != null) {
									var objCodeKamokuTmp = sanshoGetIchiranCodeKamoku(rowIndex);
									if (objCodeKamokuTmp != null) {
										objSanshoTextKamoku.value = objCodeKamokuTmp.value;
									}
								}
								// 貼り付け先のテキストフィールドが無くなったら繰り返しを終了
								break;
							}
						}
					} else {
						if (objSanshoTextArray[0] != null) {
							// デリミタに文字が入っているときは最初のオブジェクトにひたすら追加
							cntLength += objCode.value.length;
							if (cntPaste > 0) {
								cntLength += sansho_DelimiterHidden.length
							}
							if (objSanshoTextArray[0].maxLength < cntLength) {
								// 文字数が最大桁数を超える場合は処理を抜ける
								break;
							}
							if (cntPaste == 0) {
								objSanshoTextArray[0].value = objCode.value;
							} else {
								objSanshoTextArray[0].value += sansho_DelimiterHidden
										+ objCode.value;
							}
							isPasted = true;
							textIndex = 1;
							cntPaste++;
						}
					}
				}
			}
		}
		// alert("codeFrom="+codeFrom+",codeTo="+codeTo);
		if (isPasted) {
			// 残りのテキストフィールドをクリアする
			while (textIndex < objSanshoTextArray.length) {
				if (objSanshoTextArray[textIndex] != null) {
					objSanshoTextArray[textIndex].value = "";
				}
				textIndex++;
			}
			// 代理店コードをテキストフィールドに貼り付ける
			if (objSanshoTextHanbaigaisha != null) {
				var objCodeHanbaigaisha = objSanshoForm.elements[sansho_name_txt_hanbaigaisha_code];
				if (objCodeHanbaigaisha != null) {
					objSanshoTextHanbaigaisha.value = objCodeHanbaigaisha.value;
				}
			}
			// テキストのonchangeイベントを発生させる
			// alert("textObj="+objSanshoTextArray[0]);
			// 失敗。
			// objSanshoTextArray[0].change();
			// 失敗。obj.onchange = ...
			// で設定したものは実行できるが、obj.attacheEvent("onchange",...)で設定したものは実行できない。
			// objSanshoTextArray[0].onchange();
			objSanshoTextArray[0].fireEvent("onchange");
		}
	}
	// 参照画面を閉じる
	openSansho();
}


/**
 * 参照画面ボタン処理 選択
 */
function sanshoChoice(objCode) {
    // alert("sanshoChoice start");
    // チェック
    if (objSanshoForm == null || objSanshoTextArray == null || objSanshoTextArray.length == 0 || objSanshoTextArray[0] == null) {
        // alert("テキストFrom、フォームが存在しない");
        return;
    }
	// alert("sanshoSelectedIndexArray="+sanshoSelectedIndexArray);

    //objCode = sanshoGetIchiranCode(rowIndex.value)

    if (objSanshoTextArray[0] != null ) {
        objSanshoTextArray[0].value = objCode;
    }
	$(objSanshoTextArray[0]).trigger('onchange')

    // 参照画面を閉じる
    openSansho();
}

/**
 * 参照画面ボタン処理 選択(摘要子画面用)
 */
function sanshoChoiceTekiyo(kamokuObj, tekiyoObj) {
    // alert("sanshoChoiceTekiyo start");
    // チェック
    if (objSanshoForm == null || objSanshoTextArray == null || objSanshoTextArray.length == 0 || objSanshoTextArray[0] == null) {
        // alert("テキストFrom、フォームが存在しない");
        return;
    }

    if(objSanshoTextKamoku != null) {
    	objSanshoTextKamoku.value = kamokuObj;
		$(objSanshoTextKamoku).trigger('onchange')
    }

    if (objSanshoTextArray[0] != null ) {
        objSanshoTextArray[0].value = tekiyoObj;
		$(objSanshoTextArray[0]).trigger('onchange')
    }

    // 参照画面を閉じる
    openSansho();
}


/**
 * 行選択チェックをチェックONにした行のインデックスの配列で、要素の並び替え
 */
function sanshoSelectedIndexArraySort(a, b) {
	return parseInt(a) - parseInt(b);
}

/**
 * 参照画面のボタン処理 キャンセル
 */
function sanshoCancel() {
	// 参照画面を閉じる
	openSansho();
}

/**
 * 参照画面の行選択チェックボックスのチェック時の処理
 *
 * @param obj
 *            行選択チェックボックス
 */
function sanshoCheckLineSelector(obj) {
	// alert("sanshoCheckLineSelector start.");
	if (obj.checked) {
		// alert("sanshoCheckLineSelector checked.");
		var name = obj.name;
		// alert("sanshoCheckLineSelector name="+name);
		var pos = name.indexOf("_");
		// alert("sanshoCheckLineSelector pos="+pos);
		if (pos != -1) {
			var lineIndex = name.substr(pos + 1);
			// alert("sanshoCheckLineSelector lineIndex="+lineIndex);
			sanshoSelectedIndexArray.push(lineIndex);
		}
		// alert("sanshoCheckLineSelector added.");
	}
}

/**
 * 参照画面のボタン処理 クリア
 */
function sanshoClear() {
	if (objSanshoForm == null) {
		// alert("フォームが存在しない");
		return;
	}
	// メッセージをクリア
	sanshoSetMessage("条件を入力し、検索ボタンを押してください。");
	// 一覧表をクリア
	sanshoClearIchiran();
	// 条件部分のフィールドの色をクリア
	sanshoSetFieldColorNormalAll();
	sanshoSelectedIndexArray = new Array();
	// 条件部分をクリア
	if (sanshoIsKamoku()) {
		sanshoClearKamoku();
	} else if (sanshoIsTekiyo()) {
		sanshoClearTekiyo();
	} else if (sanshoIsTokuyakuten()) {
		sanshoClearTokuyakuten();
	} else if (sanshoIsJds()) {
		sanshoClearJds();
	} else if (sanshoIsInzei()) {
		sanshoClearInzei();
	} else if (sanshoIsShohin()) {
		sanshoClearShohin();
	} else if (sanshoIsProject()) {
		sanshoClearProject();
	} else if (sanshoIsKikaku()) {
		sanshoClearKikaku();
        } else if (sanshoIsHaishin()) {
		sanshoClearHaishin();
	} else if (sanshoIsArtist()) {
		sanshoClearArtist();
  } else if (sanshoIsShiharai()) {
		sanshoClearShiharai();
  } else if (sanshoIsKenrisha()) {
    sanshoClearKenrisha();
  } else if (sanshoIsKeiyaku()) {
    sanshoClearKeiyaku();
  } else if (sanshoIsKeiyakuEda()) {
    sanshoClearKeiyakuEda();
	} else if (sanshoIsAdvance()) {
    sanshoClearAdvance();
	}else {
		// 無処理
		// alert("参照画面の種類が想定外");
	}
	// ボタンを使用可能にする
	sanshoSetButtonDisabled(false);
}

/**
 * 参照画面ボタン処理 検索
 */
function sanshoKensaku() {
	if (objSanshoForm == null) {
		// alert("フォームが存在しない");
		return;
	}
	// メッセージを表示
	sanshoSetMessage("ただ今一覧表を表示中です。しばらくお待ち下さい。");
	// ボタンを使用不可にする
	sanshoSetButtonDisabled(true);
	// 検索
	if (sanshoIsKamoku()) {
		sanshoKensakuKamoku();
	} else if (sanshoIsTekiyo()) {
		sanshoKensakuTekiyo();
	} else if (sanshoIsTokuyakuten()) {
		sanshoKensakuTokuyakuten();
	} else if (sanshoIsJds()) {
		sanshoKensakuJds();
	} else if (sanshoIsInzei()) {
		sanshoKensakuInzei();
	} else if (sanshoIsShohin()) {
		sanshoKensakuShohin();
        } else if (sanshoIsProject()) {
                sanshoKensakuProject();
	} else if (sanshoIsKikaku()) {
                sanshoKensakuKikaku();
        } else if (sanshoIsHaishin()) {
		sanshoKensakuHaishin();
	} else if (sanshoIsArtist()) {
                sanshoKensakuArtist();
  } else if (sanshoIsShiharai()) {
		sanshoKensakuShiharai();
  } else if (sanshoIsKenrisha()) {
    sanshoKensakuKenrisha();
  } else if (sanshoIsKeiyaku()) {
    sanshoKensakuKeiyaku();
  } else if (sanshoIsKeiyakuEda()) {
    sanshoKensakuKeiyakuEda();
	} else if (sanshoIsAdvance()) {
    sanshoKensakuAdvance();
	} else {
		// メッセージを表示
    console.log("err  ");
		sanshoSetMessage("検索できません。", true);
		// ボタンを使用可にする
		sanshoSetButtonDisabled(false);
	}
}

/**
 * 検索のエラー処理（サーバー処理の後）
 *
 * @param message
 *            メッセージ
 * @param error
 *            エラー
 */
function respSanshoByDwrOnError(message, error) {
	// alert("onError");
	var displayMessage = "検索結果を表示できません。";
	// メッセージを表示
	sanshoSetMessage(displayMessage, true);
	// 「閉じる」以外のボタンは使用不可のままにする
}

/**
 * 検索の例外処理（サーバー処理の後）
 *
 * @param message
 *            メッセージ
 * @param exception
 *            例外
 */
function respSanshoByDwrOnException(message, exception) {
	// alert("onException");
	var displayMessage = "検索結果を表示できません。";
	// メッセージを表示
	sanshoSetMessage(displayMessage, true);
	// 「閉じる」以外のボタンは使用不可のままにする
}

/**
 * 検索の警告処理（サーバー処理の後）
 *
 * @param message
 *            メッセージ
 * @param warning
 *            警告
 */
function respSanshoByDwrOnWarning(message, warning) {
	// alert("onWarning");
	var displayMessage = "検索結果を表示できません。";
	if (warning.name == "dwr.engine.missingData") {
		// ログオンチェックエラー、IPアドレスチェックエラーの場合は、ServletFilterで空の戻りをしている。
		displayMessage = "ログオンしてください。";
	}
	// メッセージを表示
	sanshoSetMessage(displayMessage, true);
	// 「閉じる」以外のボタンは使用不可のままにする
}

/**
 * 検索処理（サーバー処理の後） 検索結果を画面に表示する
 *
 * @param resp
 *            サーバー処理の戻り値
 */
function respSanshoByDwr(resp) {
	// alert("respSanshoByDwr start");
	if (objSanshoForm == null) {
		// alert("検索中に参照画面が閉じられた。");
		return;
	}

	// alert("respSanshoByDwr 1");
	var respIndex = 0; // 検索結果の配列のインデックス

	// 区分を取得
	var kbn = resp[respIndex++];

	// alert("respSanshoByDwr 2");
	// チェック
	var cellCount = 0;
	if (sanshoIsKamoku()) {
		if (kbn == sansho_kbn_kamoku) {
			cellCount = 5;
		}
	} else if (sanshoIsTekiyo()) {
		if (kbn == sansho_kbn_tekiyo) {
			cellCount = 5;
		}
	} else if (sanshoIsTokuyakuten()) {
		if (kbn == sansho_kbn_tokuyakuten) {
			cellCount = 5;
		}
	} else if (sanshoIsJds()) {
		if (kbn == sansho_kbn_jds) {
			cellCount = 5;
		}
	} else if (sanshoIsInzei()) {
		if (kbn == sansho_kbn_inzei) {
			cellCount = 5;
		}
	} else if (sanshoIsShohin()) {
		if (kbn == sansho_kbn_shohin) {
			cellCount = 5;
		}
        } else if (sanshoIsProject()) {
                if (kbn == sansho_kbn_project) {
                        cellCount = 5;
                }
        } else if (sanshoIsKikaku()) {
                if (kbn == sansho_kbn_kikaku) {
                        cellCount = 5;
                }
        } else if (sanshoIsArtist()) {
                if (kbn == sansho_kbn_artist) {
                        cellCount = 5;
                }
        } else if (sanshoIsHaishin()) {
                if (kbn == sansho_kbn_haishin) {
                        cellCount = 5;
                }
  } else if (sanshoIsShiharai()) {
    if (kbn == sansho_kbn_shiharai) {
      cellCount = 5;
    }
  } else if (sanshoIsKenrisha()) {
		if (kbn == sansho_kbn_kenrisha) {
			cellCount = 5;
		}
  } else if (sanshoIsKeiyaku()) {
    if (kbn == sansho_kbn_keiyaku) {
      cellCount = 5;
    }
  } else if (sanshoIsKeiyakuEda()) {
    if (kbn == sansho_kbn_keiyakuEda) {
      cellCount = 5;
    }
	}else if (sanshoIsAdvance()) {
    if (kbn == sansho_kbn_advance) {
      cellCount = 5;
    }
  }
	if (cellCount == 0) {
		// alert("respSanshoByDwr 2-2");
		// alert("参照画面の種類が想定外");
		// メッセージを表示
		sanshoSetMessage("検索結果を表示できません。", true);
		// ボタンを使用可にする
		sanshoSetButtonDisabled(false);
		return;
	}
	// alert("respSanshoByDwr 3");

	// メッセージを取得
	var message = resp[respIndex++];
	// alert("respSanshoByDwr message="+message);

	// エラー発生フィールドのインデックスを取得
	var errorIndex = resp[respIndex++];

	// 検索条件のフィールドの色をクリア
	sanshoSetFieldColorNormalAll();

	// エラーのフィールドがある場合
	if (errorIndex != -1) {
		// エラーのフィールドの色をセット
		sanshoSetFieldColorError(errorIndex);
		// メッセージを取得
		sanshoSetMessage(message, true);
		// ボタンを使用可にする
		sanshoSetButtonDisabled(false);
		return;
	}

	// alert("respSanshoByDwr 4");
	var selectCount = resp[respIndex++]; // 検索結果のレコード数

	// alert("respSanshoByDwr 5");
	if (selectCount > 0) {

		// 一覧表を表示
		var pObj = sanshoGetIchiran().parentNode; // 一覧表の親ノード
		// alert("respSanshoByDwr 5. resp=["+resp[respIndex]+"]");
		// 一覧表テーブル全体を、サーバから受信したHTMLで上書き
		pObj.innerHTML = resp[respIndex++];

	} else {
		// 一覧表をクリア
		sanshoClearIchiran();
	}

	//
	// alert("respSanshoByDwr 100");
	// メッセージを表示
	sanshoSetMessage(message);
	// alert("respSanshoByDwr 101");
	// ボタンを使用可にする
	sanshoSetButtonDisabled(false);
}

// 以下、他のfunctionから呼び出されるprivateな処理 -----------------------------

/**
 * ボタンを使用可能／使用不可にする
 *
 * @param disabled
 *            使用不可にする場合true、使用可能にする場合false
 */
function sanshoSetButtonDisabled(disabled) {
	// ボタンを使用可能／使用不可にする
	objSanshoForm.elements["btnKensaku"].disabled = disabled;
	objSanshoForm.elements["btnClear"].disabled = disabled;
	//objSanshoForm.elements["btnOK"].disabled = disabled;
	// キャンセルは常に使用可能にする
	// objSanshoForm.elements["btnRefDairiCancel"].disabled = disabled;
}

/**
 * 参照画面の一覧表をクリアする
 */
function sanshoClearIchiran() {
	// alert("sanshoClearIchiran start");
	// 一覧表を表示
	var objIchiran = sanshoGetIchiran();
	var rowCount = objIchiran.rows.length;
	// alert("len="+objIchiran.rows.length);
	// 行毎に繰り返し
	for (var rowIndex = 0; rowIndex < rowCount; rowIndex++) {
		objIchiran.deleteRow(0);
	}
}

/**
 * 参照画面の一覧表の行選択チェックボックスを取得する
 *
 * @param index
 *            行インデックス
 * @return 一覧表の行選択チェックボックス
 */
function sanshoGetIchiranCheckBox(index) {
	return objSanshoForm.elements[sanshoGetIchiranCheckBoxName(index)];
}

/**
 * 参照画面の一覧表の行選択チェックボックスの名前を取得する
 *
 * @param index
 *            行インデックス
 * @return 一覧表の行選択チェックボックスの名前
 */
function sanshoGetIchiranCheckBoxName(index) {
	return "TBLchkSelect_" + index;
}

/**
 * 参照画面の一覧表のコードのテキストフィールドを取得する
 *
 * @param index
 *            行インデックス
 * @return 一覧表のコードのテキストフィールド
 */
function sanshoGetIchiranCode(index) {
	return objSanshoForm.elements[sanshoGetIchiranCodeName(index)];
}

/**
 * 参照画面の一覧表のコードのテキストフィールドを取得する
 *
 * @param index
 *            行インデックス
 * @return 一覧表のコードのテキストフィールドの名前
 */
function sanshoGetIchiranCodeName(index) {
	return "TBLcode_" + index;
}

/**
 * 参照画面の一覧表のコードのテキストフィールドを取得する
 *
 * @param index
 *            行インデックス
 * @return 一覧表のコードのテキストフィールド
 */
function sanshoGetIchiranCodeKamoku(index) {
	return objSanshoForm.elements[sanshoGetIchiranCodeNameKamoku(index)];
}

/**
 * 参照画面の一覧表のコードのテキストフィールドを取得する
 *
 * @param index
 *            行インデックス
 * @return 一覧表のコードのテキストフィールドの名前
 */
function sanshoGetIchiranCodeNameKamoku(index) {
	return "TBLcodeKamoku_" + index;
}

/**
 * 参照画面の一覧表を取得する
 *
 * @return 一覧表
 */
function sanshoGetIchiran() {
	var objIchiran = null;
	if (sanshoIsKamoku()) {
		objIchiran = document.getElementById(sansho_name_table_ichiran
				+ "Kamoku");
	} else if (sanshoIsTekiyo()) {
		objIchiran = document.getElementById(sansho_name_table_ichiran
				+ "Tekiyo");
	} else if (sanshoIsTokuyakuten()) {
		objIchiran = document.getElementById(sansho_name_table_ichiran
				+ "Tokuyakuten");
	} else if (sanshoIsJds()) {
		objIchiran = document.getElementById(sansho_name_table_ichiran
				+ "Jds");
	} else if (sanshoIsInzei()) {
		objIchiran = document.getElementById(sansho_name_table_ichiran
				+ "Inzei");
	} else if (sanshoIsShohin()) {
		objIchiran = document.getElementById(sansho_name_table_ichiran
				+ "Shohin");
	} else if (sanshoIsProject()) {
		objIchiran = document.getElementById(sansho_name_table_ichiran
				+ "Project");
	} else if (sanshoIsKikaku()) {
		objIchiran = document.getElementById(sansho_name_table_ichiran
				+ "Kikaku");
	} else if (sanshoIsHaishin()) {
		objIchiran = document.getElementById(sansho_name_table_ichiran
				+ "Haishin");
	} else if (sanshoIsArtist()) {
		objIchiran = document.getElementById(sansho_name_table_ichiran
				+ "Artist");
	} else if (sanshoIsHaishin()) {
		objIchiran = document.getElementById(sansho_name_table_ichiran
				+ "Haishin");
  } else if (sanshoIsShiharai()) {
  	objIchiran = document.getElementById(sansho_name_table_ichiran
  			+ "Shiharai");
  } else if (sanshoIsKenrisha()) {
  	objIchiran = document.getElementById(sansho_name_table_ichiran
  			+ "Kenrisha");
  } else if (sanshoIsKeiyaku()) {
  	objIchiran = document.getElementById(sansho_name_table_ichiran
  			+ "Keiyaku");
  }else if (sanshoIsKeiyakuEda()) {
  	objIchiran = document.getElementById(sansho_name_table_ichiran
  			+ "KeiyakuEda");
	}else if (sanshoIsAdvance()) {
  	objIchiran = document.getElementById(sansho_name_table_ichiran
  			+ "Advance");
	}
	return objIchiran;
}

/**
 * 参照画面のメッセージ表示欄にメッセージをセットする
 *
 * @param message
 *            メッセージ
 * @param isError
 *            エラーの場合true
 */
function sanshoSetMessage(message, isError) {
	if (arguments.length < 2) {
		isError = false;
	}
	var objMessage = null;
	if (sanshoIsKamoku()) {
		objMessage = document.getElementById(sansho_name_span_message
				+ "Kamoku");
	} else if (sanshoIsTekiyo()) {
		objMessage = document.getElementById(sansho_name_span_message
				+ "Tekiyo");
	} else if (sanshoIsTokuyakuten()) {
		objMessage = document.getElementById(sansho_name_span_message
				+ "Tokuyakuten");
	} else if (sanshoIsJds()) {
		objMessage = document.getElementById(sansho_name_span_message
				+ "Jds");
	} else if (sanshoIsInzei()) {
		objMessage = document.getElementById(sansho_name_span_message
				+ "Inzei");
	} else if (sanshoIsShohin()) {
		objMessage = document.getElementById(sansho_name_span_message
				+ "Shohin");
        } else if (sanshoIsProject()) {
                objMessage = document.getElementById(sansho_name_span_message
                                + "Project");
	} else if (sanshoIsKikaku()) {
                objMessage = document.getElementById(sansho_name_span_message
                                + "Kikaku");
	} else if (sanshoIsHaishin()) {
		objMessage = document.getElementById(sansho_name_span_message
				+ "Haishin");
	} else if (sanshoIsArtist()) {
                objMessage = document.getElementById(sansho_name_span_message
                                + "Artist");
  } else if (sanshoIsShiharai()) {
		objMessage = document.getElementById(sansho_name_span_message
				+ "Shiharai");
  } else if (sanshoIsKenrisha()) {
		objMessage = document.getElementById(sansho_name_span_message
				+ "Kenrisha");
  } else if (sanshoIsKeiyaku()) {
		objMessage = document.getElementById(sansho_name_span_message
				+ "Keiyaku");
  }else if (sanshoIsKeiyakuEda()) {
		objMessage = document.getElementById(sansho_name_span_message
				+ "KeiyakuEda");
	}else if (sanshoIsAdvance()) {
		objMessage = document.getElementById(sansho_name_span_message
				+ "Advance");
	}

	if (objMessage != null) {
		objMessage.innerHTML = message;
		if (isError) {
			objMessage.style.color = sansho_color_error;
		} else {
			objMessage.style.color = "";
		}
	} else {
		// alert("メッセージ欄が存在しない。"+sansho_name_span_message);
	}
}

/**
 * 開いている参照画面の種類が科目であるか
 *
 * @return 科目の場合true
 */
function sanshoIsKamoku() {
	if (objSanshoForm != null && objSanshoForm.id == sansho_name_form_kamoku) {
		return true;
	} else {
		return false;
	}
}

/**
 * 開いている参照画面の種類が摘要であるか
 *
 * @return 摘要の場合true
 */
function sanshoIsTekiyo() {
	if (objSanshoForm != null && objSanshoForm.id == sansho_name_form_tekiyo) {
		return true;
	} else {
		return false;
	}
}

/**
 * 開いている参照画面の種類が特約店であるか
 *
 * @return 特約店の場合true
 */
function sanshoIsTokuyakuten() {
	if (objSanshoForm != null && objSanshoForm.id == sansho_name_form_tokuyakuten) {
		return true;
	} else {
		return false;
	}
}

/**
 * 開いている参照画面の種類がJDSであるか
 *
 * @return 特約店の場合true
 */
function sanshoIsJds() {
	if (objSanshoForm != null && objSanshoForm.id == sansho_name_form_jds) {
		return true;
	} else {
		return false;
	}
}


/**
 * 開いている参照画面の種類が印税であるか
 *
 * @return 印税の場合true
 */
function sanshoIsInzei() {
	if (objSanshoForm != null && objSanshoForm.id == sansho_name_form_inzei) {
		return true;
	} else {
		return false;
	}
}

/**
 * 開いている参照画面の種類が商品であるか
 *
 * @return 商品の場合true
 */
function sanshoIsShohin() {
	if (objSanshoForm != null && objSanshoForm.id == sansho_name_form_shohin) {
		return true;
	} else {
		return false;
	}
}
/**
 * 開いている参照画面の種類が企画であるか
 *
 * @return 商品の場合true
 */
function sanshoIsKikaku() {
	if (objSanshoForm != null && objSanshoForm.id == sansho_name_form_kikaku) {
		return true;
	} else {
		return false;
	}
}
/**
 * 開いている参照画面の種類がProjectであるか
 *
 * @return Projectの場合true
 */
function sanshoIsProject() {
	if (objSanshoForm != null && objSanshoForm.id == sansho_name_form_project) {
		return true;
	} else {
		return false;
	}
}
/**
 * 開いている参照画面の種類が配信であるか
 *
 * @return 配信の場合true
 */
function sanshoIsHaishin() {
	if (objSanshoForm != null && objSanshoForm.id == sansho_name_form_haishin) {
		return true;
	} else {
		return false;
	}
}
/**
 * 開いている参照画面の種類がアーチストであるか
 *
 * @return 商品の場合true
 */
function sanshoIsArtist() {
	if (objSanshoForm != null && objSanshoForm.id == sansho_name_form_artist) {
		return true;
	} else {
		return false;
	}
}
/**
 * 開いている参照画面の種類が支払であるか
 *
 * @return 支払の場合true
 */
function sanshoIsShiharai() {
	if (objSanshoForm != null && objSanshoForm.id == sansho_name_form_shiharai) {
		return true;
	} else {
		return false;
	}
}
/**
 * 開いている参照画面の種類が権利者であるか
 *
 * @return 権利者の場合true
 */
function sanshoIsKenrisha() {
	if (objSanshoForm != null && objSanshoForm.id == sansho_name_form_kenrisha) {
		return true;
	} else {
		return false;
	}
}
/**
 * 開いている参照画面の種類が契約番号であるか
 *
 * @return 契約番号の場合true
 */
function sanshoIsKeiyaku() {
	if (objSanshoForm != null && objSanshoForm.id == sansho_name_form_keiyaku) {
		return true;
	} else {
		return false;
	}
}

/**
 * 開いている参照画面の種類が契約番号であるか
 *
 * @return 契約番号の場合true
 */
function sanshoIsKeiyakuEda() {
	if (objSanshoForm != null && objSanshoForm.id == sansho_name_form_keiyakuEda) {
		return true;
	} else {
		return false;
	}
}

/**
 * 開いている参照画面の種類がアドバンスであるか
 *
 * @return アドバンスの場合true
 */
function sanshoIsAdvance() {
	if (objSanshoForm != null && objSanshoForm.id == sansho_name_form_advance) {
		return true;
	} else {
		return false;
	}
}

/**
 * システム日付を取得する
 *
 * @return システム日付の配列{年,月,日}
 */
function sanshoGetSystemDate() {
	var current = new Date();
	return new Array(current.getYear(), current.getMonth() + 1, current
			.getDate());
}

/**
 * ラジオボタンの選択したvalueを取得する
 *
 * @param obj
 *            ラジオボタン
 * @return 選択したvalue
 */
function sanshoGetRadiobuttonValue(obj) {
	var value = "";
	if (obj != null) {
		for (var i = 0; i < obj.length; i++) {
			if (obj[i].checked) {
				value = obj[i].value;
			}
		}
	}
	return value;
}

/**
 * フィールドに通常の色をセットする
 *
 * @param index
 *            フィールドのインデックス番号
 * @param color
 *            色
 */
function sanshoSetFieldColor(index, color) {
	if (sanshoIsKamoku()) {
		sanshoSetFieldColorKamoku(index, color);
	} else if (sanshoIsTekiyo()) {
		sanshoSetFieldColorTekiyo(index, color);
	} else if (sanshoIsTokuyakuten()) {
		sanshoSetFieldColorTokuyakuten(index, color);
	} else if (sanshoIsJds()) {
		sanshoSetFieldColorJds(index, color);
	} else if (sanshoIsInzei()) {
		sanshoSetFieldColorInzei(index, color);
	} else if (sanshoIsShohin()) {
		sanshoSetFieldColorShohin(index, color);
	} else if (sanshoIsProject()) {
		sanshoSetFieldColorProject(index, color);
	} else if (sanshoIsKikaku()) {
		sanshoSetFieldColorKikaku(index, color);
	} else if (sanshoIsHaishin()) {
		sanshoSetFieldColorHaishin(index, color);
  } else if (sanshoIsArtist()) {
		sanshoSetFieldColorArtist(index, color);
  } else if (sanshoIsShiharai()) {
		sanshoSetFieldColorShiharai(index, color);
  } else if (sanshoIsKenrisha()) {
    sanshoSetFieldColorKenrisha(index, color);
  } else if (sanshoIsKeiyaku()) {
		sanshoSetFieldColorKeiyaku(index, color);
  } else if (sanshoIsKeiyakuEda()) {
		sanshoSetFieldColorKeiyakuEda(index, color);
	}else if (sanshoIsAdvance()) {
		sanshoSetFieldColorAdvance(index, color);
	}
}

/**
 * フィールドに通常の色をセットする
 *
 * @param color
 *            色
 */
function sanshoSetFieldColorAll(color) {
	if (sanshoIsKamoku()) {
		sanshoSetFieldColorKamokuAll(color);
	} else if (sanshoIsTekiyo()) {
		sanshoSetFieldColorTekiyoAll(color);
	} else if (sanshoIsTokuyakuten()) {
		sanshoSetFieldColorTokuyakutenAll(color);
	} else if (sanshoIsJds()) {
		sanshoSetFieldColorJdsAll(color);
	} else if (sanshoIsInzei()) {
		sanshoSetFieldColorInzeiAll(color);
	} else if (sanshoIsShohin()) {
		sanshoSetFieldColorShohinAll(color);
	} else if (sanshoIsProject()) {
		sanshoSetFieldColorProjectAll(color);
	} else if (sanshoIsKikaku()) {
		sanshoSetFieldColorKikakuAll(color);
	} else if (sanshoIsHaishin()) {
		sanshoSetFieldColorHaishinAll(color);
	} else if (sanshoIsArtist()) {
		sanshoSetFieldColorArtistAll(color);
  } else if (sanshoIsShiharai()) {
		sanshoSetFieldColorShiharaiAll(color);
  } else if (sanshoIsKenrisha()) {
		sanshoSetFieldColorKenrishaAll(color);
  } else if (sanshoIsKeiyaku()) {
		sanshoSetFieldColorKeiyakuAll(color);
  } else if (sanshoIsKeiyakuEda()) {
		sanshoSetFieldColorKeiyakuEdaAll(color);
  }else if (sanshoIsAdvance()) {
		sanshoSetFieldColorAdvanceAll(color);
  }
}

/**
 * フィールドにエラーを示す色をセットする
 *
 * @param index
 *            フィールドのインデックス番号
 */
function sanshoSetFieldColorError(index) {
	sanshoSetFieldColor(index, sansho_color_error);
}

/**
 * フィールドに通常の色をセットする
 *
 * @param index
 *            フィールドのインデックス番号
 */
function sanshoSetFieldColorNormal(index) {
	sanshoSetFieldColor(index, "");
}

/**
 * フィールドに通常の色をセットする
 */
function sanshoSetFieldColorNormalAll() {
	sanshoSetFieldColorAll("");
}

/**
 * 背景色をセットする
 *
 * @param obj
 *            項目
 * @param color
 *            色
 */
function sanshoSetBackgroundColor(obj, color) {
	//alert(obj);
	obj.style.backgroundColor = color;
}

// 以下、画面の種類により内容が異なる処理 --------------------------------------

/**
 * 参照画面のボタン処理 クリア 印税
 */
function sanshoClearInzei() {
	// alert("sanshoClear start");
	objSanshoForm.elements["fldSanshoInzeiGeimeikanji"].value = "";
	objSanshoForm.elements["fldSanshoInzeiGeimeikana"].value = "";
	objSanshoForm.elements["fldSanshoInzeiKouzameigijin"].value = "";
}
/**
 * 参照画面ボタン処理 検索 印税
 */
function sanshoKensakuInzei() {
	// alert("sanshoKensakuInzei start");
	// ★★モック
	respSanshoByDwr(new Array(
			"I",
			"検索しました。",
			-1,
			2,
			"<table class=\"table_main\" id=\"tableSanshoInzei\" width=\"600px\" >"
					+ "<tr ><td width=\"30px\" align=\"center\">1</td><td width=\"70px\" align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('NII1001');\"></td><td width=\"100px\">NII1001</td><td width=\"200px\">ＹＹＹＹＹＹＹＹＹ１ＹＹＹＹＹＹＹＹＹ２<input type=\"hidden\" name=\"TBLcode_0\" id=\"TBLcode_0\" value=\"ＹＹＹＹＹＹＹＹＹ１ＹＹＹＹＹＹＹＹＹ２\"></td><td width=\"200px\">ＹＹＹＹＹＹＹＹＹ１ＹＹＹＹＹＹＹＹＹ２</td></tr>"
					+ "<tr ><td align=\"center\">2</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('NII1234');\"></td><td>NII1234</td><td>ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２<input type=\"hidden\" name=\"TBLcode_1\" id=\"TBLcode_1\" value=\"ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２\"></td><td>ＹＹＹＹＹＹＹＹＹ１ＹＹＹＹＹＹＹＹＹ２</td></tr>"
					+ "<tr ><td align=\"center\">3</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('NII1235');\"></td><td>NII1235</td><td>日本テレビ情報産業<input type=\"hidden\" name=\"TBLcode_2\" id=\"TBLcode_2\" value=\"日本テレビ情報産業\"></td><td>ニホンテレビケイリブ</td></tr>"
					+ "<tr ><td align=\"center\">4</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('NII1240');\"></td><td>NII1240</td><td>日本アニメ情報産業<input type=\"hidden\" name=\"TBLcode_3\" id=\"TBLcode_3\" value=\"日本アニメ情報産業\"></td><td>ニホンテレビケイリブ</td></tr>"
					+ "<tr ><td align=\"center\">5</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('NII1250');\"></td><td>NII1250</td><td>ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２<input type=\"hidden\" name=\"TBLcode_4\" id=\"TBLcode_4\" value=\"ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２\"></td><td>ＹＹＹＹＹＹＹＹＹ１ＹＹＹＹＹＹＹＹＹ２</td></tr>"
					+ "<tr ><td align=\"center\">6</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('NII1777');\"></td><td>NII1777</td><td>ＺＺＺＺＺＺＺＺＺ１ＺＺＺＺＺＺＺＺＺ２<input type=\"hidden\" name=\"TBLcode_5\" id=\"TBLcode_5\" value=\"ＺＺＺＺＺＺＺＺＺ１ＺＺＺＺＺＺＺＺＺ２\"></td><td>ＹＹＹＹＹＹＹＹＹ１ＹＹＹＹＹＹＹＹＹ２</td></tr>"
					+ "</table>"));
}

/**
 * フィールドに色をセットする 印税
 *
 * @param index
 *            フィールドのインデックス番号
 * @param color
 *            色
 */
function sanshoSetFieldColorInzei(index, color) {
	if (index == 0) {
		// sanshoSetBackgroundColor(objSanshoForm.elements[sansho_name_txt_dairiten_code],
		// color);
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoInzeiGeimeikanji"], color);
	} else if (index == 1) {
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoInzeiGeimeikana"], color);
	} else if (index == 2) {
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoInzeiKouzameigijin"],
				color);
	}
}

/**
 * フィールドに色をセットする 印税
 *
 * @param color
 *            色
 */
function sanshoSetFieldColorInzeiAll(color) {
	for (var i = 0; i <= 4; i++) {
		sanshoSetFieldColorInzei(i, color);
	}
}

/**
 * 参照画面のボタン処理 クリア 商品
 */
function sanshoClearShohin() {
	// alert("sanshoClear start");
  objSanshoForm.elements["fldSanshoShohinCode"].value = "";
	objSanshoForm.elements["fldSanshoShohinCodeFrom"].value = "";
	objSanshoForm.elements["fldSanshoShohinCodeTo"].value = "";
	objSanshoForm.elements["fldSanshoShohinHatubaihiFrom"].value = "";
	objSanshoForm.elements["fldSanshoShohinHatubaihiTo"].value = "";
	objSanshoForm.elements["fldSanshoShohinTitleKanji"].value = "";
  objSanshoForm.elements["fldSanshoShohinTitleKana"].value = "";
	objSanshoForm.elements["fldSanshoShohinArtistKanji"].value = "";
  objSanshoForm.elements["fldSanshoShohinArtistKana"].value = "";
}
/**
 * 参照画面ボタン処理 検索 商品
 */
function sanshoKensakuShohin() {
	// ★★モック
	respSanshoByDwr(new Array(
			"S",
			"検索しました。",
			-1,
			2,
			"<table class=\"table_main\" id=\"tableSanshoShohin\" width=\"990px\" >"
					+ "<tr ><td width=\"20px\" align=\"center\">1</td><td width=\"70px\" align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('VPBT  123456X');\"></td><td width=\"100px\">VPBT  123456X</td><td width=\"200px\">ＹＹＹＹＹＹＹＹＹ１ＹＹＹＹＹＹＹＹＹ２</td><td width=\"150px\">YYYYYYYYY1YYYYYYYYY2</td><td width=\"200px\">ＹＹＹＹＹＹＹＹＹ１ＹＹＹＹＹＹＹＹＹ２</td><td width=\"150px\">YYYYYYYYY1YYYYYYYYY2</td><td width=\"100px\">yyyy/mm/dd</td></tr>"
					+ "<tr ><td align=\"center\">2</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('VPBT  123457X');\"></td><td>VPBT  123457X</td><td>ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td><td>XXXXXXXXX1XXXXXXXXX2</td><td>ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td><td>XXXXXXXXX1XXXXXXXXX2</td><td>2019/02/03</td></tr>"
					+ "<tr ><td align=\"center\">3</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('VPBT  123458X');\"></td><td>VPBT  123458X</td><td>アンパンマン劇場版</td><td>ｱﾝﾊﾟﾝﾏﾝｹﾞｷｼﾞｮｳﾊﾞﾝ</td><td></td><td></td><td>2019/02/03</td></tr>"
					+ "<tr ><td align=\"center\">4</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('VPBT  123459X');\"></td><td>VPBT  123459X</td><td>NOGIBINGO！</td><td>NOGIBINGO!</td><td>乃木坂４６</td><td>ﾉｷﾞｻﾞｶ46</td><td>2019/02/03</td></tr>"
					+ "<tr ><td align=\"center\">5</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('VPBT  123460X');\"></td><td>VPBT  123460X</td><td>ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td><td>XXXXXXXXX1XXXXXXXXX2</td><td>ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td><td>XXXXXXXXX1XXXXXXXXX2</td><td>2019/02/03</td></tr>"
					+ "<tr ><td align=\"center\">6</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('VPBT  123461X');\"></td><td>VPBT  123461X</td><td>ＺＺＺＺＺＺＺＺＺ１ＺＺＺＺＺＺＺＺＺ２</td><td>ZZZZZZZZZ1ZZZZZZZZZ2</td><td>ＺＺＺＺＺＺＺＺＺ１ＺＺＺＺＺＺＺＺＺ２</td><td>ZZZZZZZZZ1ZZZZZZZZZ2</td><td>2019/02/03</td></tr>"
					+ "</table>"));
}

/**
 * フィールドに色をセットする 商品
 *
 * @param index
 *            フィールドのインデックス番号
 * @param color
 *            色
 */
function sanshoSetFieldColorShohin(index, color) {
	if (index == 0) {
		// sanshoSetBackgroundColor(objSanshoForm.elements[sansho_name_txt_dairiten_code],
		// color);
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoShohinCodeFrom"], color);
	} else if (index == 1) {
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoShohinCodeTo"], color);
	} else if (index == 2) {
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoShohinHatubaihiFrom"], color);
	} else if (index == 3) {
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoShohinHatubaihiTo"], color);
	}
}

/**
 * フィールドに色をセットする 商品
 *
 * @param color
 *            色
 */
function sanshoSetFieldColorShohinAll(color) {
	for (var i = 0; i <= 4; i++) {
		sanshoSetFieldColorShohin(i, color);
	}
}

/**
 * 参照画面のボタン処理 クリア 配信
 */
function sanshoClearHaishin() {
	// alert("sanshoClear start");
	objSanshoForm.elements["fldSanshoHaishinCode"].value = "";
  objSanshoForm.elements["fldSanshoHaishinCodeFrom1"].value = "";
  objSanshoForm.elements["fldSanshoHaishinCodeFrom2"].value = "";
  objSanshoForm.elements["fldSanshoHaishinCodeTo1"].value = "";
  objSanshoForm.elements["fldSanshoHaishinCodeTo2"].value = "";
	objSanshoForm.elements["fldSanshoHaishinHatubaihiFrom"].value = "";
	objSanshoForm.elements["fldSanshoHaishinHatubaihiTo"].value = "";
	objSanshoForm.elements["fldSanshoHaishinTitleKanji"].value = "";
  objSanshoForm.elements["fldSanshoHaishinTitleKana"].value = "";
	objSanshoForm.elements["fldSanshoHaishinArtistKanji"].value = "";
  objSanshoForm.elements["fldSanshoHaishinArtistKana"].value = "";
  objSanshoForm.elements["fldSanshoHaishinISRC"].value = "";
  objSanshoForm.elements["fldSanshoHaishinUPCコード"].value = "";
}
/**
 * 参照画面ボタン処理 検索 配信
 */
function sanshoKensakuHaishin() {
	// ★★モック
	respSanshoByDwr(new Array(
			"H",
			"検索しました。",
			-1,
			2,
			"<table class=\"table_main\" id=\"tableSanshoHaishin\" width=\"1310px\" >"
					+ "<tr ><td width=\"20px\" align=\"center\">1</td><td width=\"70px\" align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('VPBT 12345XX-123456');\"></td><td width=\"150px\">VPBT 12345XX-123456</td><td width=\"200px\">ＹＹＹＹＹＹＹＹＹ１ＹＹＹＹＹＹＹＹＹ２</td><td width=\"150px\">XXXXXXXXX1XXXXXXXXX2</td><td width=\"200px\">ＹＹＹＹＹＹＹＹＹ１ＹＹＹＹＹＹＹＹＹ２</td><td width=\"150px\">XXXXXXXXX1XXXXXXXXX2</td><td width=\"100px\">yyyy/mm/dd</td><td width=\"100px\">XXXXXXXXX1XXXXX</td><td width=\"120px\" style=\"background-Color:#E6E6E6\">XXXXXXXXX1XXXX</td></tr>"
					+ "<tr ><td align=\"center\">2</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('VPBT 12346XX-123456');\"></td><td>VPBT 12346XX-123456</td><td>ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td><td>XXXXXXXXX1XXXXXXXXX2</td><td>ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td><td>XXXXXXXXX1XXXXXXXXX2</td><td>2019/02/03</td><td width=\"130px\">123456789012XXX</td><td width=\"120px\"style=\"background-Color:#E6E6E6\">12345678901234</td></tr>"
					+ "<tr ><td align=\"center\">3</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('VPBT 12347XX-123456');\"></td><td>VPBT 12347XX-123456</td><td>アンパンマン劇場版</td><td>ｱﾝﾊﾟﾝﾏﾝｹﾞｷｼﾞｮｳﾊﾞﾝ</td><td></td><td></td><td>2019/02/03</td><td width=\"130px\">123456789012XXX</td><td width=\"120px\"style=\"background-Color:#E6E6E6\">12345678901234</td></tr>"
					+ "<tr ><td align=\"center\">4</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('VPBT 12348XX-123456');\"></td><td>VPBT 12348XX-123456</td><td>NOGIBINGO！</td><td>NOGIBINGO!</td><td>乃木坂４６</td><td>ﾉｷﾞｻﾞｶ46</td><td>2019/02/03</td><td width=\"130px\">123456789012XXX</td><td width=\"120px\"style=\"background-Color:#E6E6E6\">12345678901234</td></tr>"
					+ "<tr ><td align=\"center\">5</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('VPBT 12349XX-123456');\"></td><td>VPBT 12349XX-123456</td><td>ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td><td>XXXXXXXXX1XXXXXXXXX2</td><td>ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td><td>XXXXXXXXX1XXXXXXXXX2</td><td>2019/02/03</td><td width=\"130px\">XXXXXXXXX1XXXXX</td><td width=\"120px\"style=\"background-Color:#E6E6E6\">XXXXXXXXX1XXXX</td></tr>"
					+ "<tr ><td align=\"center\">6</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('VPBT 12350XX-123456');\"></td><td>VPBT 12350XX-123456</td><td>ＺＺＺＺＺＺＺＺＺ１ＺＺＺＺＺＺＺＺＺ２</td><td>XXXXXXXXX1XXXXXXXXX2</td><td>ＺＺＺＺＺＺＺＺＺ１ＺＺＺＺＺＺＺＺＺ２</td><td>XXXXXXXXX1XXXXXXXXX2</td><td>2019/02/03</td><td width=\"130px\">XXXXXXXXX1XXXXX</td><td width=\"120px\"style=\"background-Color:#E6E6E6\">XXXXXXXXX1XXXX</td></tr>"
					+ "</table>"));
}

/**
 * フィールドに色をセットする 配信
 *
 * @param index
 *            フィールドのインデックス番号
 * @param color
 *            色
 */
function sanshoSetFieldColorHaishin(index, color) {
	if (index == 0) {
		// sanshoSetBackgroundColor(objSanshoForm.elements[sansho_name_txt_dairiten_code],
		// color);
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoHaishinCode"], color);
  } else if (index == 1) {
    sanshoSetBackgroundColor(
        objSanshoForm.elements["fldSanshoHaishinCodeFrom1"], color);
  } else if (index == 2) {
    sanshoSetBackgroundColor(
        objSanshoForm.elements["fldSanshoHaishinCodeFrom2"], color);
  } else if (index == 3) {
    sanshoSetBackgroundColor(
        objSanshoForm.elements["fldSanshoHaishinCodeTo1"], color);
	} else if (index == 4) {
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoHaishinCodeTo2"], color);
	} else if (index == 5) {
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoHaishinHatubaihiFrom"], color);
	} else if (index == 6) {
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoHaishinHatubaihiTo"], color);
	}
}

/**
 * フィールドに色をセットする 配信
 *
 * @param color
 *            色
 */
function sanshoSetFieldColorHaishinAll(color) {
	for (var i = 0; i <= 4; i++) {
		sanshoSetFieldColorHaishin(i, color);
	}
}

/**
 * 参照画面のボタン処理 クリア 特約店
 */
function sanshoClearTokuyakuten() {
	// alert("sanshoClear start");
	objSanshoForm.elements["fldSanshoTokuyakutenCodeFrom"].value = "";
	objSanshoForm.elements["fldSanshoTokuyakutenCodeTo"].value = "";
	objSanshoForm.elements["fldSanshoTokuyakutenMeisho"].value = "";
}
/**
 * 参照画面ボタン処理 検索 特約店
 */
function sanshoKensakuTokuyakuten() {
	// alert("sanshoKensakuTokuyakuten start");
	// ★★モック
	respSanshoByDwr(new Array(
			"T",
			"検索しました。",
			-1,
			2,
			"<table class=\"table_main\" id=\"tableSanshoTokuyakuten\" width=\"590px\" >"
					+ "<tr ><td width=\"20px\" align=\"center\">1</td><td width=\"70px\" align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('270001');\"></td><td width=\"115px\">270001</td><td width=\"115px\">00036329</td><td>ＷＷＷＷＷＷＷＷＷ１ＷＷＷＷＷＷＷＷＷ２</tr>"
					+ "<tr ><td align=\"center\">2</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('270002');\"></td><td>270002</td><td>00011016</td><td>ＷＷＷＷＷＷＷＷＷ１ＷＷＷＷＷＷＷＷＷ２</tr>"
					+ "<tr ><td align=\"center\">3</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('270003');\"></td><td>270003</td><td>00033333</td><td>ＷＷＷＷＷＷＷＷＷ１ＷＷＷＷＷＷＷＷＷ２</tr>"
					+ "<tr ><td align=\"center\">4</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('270004');\"></td><td>270004</td><td>00048028</td><td>ＷＷＷＷＷＷＷＷＷ１ＷＷＷＷＷＷＷＷＷ２</tr>"
					+ "<tr ><td align=\"center\">5</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('270005');\"></td><td>270005</td><td>00099999</td><td>ＷＷＷＷＷＷＷＷＷ１ＷＷＷＷＷＷＷＷＷ２</tr>"
					+ "<tr ><td align=\"center\">6</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('270006');\"></td><td>270006</td><td>00011111</td><td>ＷＷＷＷＷＷＷＷＷ１ＷＷＷＷＷＷＷＷＷ２</tr>"
					+ "</table>"));
}
/**
 * フィールドに色をセットする 特約店
 *
 * @param index
 *            フィールドのインデックス番号
 * @param color
 *            色
 */
function sanshoSetFieldColorTokuyakuten(index, color) {
	if (index == 0) {
		// sanshoSetBackgroundColor(objSanshoForm.elements[sansho_name_txt_dairiten_code],
		// color);
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoTokuyakutenCodeFrom"], color);
	} else if (index == 1) {
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoTokuyakutenCodeTo"], color);
	} else if (index == 2) {
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoTokuyakutenMeisho"],
				color);
	}
}
/**
 * フィールドに色をセットする 特約店
 *
 * @param color
 *            色
 */
function sanshoSetFieldColorTokuyakutenAll(color) {
	for (var i = 0; i <= 4; i++) {
		sanshoSetFieldColorTokuyakuten(i, color);
	}
}


/**
 * 参照画面のボタン処理 クリア JDS
 */
function sanshoClearJds() {
	// alert("sanshoClear start");

}
/**
 * 参照画面ボタン処理 検索 特約店
 */
function sanshoKensakuJds() {
	// alert("sanshoKensakuJds start");
	// ★★モック
	respSanshoByDwr(new Array(
			"J",
			"検索しました。",
			-1,
			2,
			"<table class=\"table_main\" id=\"tableSanshoJds\" width=\"590px\" >"
					+ "<tr ><td width=\"20px\" align=\"center\">1</td><td width=\"70px\" align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('00036329');\"></td><td width=\"70px\" align=\"center\">00036329</td><td width=\"70px\" align=\"center\">001</td><td width=\"90px\" align=\"center\">270001</td><td>ＷＷＷＷＷＷＷＷＷ１ＷＷＷＷＷＷＷＷＷ２</tr>"
					+ "<tr ><td align=\"center\">2</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('00011016');\"></td><td align=\"center\">00011016</td><td align=\"center\">002</td><td align=\"center\">270002</td><td>ＷＷＷＷＷＷＷＷＷ１ＷＷＷＷＷＷＷＷＷ２</tr>"
					+ "<tr ><td align=\"center\">3</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('00033333');\"></td><td align=\"center\">00033333</td><td align=\"center\">&ensp;</td><td align=\"center\">270003</td><td>ＷＷＷＷＷＷＷＷＷ１ＷＷＷＷＷＷＷＷＷ２</tr>"
					+ "<tr ><td align=\"center\">4</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('00048028');\"></td><td align=\"center\">00048028</td><td align=\"center\">&ensp;</td><td align=\"center\">270004</td><td>ＷＷＷＷＷＷＷＷＷ１ＷＷＷＷＷＷＷＷＷ２</tr>"
					+ "<tr ><td align=\"center\">5</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('00099999');\"></td><td align=\"center\">00099999</td><td align=\"center\">&ensp;</td><td align=\"center\">270005</td><td>ＷＷＷＷＷＷＷＷＷ１ＷＷＷＷＷＷＷＷＷ２</tr>"
					+ "<tr ><td align=\"center\">6</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('00011111');\"></td><td align=\"center\">00011111</td><td align=\"center\">&ensp;</td><td align=\"center\">270006</td><td>ＷＷＷＷＷＷＷＷＷ１ＷＷＷＷＷＷＷＷＷ２</tr>"
					+ "</table>"));
}
/**
 * フィールドに色をセットする JDS
 *
 * @param index
 *            フィールドのインデックス番号
 * @param color
 *            色
 */
function sanshoSetFieldColorJds(index, color) {
	/*if (index == 0) {
		// sanshoSetBackgroundColor(objSanshoForm.elements[sansho_name_txt_dairiten_code],
		// color);
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoJdsCodeFrom"], color);
	} else if (index == 1) {
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoJdsCodeTo"], color);
	} else if (index == 2) {
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoJdsMeisho"],
				color);
	}*/
}
/**
 * フィールドに色をセットする JDS
 *
 * @param color
 *            色
 */
function sanshoSetFieldColorJdsAll(color) {
	for (var i = 0; i <= 4; i++) {
		sanshoSetFieldColorJds(i, color);
	}
}

/**
 * 参照画面のボタン処理 クリア 企画
 */
function sanshoClearKikaku() {
	// alert("sanshoClear start");
	objSanshoForm.elements["fldSanshoKikakuCodeFrom"].value = "";
	objSanshoForm.elements["fldSanshoKikakuCodeTo"].value = "";
	objSanshoForm.elements["KikakuName"].value = "";
}
/**
 * 参照画面ボタン処理 検索 企画
 */
function sanshoKensakuKikaku() {
	// ★★モック
	respSanshoByDwr(new Array(
			"K",
			"検索しました。",
			-1,
			2,
			"<table class=\"table_main\" id=\"tableSanshoKikaku\" width=\"700px\" >"
					+ "<tr ><td width=\"20px\" align=\"center\">1</td><td width=\"70px\" align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('K123456');\"></td><td width=\"100px\">K123456</td><td width=\"400px\">ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td></tr>"
					+ "<tr ><td align=\"center\">2</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('K123457');\"></td><td>K123457</td><td><div style='overflow:hidden; width:400px' title='ＺＺＺＺＺＺＺＺＺ１ＺＺＺＺＺＺＺＺＺ２'>ＺＺＺＺＺＺＺＺＺ１ＺＺＺＺＺＺＺＺＺ２</div></td></tr>"
					+ "<tr ><td align=\"center\">3</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('K123458');\"></td><td>K123458</td><td><div style='overflow:hidden; width:400px' title='ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２'>ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</div></td></tr>"
					+ "<tr ><td align=\"center\">4</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('K123459');\"></td><td>K123459</td><td><div style='overflow:hidden; width:400px' title='ＺＺＺＺＺＺＺＺＺ１ＺＺＺＺＺＺＺＺＺ２'>ＺＺＺＺＺＺＺＺＺ１ＺＺＺＺＺＺＺＺＺ２</div></td></tr>"
					+ "<tr ><td align=\"center\">5</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('K123460');\"></td><td>K123460</td><td><div style='overflow:hidden; width:400px' title='ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２'>ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</div></td></tr>"
					+ "<tr ><td align=\"center\">6</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('K123461');\"></td><td>K123461</td><td><div style='overflow:hidden; width:400px' title='ＺＺＺＺＺＺＺＺＺ１ＺＺＺＺＺＺＺＺＺ２ＺＺＺＺＺＺＺＺＺ３ＺＺＺＺＺＺＺＺＺ４ＺＺＺＺＺＺＺＺＺ５ＺＺＺＺＺＺＺＺＺ６ＺＺＺＺＺＺＺＺＺ７ＺＺＺＺＺＺＺＺＺ８ＺＺＺＺＺＺＺＺＺ９ＺＺＺＺＺＺＺＺ１０ＺＺＺＺＺＺＺＺＺ１ＺＺＺＺＺＺＺＺＺ２ＺＺＺＺＺＺＺＺＺ３ＺＺＺＺＺＺＺＺＺ４ＺＺＺＺＺＺＺＺＺ５ＺＺＺＺＺＺＺＺＺ６ＺＺＺＺＺＺＺＺＺ７ＺＺＺＺＺＺＺＺＺ８ＺＺＺＺＺＺＺＺＺ９ＺＺＺＺＺＺＺＺ１０'>ＺＺＺＺＺＺＺＺＺ１ＺＺＺＺＺＺＺＺＺ２ＺＺＺＺＺＺＺＺＺ３ＺＺＺＺＺＺＺＺＺ４ＺＺＺＺＺＺＺＺＺ５ＺＺＺＺＺＺＺＺＺ６ＺＺＺＺＺＺＺＺＺ７ＺＺＺＺＺＺＺＺＺ８ＺＺＺＺＺＺＺＺＺ９ＺＺＺＺＺＺＺＺ１０ＺＺＺＺＺＺＺＺＺ１ＺＺＺＺＺＺＺＺＺ２ＺＺＺＺＺＺＺＺＺ３ＺＺＺＺＺＺＺＺＺ４ＺＺＺＺＺＺＺＺＺ５ＺＺＺＺＺＺＺＺＺ６ＺＺＺＺＺＺＺＺＺ７ＺＺＺＺＺＺＺＺＺ８ＺＺＺＺＺＺＺＺＺ９ＺＺＺＺＺＺＺＺ１０</div></td></tr>"
					+ "</table>"));
}

/**
 * フィールドに色をセットする 企画
 *
 * @param index
 *            フィールドのインデックス番号
 * @param color
 *            色
 */
function sanshoSetFieldColorKikaku(index, color) {
	if (index == 0) {
		// sanshoSetBackgroundColor(objSanshoForm.elements[sansho_name_txt_dairiten_code],
		// color);
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoKikakuCodeFrom"], color);
	} else if (index == 1) {
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoKikakuCodeTo"], color);
	} else if (index == 2) {
		sanshoSetBackgroundColor(
				objSanshoForm.elements["KikakuName"], color);
	}
}

/**
 * フィールドに色をセットする 企画
 *
 * @param color
 *            色
 */
function sanshoSetFieldColorKikakuAll(color) {
	for (var i = 0; i <= 4; i++) {
		sanshoSetFieldColorKikaku(i, color);
	}
}

/**
 * 参照画面のボタン処理 クリア Project
 */
function sanshoClearProject() {
	// alert("sanshoClear start");
	objSanshoForm.elements["fldSanshoProjectCodeFrom"].value = "";
	objSanshoForm.elements["fldSanshoProjectCodeTo"].value = "";
	objSanshoForm.elements["fldSanshoProjectTitle"].value = "";
}
/**
 * 参照画面ボタン処理 検索 Project
 */
function sanshoKensakuProject() {
	// ★★モック
	respSanshoByDwr(new Array(
			"P",
			"検索しました。",
			-1,
			2,
			"<table class=\"table_main\" id=\"tableSanshoProject\" width=\"490px\" >"
					+ "<tr ><td width=\"20px\" align=\"center\">1</td><td width=\"70px\" align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('P12345');\"></td><td width=\"150px\">P12345</td><td width=\"250px\">ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td></tr>"
					+ "<tr ><td align=\"center\">2</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('P12346');\"></td><td>P12346</td><td>ＺＺＺＺＺＺＺＺＺ１ＺＺＺＺＺＺＺＺＺ２</td></tr>"
					+ "<tr ><td align=\"center\">3</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('P12347');\"></td><td>P12347</td><td>２０世紀少年</td></tr>"
					+ "<tr ><td align=\"center\">4</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('P12348');\"></td><td>P12348</td><td>２４時間テレビドラマスペシャル</td></tr>"
					+ "<tr ><td align=\"center\">5</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('P12349');\"></td><td>P12349</td><td>ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td></tr>"
					+ "<tr ><td align=\"center\">6</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('P12350');\"></td><td>P12350</td><td>ＺＺＺＺＺＺＺＺＺ１ＺＺＺＺＺＺＺＺＺ２</td></tr>"
					+ "</table>"));
}

/**
 * フィールドに色をセットする Project
 *
 * @param index
 *            フィールドのインデックス番号
 * @param color
 *            色
 */
function sanshoSetFieldColorProject(index, color) {
	if (index == 0) {
		// sanshoSetBackgroundColor(objSanshoForm.elements[sansho_name_txt_dairiten_code],
		// color);
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoProjectCodeFrom"], color);
	} else if (index == 1) {
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoProjectCodeTo"], color);
	} else if (index == 2) {
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoProjectTitle"], color);
        }
}

/**
 * フィールドに色をセットする Project
 *
 * @param color
 *            色
 */
function sanshoSetFieldColorProjectAll(color) {
	for (var i = 0; i <= 4; i++) {
		sanshoSetFieldColorProject(i, color);
	}
}

/**
 * 参照画面のボタン処理 クリア アーチスト
 */
function sanshoClearArtist() {
	// alert("sanshoClear start");
	objSanshoForm.elements["fldSanshoArtistCodeFrom"].value = "";
	objSanshoForm.elements["fldSanshoArtistCodeTo"].value = "";
	objSanshoForm.elements["ArtistTaitoru"].value = "";
}
/**
 * 参照画面ボタン処理 検索 アーチスト
 */
function sanshoKensakuArtist() {
	// ★★モック
	respSanshoByDwr(new Array(
			"A",
			"検索しました。",
			-1,
			2,
			"<table class=\"table_main\" id=\"tableSanshoArtist\" width=\"550px\" >"
					+ "<tr ><td width=\"20px\" align=\"center\">1</td><td width=\"70px\" align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('A12345');\"></td><td width=\"100px\">A12345</td><td width=\"250px\">ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td></tr>"
					+ "<tr ><td align=\"center\">2</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('A12346');\"></td><td>A12346</td><td>ＺＺＺＺＺＺＺＺＺ１ＺＺＺＺＺＺＺＺＺ２</td></tr>"
					+ "<tr ><td align=\"center\">3</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('A12347');\"></td><td>A12347</td><td>ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td></tr>"
					+ "<tr ><td align=\"center\">4</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('A12348');\"></td><td>A12348</td><td>ＺＺＺＺＺＺＺＺＺ１ＺＺＺＺＺＺＺＺＺ２</td></tr>"
					+ "<tr ><td align=\"center\">5</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('A12349');\"></td><td>A12349</td><td>ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td></tr>"
					+ "<tr ><td align=\"center\">6</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('A12350');\"></td><td>A12350</td><td>ＺＺＺＺＺＺＺＺＺ１ＺＺＺＺＺＺＺＺＺ２</td></tr>"
					+ "</table>"));
}

/**
 * フィールドに色をセットする アーチスト
 *
 * @param index
 *            フィールドのインデックス番号
 * @param color
 *            色
 */
function sanshoSetFieldColorArtist(index, color) {
	if (index == 0) {
		// sanshoSetBackgroundColor(objSanshoForm.elements[sansho_name_txt_dairiten_code],
		// color);
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoArtistCodeFrom"], color);
	} else if (index == 1) {
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoArtistCodeTo"], color);
	} else if (index == 2) {
		sanshoSetBackgroundColor(
				objSanshoForm.elements["ArtistTaitoru"], color);
	}
}

/**
 * フィールドに色をセットする アーチスト
 *
 * @param color
 *            色
 */
function sanshoSetFieldColorArtistAll(color) {
	for (var i = 0; i <= 4; i++) {
		sanshoSetFieldColorArtist(i, color);
	}
}

/**
 * 参照画面のボタン処理 クリア 支払
 */
function sanshoClearShiharai() {
	// alert("sanshoClear start");
	objSanshoForm.elements["fldSanshoShiharaiGeimeikanji"].value = "";
	objSanshoForm.elements["fldSanshoShiharaiGeimeikana"].value = "";
	objSanshoForm.elements["fldSanshoShiharaiKouzameigijin"].value = "";
}
/**
 * 参照画面ボタン処理 検索 支払
 */
function sanshoKensakuShiharai() {
	// alert("sanshoKensakuHaishin start");
	// ★★モック
	respSanshoByDwr(new Array(
			"SH",
			"検索しました。",
			-1,
			2,
			"<table class=\"table_main\" id=\"tableSanshoShiharai\" width=\"800px\" >"
					+ "<tr ><td width=\"30px\" align=\"center\">1</td><td width=\"70px\" align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('NII1001XXX');\"></td><td width=\"100px\">NII1001XXX</td><td width=\"200px\">ＹＹＹＹＹＹＹＹＹ１ＹＹＹＹＹＹＹＹＹ２<input type=\"hidden\" name=\"TBLcode_0\" id=\"TBLcode_0\" value=\"ＹＹＹＹＹＹＹＹＹ１ＹＹＹＹＹＹＹＹＹ２\"></td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><td>ＹＹＹＹＹＹＹＹＹ１ＹＹＹＹＹＹＹＹＹ２</td></tr>"
					+ "<tr ><td align=\"center\">2</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('NII1234XXX');\"></td><td>NII1234XXX</td><td>ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２<input type=\"hidden\" name=\"TBLcode_1\" id=\"TBLcode_1\" value=\"ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２\"></td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><td>ＹＹＹＹＹＹＹＹＹ１ＹＹＹＹＹＹＹＹＹ２</td></tr>"
					+ "<tr ><td align=\"center\">3</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('NII1235XXX');\"></td><td>NII1235XXX</td><td>日本テレビ情報産業<input type=\"hidden\" name=\"TBLcode_2\" id=\"TBLcode_2\" value=\"日本テレビ情報産業\"></td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><td>ニホンテレビケイリブ</td></tr>"
					+ "<tr ><td align=\"center\">4</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('NII1240XXX');\"></td><td>NII1240XXX</td><td>日本アニメ情報産業<input type=\"hidden\" name=\"TBLcode_3\" id=\"TBLcode_3\" value=\"日本アニメ情報産業\"></td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><td>ニホンテレビケイリブ</td></tr>"
					+ "<tr ><td align=\"center\">5</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('NII1250XXX');\"></td><td>NII1250XXX</td><td>ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２<input type=\"hidden\" name=\"TBLcode_4\" id=\"TBLcode_4\" value=\"ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２\"></td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><td>ＹＹＹＹＹＹＹＹＹ１ＹＹＹＹＹＹＹＹＹ２</td></tr>"
					+ "<tr ><td align=\"center\">6</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('NII1777XXX');\"></td><td>NII1777XXX</td><td>ＺＺＺＺＺＺＺＺＺ１ＺＺＺＺＺＺＺＺＺ２<input type=\"hidden\" name=\"TBLcode_5\" id=\"TBLcode_5\" value=\"ＺＺＺＺＺＺＺＺＺ１ＺＺＺＺＺＺＺＺＺ２\"></td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><td>ＹＹＹＹＹＹＹＹＹ１ＹＹＹＹＹＹＹＹＹ２</td></tr>"
					+ "</table>"));
}

/**
 * フィールドに色をセットする 支払
 *
 * @param index
 *            フィールドのインデックス番号
 * @param color
 *            色
 */
function sanshoSetFieldColorShiharai(index, color) {
	if (index == 0) {
		// sanshoSetBackgroundColor(objSanshoForm.elements[sansho_name_txt_dairiten_code],
		// color);
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoShiharaiGeimeikanji"], color);
	} else if (index == 1) {
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoShiharaiGeimeikana"], color);
	} else if (index == 2) {
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoShiharaiKouzameigijin"],
				color);
	}
}

/**
 * フィールドに色をセットする 支払
 *
 * @param color
 *            色
 */
function sanshoSetFieldColorShiharaiAll(color) {
	for (var i = 0; i <= 4; i++) {
		sanshoSetFieldColorShiharai(i, color);
	}
}

/**
 * 参照画面のボタン処理 クリア 権利者
 */
function sanshoClearKenrisha() {
	// alert("sanshoClear start");
	objSanshoForm.elements["fldSanshoKenrishaGeimeikanji"].value = "";
	objSanshoForm.elements["fldSanshoKenrishaGeimeikana"].value = "";
}
/**
 * 参照画面ボタン処理 検索 権利者
 */
function sanshoKensakuKenrisha() {
	// alert("sanshoKensakuKenrisha start");
	// ★★モック
	respSanshoByDwr(new Array(
			"KE",
			"検索しました。",
			-1,
			2,
			"<table class=\"table_main\" id=\"tableSanshoKenrisha\" width=\"800px\" >"
					+ "<tr ><td width=\"30px\" align=\"center\">1</td><td width=\"70px\" align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('NII1001');\"></td><td width=\"100px\">NII1001</td><td width=\"200px\">ＹＹＹＹＹＹＹＹＹ１ＹＹＹＹＹＹＹＹＹ２<input type=\"hidden\" name=\"TBLcode_0\" id=\"TBLcode_0\" value=\"ＹＹＹＹＹＹＹＹＹ１ＹＹＹＹＹＹＹＹＹ２\"></td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2<input type=\"hidden\" name=\"TBLcode_0\" id=\"TBLcode_0\" value=\"XXXXXXXXX1XXXXXXXXX2\"></td></tr>"
					+ "<tr ><td align=\"center\">2</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('NII1234');\"></td><td>NII1234</td><td>ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２<input type=\"hidden\" name=\"TBLcode_1\" id=\"TBLcode_1\" value=\"ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２\"></td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2<input type=\"hidden\" name=\"TBLcode_1\" id=\"TBLcode_1\" value=\"XXXXXXXXX1XXXXXXXXX2\"></td></tr>"
					+ "<tr ><td align=\"center\">3</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('NII1235');\"></td><td>NII1235</td><td>日本テレビ情報産業<input type=\"hidden\" name=\"TBLcode_2\" id=\"TBLcode_2\" value=\"日本テレビ情報産業\"></td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2<input type=\"hidden\" name=\"TBLcode_2\" id=\"TBLcode_2\" value=\"XXXXXXXXX1XXXXXXXXX2\"></td></tr>"
					+ "<tr ><td align=\"center\">4</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('NII1240');\"></td><td>NII1240</td><td>日本アニメ情報産業<input type=\"hidden\" name=\"TBLcode_3\" id=\"TBLcode_3\" value=\"日本アニメ情報産業\"></td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2<input type=\"hidden\" name=\"TBLcode_3\" id=\"TBLcode_3\" value=\"XXXXXXXXX1XXXXXXXXX2\"></td></tr>"
					+ "<tr ><td align=\"center\">5</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('NII1250');\"></td><td>NII1250</td><td>ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２<input type=\"hidden\" name=\"TBLcode_4\" id=\"TBLcode_4\" value=\"ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２\"></td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2<input type=\"hidden\" name=\"TBLcode_4\" id=\"TBLcode_4\" value=\"XXXXXXXXX1XXXXXXXXX2\"></td></tr>"
					+ "<tr ><td align=\"center\">6</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('NII1777');\"></td><td>NII1777</td><td>ＺＺＺＺＺＺＺＺＺ１ＺＺＺＺＺＺＺＺＺ２<input type=\"hidden\" name=\"TBLcode_5\" id=\"TBLcode_5\" value=\"ＺＺＺＺＺＺＺＺＺ１ＺＺＺＺＺＺＺＺＺ２\"></td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2<input type=\"hidden\" name=\"TBLcode_5\" id=\"TBLcode_5\" value=\"XXXXXXXXX1XXXXXXXXX2\"></td></tr>"
					+ "</table>"));
}

/**
 * フィールドに色をセットする 権利者
 *
 * @param index
 *            フィールドのインデックス番号
 * @param color
 *            色
 */
function sanshoSetFieldColorKenrisha(index, color) {
	if (index == 0) {
		// sanshoSetBackgroundColor(objSanshoForm.elements[sansho_name_txt_dairiten_code],
		// color);
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoKenrishaGeimeikanji"], color);
	} else if (index == 1) {
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoKenrishaGeimeikana"], color);
	}
}

/**
 * フィールドに色をセットする 権利者
 *
 * @param color
 *            色
 */
function sanshoSetFieldColorKenrishaAll(color) {
	for (var i = 0; i <= 4; i++) {
		sanshoSetFieldColorKenrisha(i, color);
	}
}

/**
 * 参照画面のボタン処理 クリア 契約番号
 */
function sanshoClearKeiyaku() {
	// alert("sanshoClear start");
	objSanshoForm.elements["fldSanshoKikakuCodeFrom"].value = "";
	objSanshoForm.elements["fldSanshoKikakuCodeTo"].value = "";
	objSanshoForm.elements["KikakuName"].value = "";
	objSanshoForm.elements["fldSanshoKeiyakuKenrishaKanji"].value = "";
	objSanshoForm.elements["fldSanshoKeiyakuKenrishaKana"].value = "";
  objSanshoForm.elements["fldSanshoKeiyakuShiharaisakiKanji"].value = "";
  objSanshoForm.elements["fldSanshoKeiyakuShiharaisakiKana"].value = "";

	// objSanshoForm.elements["fldSanshoKeiyakuInzeibunpaiyou"].value = "";
}
/**
 * 参照画面ボタン処理 検索 契約番号
 */
function sanshoKensakuKeiyaku() {
	// alert("sanshoKensakuHaishin start");
	// ★★モック
	respSanshoByDwr(new Array(
			"KEI",
			"検索しました。",
			-1,
			2,
			"<table class=\"table_main\" id=\"tableSanshoKeiyaku\" width=\"1590px\" >"
					+ "<tr ><td width=\"30px\" align=\"center\">1</td><td width=\"60px\" align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('XXXXXX');\"></td><td width=\"80px\">XXXXXXXXX1</td><td width=\"50px\">XXX</td><td width=\"80px\">XXXXXXX</td><td width=\"190px\"><div style='overflow:hidden;width:180px'title='ＺＺＺＺＺＺＺＺＺ１ＺＺＺＺＺＺＺＺＺ２ＺＺＺＺＺＺＺＺＺ３ＺＺＺＺＺＺＺＺＺ４ＺＺＺＺＺＺＺＺＺ５ＺＺＺＺＺＺＺＺＺ６ＺＺＺＺＺＺＺＺＺ７ＺＺＺＺＺＺＺＺＺ８ＺＺＺＺＺＺＺＺＺ９ＺＺＺＺＺＺＺＺ１０ＺＺＺＺＺＺＺＺＺ１ＺＺＺＺＺＺＺＺＺ２ＺＺＺＺＺＺＺＺＺ３ＺＺＺＺＺＺＺＺＺ４ＺＺＺＺＺＺＺＺＺ５ＺＺＺＺＺＺＺＺＺ６ＺＺＺＺＺＺＺＺＺ７ＺＺＺＺＺＺＺＺＺ８ＺＺＺＺＺＺＺＺＺ９ＺＺＺＺＺＺＺＺ１０'>ＺＺＺＺＺＺＺＺＺ１ＺＺＺＺＺＺＺＺＺ２ＺＺＺＺＺＺＺＺＺ３ＺＺＺＺＺＺＺＺＺ４ＺＺＺＺＺＺＺＺＺ５ＺＺＺＺＺＺＺＺＺ６ＺＺＺＺＺＺＺＺＺ７ＺＺＺＺＺＺＺＺＺ８ＺＺＺＺＺＺＺＺＺ９ＺＺＺＺＺＺＺＺ１０ＺＺＺＺＺＺＺＺＺ１ＺＺＺＺＺＺＺＺＺ２ＺＺＺＺＺＺＺＺＺ３ＺＺＺＺＺＺＺＺＺ４ＺＺＺＺＺＺＺＺＺ５ＺＺＺＺＺＺＺＺＺ６ＺＺＺＺＺＺＺＺＺ７ＺＺＺＺＺＺＺＺＺ８ＺＺＺＺＺＺＺＺＺ９ＺＺＺＺＺＺＺＺ１０</div></td><td width=\"80px\">XXXXXX</td><td width=\"200px\">ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><td width=\"80px\">XXXXXXXXX1</td><td width=\"200px\">ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><!--<td width=\"120px\">1.歌唱印税</td>--><!--<td width=\"200px\">ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td>--></tr>"
					+ "<tr ><td align=\"center\">2</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('XXXXXX');\"></td><td width=\"80px\">XXXXXXXXX1</td><td width=\"50px\">XXX</td><td width=\"80px\">K123456</td><td width=\"190px\"><div style='overflow:hidden;width:180px'title='ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２'>ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</div></td><td width=\"80px\">XXXXXXX</td><td width=\"200px\">ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><td width=\"80px\">XXXXXXXXX1</td><td width=\"200px\">ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><!--<td width=\"120px\">2.原盤印税</td>--><!--<td width=\"200px\">ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td>--></tr>"
					+ "<tr ><td align=\"center\">3</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('012345');\"></td><td width=\"80px\">0123456789</td><td width=\"50px\">001</td><td width=\"80px\">K123456</td><td width=\"190px\"><div style='overflow:hidden;width:180px'title='ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２'>ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</div></td><td width=\"80px\">0000001</td><td width=\"200px\">東野幸治</td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><td width=\"80px\">XXX1234561</td><td width=\"200px\">よしもと</td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><!--<td width=\"120px\">11.実演家追加報酬</td>--><!--<td width=\"200px\">東野・岡村の旅猿8 ごめんなさい</td>--></tr>"
					+ "<tr ><td align=\"center\">4</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('012345');\"></td><td width=\"80px\">0123456789</td><td width=\"50px\">002</td><td width=\"80px\">K123456</td><td width=\"190px\"><div style='overflow:hidden;width:180px'title='ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２'>ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</div></td><td width=\"80px\">0000002</td><td width=\"200px\">岡村隆史</td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><td width=\"80px\">XXX1234561</td><td width=\"200px\">よしもと</td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><!--<td width=\"120px\">11.実演家追加報酬</td>--><!--<td width=\"200px\">東野・岡村の旅猿8 ごめんなさい</td>--></tr>"
					+ "<tr ><td align=\"center\">5</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('012345');\"></td><td width=\"80px\">0123456789</td><td width=\"50px\">003</td><td width=\"80px\">K123456</td><td width=\"190px\"><div style='overflow:hidden;width:180px'title='ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２'>ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</div></td><td width=\"80px\">0000003</td><td width=\"200px\">シンガー００３</td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><td width=\"80px\">XXX1111113</td><td width=\"200px\">歌手三太郎</td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><!--<td width=\"120px\">1.歌唱印税</td>--><!--<td width=\"200px\">東野・岡村の旅猿8 テーマソング</td>--></tr>"
					+ "<tr ><td align=\"center\">6</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('012345');\"></td><td width=\"80px\">0123456789</td><td width=\"50px\">004</td><td width=\"80px\">K123456</td><td width=\"190px\"><div style='overflow:hidden;width:180px'title='ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２'>ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</div></td><td width=\"80px\">0000004</td><td width=\"200px\">グッズ作成００４</td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><td width=\"80px\">XXX1111114</td><td width=\"200px\">ショップよしもと</td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><!--<td width=\"120px\">4.商品化権使用料</td>--><!--<td width=\"200px\">東野・岡村の旅猿8 缶バッチ</td>--></tr>"
          + "<tr ><td align=\"center\">7</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('123456');\"></td><td width=\"80px\">1234567890</td><td width=\"50px\">XXX</td><td width=\"80px\">XXXXXXX</td><td width=\"190px\"><div style='overflow:hidden;width:180px'title='ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２'>ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</div></td><td width=\"80px\">XXXXXXX</td><td width=\"200px\">ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><td width=\"80px\">XXXXXXXXX1</td><td width=\"200px\">ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><!--<td width=\"120px\">2.原盤印税</td>--><!--<td width=\"200px\">ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td>--></tr>"
					+ "</table>"));
}


/**
 * 参照画面のボタン処理 クリア 契約番号-枝番
 */
function sanshoClearKeiyakuEda() {
	// alert("sanshoClear start");
	objSanshoForm.elements["fldSanshoKikakuCodeFrom"].value = "";
	objSanshoForm.elements["fldSanshoKikakuCodeTo"].value = "";
	objSanshoForm.elements["KikakuName"].value = "";
	objSanshoForm.elements["fldSanshoKeiyakuKenrishaKanji"].value = "";
	objSanshoForm.elements["fldSanshoKeiyakuKenrishaKana"].value = "";
  objSanshoForm.elements["fldSanshoKeiyakuShiharaisakiKanji"].value = "";
  objSanshoForm.elements["fldSanshoKeiyakuShiharaisakiKana"].value = "";

	// objSanshoForm.elements["fldSanshoKeiyakuInzeibunpaiyou"].value = "";
}
/**
 * 参照画面ボタン処理 検索 契約番号-枝番
 */
function sanshoKensakuKeiyakuEda() {
	// alert("sanshoKensakuHaishin start");
	// ★★モック
	respSanshoByDwr(new Array(
			"KEIEDA",
			"検索しました。",
			-1,
			2,
			"<table class=\"table_main\" id=\"tableSanshoKeiyakuEda\" width=\"1600px\" >"
					+ "<tr ><td width=\"30px\" align=\"center\">1</td><td width=\"60px\" align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('XXXXXXXXX1-XXX');\"></td><td width=\"110px\">XXXXXXXXX1-XXX</td><td width=\"80px\">XXXXXXX</td><td width=\"200px\"><div style='overflow:hidden; width:200px;' title='ＺＺＺＺＺＺＺＺＺ１ＺＺＺＺＺＺＺＺＺ２ＺＺＺＺＺＺＺＺＺ３ＺＺＺＺＺＺＺＺＺ４ＺＺＺＺＺＺＺＺＺ５ＺＺＺＺＺＺＺＺＺ６ＺＺＺＺＺＺＺＺＺ７ＺＺＺＺＺＺＺＺＺ８ＺＺＺＺＺＺＺＺＺ９ＺＺＺＺＺＺＺＺ１０ＺＺＺＺＺＺＺＺＺ１ＺＺＺＺＺＺＺＺＺ２ＺＺＺＺＺＺＺＺＺ３ＺＺＺＺＺＺＺＺＺ４ＺＺＺＺＺＺＺＺＺ５ＺＺＺＺＺＺＺＺＺ６ＺＺＺＺＺＺＺＺＺ７ＺＺＺＺＺＺＺＺＺ８ＺＺＺＺＺＺＺＺＺ９ＺＺＺＺＺＺＺＺ１０'>ＺＺＺＺＺＺＺＺＺ１ＺＺＺＺＺＺＺＺＺ２ＺＺＺＺＺＺＺＺＺ３ＺＺＺＺＺＺＺＺＺ４ＺＺＺＺＺＺＺＺＺ５ＺＺＺＺＺＺＺＺＺ６ＺＺＺＺＺＺＺＺＺ７ＺＺＺＺＺＺＺＺＺ８ＺＺＺＺＺＺＺＺＺ９ＺＺＺＺＺＺＺＺ１０ＺＺＺＺＺＺＺＺＺ１ＺＺＺＺＺＺＺＺＺ２ＺＺＺＺＺＺＺＺＺ３ＺＺＺＺＺＺＺＺＺ４ＺＺＺＺＺＺＺＺＺ５ＺＺＺＺＺＺＺＺＺ６ＺＺＺＺＺＺＺＺＺ７ＺＺＺＺＺＺＺＺＺ８ＺＺＺＺＺＺＺＺＺ９ＺＺＺＺＺＺＺＺ１０</div></td><td width=\"80px\">XXXXXXX</td><td width=\"200px\">ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><td width=\"80px\">XXXXXXXXX1</td><td width=\"200px\">ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><!--<td width=\"110px\">1.歌唱印税</td>--><!--<td width=\"200px\">ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td>--></tr>"
					+ "<tr ><td align=\"center\">2</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('XXXXXXXXX1-XXX');\"></td><td width=\"100px\">XXXXXXXXX1-XXX</td><td width=\"80px\">K123456</td><td width=\"200px\"><div style='overflow:hidden; width:200px;' title='ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２'>ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</div></td><td width=\"80px\">XXXXXXX</td><td width=\"200px\">ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><td width=\"80px\">XXXXXXXXX1</td><td width=\"200px\">ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><!--<td width=\"110px\">2.原盤印税</td>--><!--<td width=\"200px\">ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td>--></tr>"
					+ "<tr ><td align=\"center\">3</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('0123456789-001');\"></td><td width=\"100px\">0123456789-001</td><td width=\"80px\">K123456</td><td width=\"200px\"><div style='overflow:hidden; width:200px;' title='ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２'>ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</div></td><td width=\"80px\">0000001</td><td width=\"200px\">東野幸治</td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><td width=\"80px\">1234567890</td><td width=\"200px\">よしもと</td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><!--<td width=\"110px\">11.実演家追加報酬</td>--><!--<td width=\"200px\">東野・岡村の旅猿8 ごめんなさい</td>--></tr>"
					+ "<tr ><td align=\"center\">4</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('0123456789-002');\"></td><td width=\"100px\">0123456789-002</td><td width=\"80px\">K123456</td><td width=\"200px\"><div style='overflow:hidden; width:200px;' title='ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２'>ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</div></td><td width=\"80px\">0000002</td><td width=\"200px\">岡村隆史</td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><td width=\"80px\">1234567890</td><td width=\"200px\">よしもと</td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><!--<td width=\"110px\">11.実演家追加報酬</td>--><!--<td width=\"200px\">東野・岡村の旅猿8 ごめんなさい</td>--></tr>"
					+ "<tr ><td align=\"center\">5</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('0123456789-003');\"></td><td width=\"100px\">0123456789-003</td><td width=\"80px\">K123456</td><td width=\"200px\"><div style='overflow:hidden; width:200px;' title='ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２'>ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</div></td><td width=\"80px\">0000003</td><td width=\"200px\">シンガー００３</td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><td width=\"80px\">1111113456</td><td width=\"200px\">歌手三太郎</td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><!--<td width=\"110px\">1.歌唱印税</td>--><!--<td width=\"200px\">東野・岡村の旅猿8 テーマソング</td>--></tr>"
					+ "<tr ><td align=\"center\">6</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('0123456789-004');\"></td><td width=\"100px\">0123456789-004</td><td width=\"80px\">K123456</td><td width=\"200px\"><div style='overflow:hidden; width:200px;' title='ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２'>ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</div></td><td width=\"80px\">0000004</td><td width=\"200px\">グッズ作成００４</td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><td width=\"80px\">1111114567</td><td width=\"200px\">ショップよしもと</td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><!--<td width=\"110px\">4.商品化権使用料</td>--><!--<td width=\"200px\">東野・岡村の旅猿8 缶バッチ</td>--></tr>"
          + "<tr ><td align=\"center\">7</td><td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('0123456789-XXX');\"></td><td width=\"100px\">0123456789-XXX</td><td width=\"80px\">XXXXXXX</td><td width=\"200px\"><div style='overflow:hidden; width:200px;' title='ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２'>ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</div></td><td width=\"80px\">XXXXXXX</td><td width=\"200px\">ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><td width=\"80px\">XXXXXXXXX1</td><td width=\"200px\">ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td><td width=\"200px\">XXXXXXXXX1XXXXXXXXX2</td><!--<td width=\"110px\">2.原盤印税</td>--><!--<td width=\"200px\">ＸＸＸＸＸＸＸＸＸ１ＸＸＸＸＸＸＸＸＸ２</td>--></tr>"
					+ "</table>"));
}

/**
 * フィールドに色をセットする 契約番号
 *
 * @param index
 *            フィールドのインデックス番号
 * @param color
 *            色
 */
function sanshoSetFieldColorKeiyaku(index, color) {
	if (index == 0) {
		// sanshoSetBackgroundColor(objSanshoForm.elements[sansho_name_txt_dairiten_code],
		// color);
		sanshoSetBackgroundColor(
					objSanshoForm.elements["fldSanshoKikakuCodeFrom"], color);
	} else if (index == 1) {
		sanshoSetBackgroundColor(
					objSanshoForm.elements["fldSanshoKikakuCodeTo"], color);
	} else if (index == 2) {
		sanshoSetBackgroundColor(
					objSanshoForm.elements["KikakuName"], color);
	} else if (index == 3) {
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoKeiyakuShiharaisakiKana"],	color);
  } else if (index == 4) {
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoKeiyakuKenrishaKanji"], color);
  } else if (index == 5) {
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoKeiyakuKenrishaKana"], color);
  } else if (index == 6) {
		sanshoSetBackgroundColor(
        objSanshoForm.elements["fldSanshoKeiyakuShiharaisakiKanji"], color);
  	//sanshoSetBackgroundColor(
  	//	 	objSanshoForm.elements["fldSanshoKeiyakuInzeibunpaiyou"],	color);
	}
}

/**
 * フィールドに色をセットする 契約番号
 *
 * @param color
 *            色
 */
function sanshoSetFieldColorKeiyakuAll(color) {
	for (var i = 0; i <= 4; i++) {
		sanshoSetFieldColorKeiyaku(i, color);
	}
}


/**
 * フィールドに色をセットする 契約番号-枝番
 *
 * @param index
 *            フィールドのインデックス番号
 * @param color
 *            色
 */
function sanshoSetFieldColorKeiyakuEda(index, color) {
	if (index == 0) {
		// sanshoSetBackgroundColor(objSanshoForm.elements[sansho_name_txt_dairiten_code],
		// color);
		sanshoSetBackgroundColor(
					objSanshoForm.elements["fldSanshoKikakuCodeFrom"], color);
	} else if (index == 1) {
		sanshoSetBackgroundColor(
					objSanshoForm.elements["fldSanshoKikakuCodeTo"], color);
	} else if (index == 2) {
		sanshoSetBackgroundColor(
					objSanshoForm.elements["KikakuName"], color);
	} else if (index == 3) {
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoKeiyakuShiharaisakiKana"],	color);
  } else if (index == 4) {
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoKeiyakuKenrishaKanji"], color);
  } else if (index == 5) {
		sanshoSetBackgroundColor(
				objSanshoForm.elements["fldSanshoKeiyakuKenrishaKana"], color);
  } else if (index == 6) {
		sanshoSetBackgroundColor(
        objSanshoForm.elements["fldSanshoKeiyakuShiharaisakiKanji"], color);
  	//sanshoSetBackgroundColor(
  	//	 	objSanshoForm.elements["fldSanshoKeiyakuInzeibunpaiyou"],	color);
	}
}

/**
 * フィールドに色をセットする 契約番号
 *
 * @param color
 *            色
 */
function sanshoSetFieldColorKeiyakuEdaAll(color) {
	for (var i = 0; i <= 4; i++) {
		sanshoSetFieldColorKeiyakuEda(i, color);
	}
}



/**
 * 参照画面のボタン処理 クリア アドバンス
 */
function sanshoClearAdvance() {
	// alert("sanshoClear start");
	objSanshoForm.elements["kenrishaCodeFrom"].value = "";
	objSanshoForm.elements["kenrishaCodeTo"].value = "";
  objSanshoForm.elements["kenrishaNameKanji"].value = "";
	objSanshoForm.elements["advanceCodeFrom"].value = "";
  objSanshoForm.elements["advanceCodeTo"].value = "";
	objSanshoForm.elements["sakuhinName"].value = "";
}
/**
 * 参照画面ボタン処理 検索 アドバンス
 */
function sanshoKensakuAdvance() {
	// alert("sanshoKensakuKenrisha start");
	// ★★モック
	respSanshoByDwr(new Array(
			"AD",
			"検索しました。",
			-1,
			2,
      "<table class=\"table_main\" width=\"1290px\" id=\"tableSanshoAdvance\" style=\"table-layout: fixed;\">"+
        "<tr>"+
          "<td width=\"20px\" align=\"right\">1</td>"+
          "<td width=\"70px\" align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('AD0001');\"></td>"+
          "<td width=\"100px\" align=\"left\">KENRI01</td>"+
          "<td width=\"200px\" align=\"left\" title=\"WWWWWWWWWMWWWWWWWWWMWWWWWWWWWMWWWWWWWWWM\">WWWWWWWWWMWWWWWWWWWMWWWWWWWWWMWWWWWWWWWM</td>"+
          "<td width=\"100px\" align=\"left\">G0001</td>"+
          "<td width=\"100px\" align=\"left\">AD0001</td>"+
          "<td width=\"200px\" align=\"left\" title=\"WWWWWWWWWMWWWWWWWWWMWWWWWWWWWMWWWWWWWWWM\">WWWWWWWWWMWWWWWWWWWMWWWWWWWWWMWWWWWWWWWM</td>"+
          "<td width=\"200px\" align=\"left\" title=\"WWWWWWWWWMWWWWWWWWWMWWWWWWWWWMWWWWWWWWWM\">WWWWWWWWWMWWWWWWWWWMWWWWWWWWWMWWWWWWWWWM</td>"+
          "<td width=\"200px\" align=\"left\" title=\"WWWWWWWWWMWWWWWWWWWMWWWWWWWWWMWWWWWWWWWM\">WWWWWWWWWMWWWWWWWWWMWWWWWWWWWMWWWWWWWWWM</td>"+
          "<td width=\"100px\" align=\"right\">99,999,999,999</td>"+
        "</tr>"+
        "<tr>"+
          "<td  align=\"right\">2</td>"+
          "<td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('AD0002');\"></td>"+
          "<td  align=\"left\" >KENRI01</td>"+
          "<td  align=\"left\" title=\"WWWWWWWWWMWWWWWWWWWMWWWWWWWWWMWWWWWWWWWM\">WWWWWWWWWMWWWWWWWWWMWWWWWWWWWMWWWWWWWWWM</td>"+
          "<td  align=\"left\">G0001</td>"+
          "<td  align=\"left\">AD0002</td>"+
          "<td  align=\"left\"> title=\"WWWWWWWWWMWWWWWWWWWMWWWWWWWWWMWWWWWWWWWM\"WWWWWWWWWMWWWWWWWWWMWWWWWWWWWMWWWWWWWWWM</td>"+
          "<td  align=\"left\" title=\"WWWWWWWWWMWWWWWWWWWMWWWWWWWWWMWWWWWWWWWM\">WWWWWWWWWMWWWWWWWWWMWWWWWWWWWMWWWWWWWWWM</td>"+
          "<td  align=\"left\" title=\"WWWWWWWWWMWWWWWWWWWMWWWWWWWWWMWWWWWWWWWM\">WWWWWWWWWMWWWWWWWWWMWWWWWWWWWMWWWWWWWWWM</td>"+
          "<td align=\"right\">99,999,999,999</td>"+
        "</tr>"+
        "<tr>"+
          "<td  align=\"right\">3</td>"+
          "<td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('AD0003');\"></td>"+
          "<td  align=\"left\">KENRI01</td>"+
          "<td  align=\"left\" title=\"WWWWWWWWWMWWWWWWWWWMWWWWWWWWWMWWWWWWWWWM\">WWWWWWWWWMWWWWWWWWWMWWWWWWWWWMWWWWWWWWWM</td>"+
          "<td  align=\"left\">G0001</td>"+
          "<td  align=\"left\">AD0003</td>"+
          "<td  align=\"left\" title=\"WWWWWWWWWMWWWWWWWWWMWWWWWWWWWMWWWWWWWWWM\">WWWWWWWWWMWWWWWWWWWMWWWWWWWWWMWWWWWWWWWM</td>"+
          "<td  align=\"left\" title=\"WWWWWWWWWMWWWWWWWWWMWWWWWWWWWMWWWWWWWWWM\">WWWWWWWWWMWWWWWWWWWMWWWWWWWWWMWWWWWWWWWM</td>"+
          "<td  align=\"left\" title=\"WWWWWWWWWMWWWWWWWWWMWWWWWWWWWMWWWWWWWWWM\">WWWWWWWWWMWWWWWWWWWMWWWWWWWWWMWWWWWWWWWM</td>"+
          "<td align=\"right\">99,999,999,999</td>"+
        "</tr>"+
        "<tr>"+
          "<td  align=\"right\">4</td>"+
          "<td align=\"center\"><input type=\"button\" name=\"TBLchkSelect_0\" id=\"TBLchkSelect_0\" style=\"WIDTH: 45px; text-align:center; name=\"選択\" value=\"選択\" onclick=\"sanshoChoice('AD0001');\"></td>"+
          "<td  align=\"left\">KENRI02</td>"+
          "<td  align=\"left\">権利者２</td>"+
          "<td  align=\"left\">G0001</td>"+
          "<td  align=\"left\">AD0001</td>"+
          "<td  align=\"left\">作品名表示</td>"+
          "<td  align=\"left\">メモ１表示</td>"+
          "<td  align=\"left\">メモ２表示</td>"+
          "<td align=\"right\">500,000,000</td>"+
        "</tr>"+
      "</table>"


        ));
}

/**
 * フィールドに色をセットする アドバンス
 *
 * @param index
 *            フィールドのインデックス番号
 * @param color
 *            色
 */
function sanshoSetFieldColorAdvance(index, color) {
	// if (index == 0) {
	// 	sanshoSetBackgroundColor(
	// 			objSanshoForm.elements["kenrishaCodeFrom"], color);
	// } else if (index == 1) {
	// 	sanshoSetBackgroundColor(
	// 			objSanshoForm.elements["kenrishaCodeTo"], color);
	// }else if (index == 2) {
	// 	sanshoSetBackgroundColor(
	// 			objSanshoForm.elements["advanceCodeFrom"], color);
	// }else if (index == 3) {
	// 	sanshoSetBackgroundColor(
	// 			objSanshoForm.elements["advanceCodeTo"], color);
	// }else if (index == 4) {
	// 	sanshoSetBackgroundColor(
	// 			objSanshoForm.elements["kenrishaNameKanji"], color);
	// }else if (index == 5) {
	// 	sanshoSetBackgroundColor(
	// 			objSanshoForm.elements["sakuhinName"], color);
	// }
}

/**
 * フィールドに色をセットする 権利者
 *
 * @param color
 *            色
 */
function sanshoSetFieldColorAdvanceAll(color) {
	for (var i = 0; i <= 4; i++) {
		sanshoSetFieldColorAdvance(i, color);
	}
}


/**
 * 参照ウインドウ専用：ラジオボタンハイライト表示
 *
 * @param radioButtonObj
 *            ラジオボタン
 */
function hilightSanshoRadioButton(radioButtonObj) {
	hilightRadioButtonOnForm(objSanshoForm, radioButtonObj);
}
function dwrGetMainForm() {
	return document.forms[0];
}
