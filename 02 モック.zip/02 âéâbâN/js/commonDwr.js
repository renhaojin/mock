var codObj = null;
var nmObj = null;
var hidObj = null;

var codObj2 = null;
var nmObj2 = null;
var hidObj2 = null;
var waveFlgObj2 = null;

/**
* 得意先 コード検索・名称表示
*/
function searchTok(_codObj, nmId, hidId) {
	var value = _codObj.value;

	codObj = _codObj;
	nmObj = document.getElementById(nmId);
	if (hidId != null) {
		hidObj = document.getElementById(hidId);
	} else {
		hidObj = null;
	}
	// 名称以外の表示項目をセット
	setTokOtObj(_codObj, nmId, hidId);

	if (value == "") {
		setNm("");
		return;
	}

	/*
	SanshoTokService.searchByTokCd(
		value
		, {
		callback:respGetTokByDwr,
		errorHandler:respGetByDwrOnError,
		warningHandler:respGetByDwrOnWarning,
		exceptionHandler:respGetByDwrOnException
	});
	*/
	var mTok = { 
			tokCd: value,
			tokRyknm: "得意先名"+value,
			kaishuIraiLevel: 4,
			heijoSeikyuShimeDay: 15
			};
	respGetTokByDwr(mTok);
}

/**
* 得意先 コード検索・名称表示2(FROM-TOのTO項目等)
* waveFlgにtrueを渡すと、名称の前に　"半角スペース" "～" "半角スペース" が付与される。
*/
function searchTok2(_codObj, nmId, hidId, waveFlg) {
	var value = _codObj.value;

	codObj2 = _codObj;
	nmObj2 = document.getElementById(nmId);
	if (hidId != null) {
		hidObj2 = document.getElementById(hidId);
	} else {
		hidObj2 = null;
	}
	// 名称以外の表示項目をセット
	setTokOtObj(_codObj, nmId, hidId, waveFlg);

	//～を出すかどうか
	waveFlgObj2 = waveFlg;
	if(waveFlgObj2 == null) {
		waveFlgObj2 = false;
	}

	if (value == "") {
		setNm2("");
		return;
	}

	/*
	SanshoTokService.searchByTokCd(
		value
		, {
		callback:respGetTokByDwr2,
		errorHandler:respGetByDwrOnError,
		warningHandler:respGetByDwrOnWarning,
		exceptionHandler:respGetByDwrOnException
	});
	*/
	var mTok = { 
			tokCd: value,
			tokRyknm: "得意先名"+value,
			kaishuIraiLevel: 4,
			heijoSeikyuShimeDay: 15
			};
	respGetTokByDwr2(mTok);
}

function respGetTokByDwr(resp) {
	if (resp==null) {
		setNm("該当無し", true);
		setTokOtCol(resp, true);	// 名称以外の表示
	} else {
		setNm(resp.tokRyknm);
		setTokOtCol(resp);	// 名称以外の表示
	}
}
function respGetTokByDwr2(resp) {
	if (resp==null) {
		setNm2("該当無し", true);
		setTokOtCol(resp, true);	// 名称以外の表示
	} else {
		setNm2(resp.tokRyknm);
		setTokOtCol(resp);	// 名称以外の表示
	}
}

/**
 * 得意先
 * 名称以外の表示項目をセット
 * 必要な場合は各画面で実装すること
 * @param _codObj
 * @param nmId
 * @param hidId
 */
function setTokOtObj(_codObj, nmId, hidId, waveFlg) {
	// 無処理
}

/**
 * 得意先
 * 名称以外の表示
 * 必要な場合は各画面で実装すること
 * @param resp
 */
function setTokOtCol(resp) {
	// 無処理
}


/**
* 商品 コード検索・名称表示
*/
function searchSho(_codObj, nmId, hidId) {
	var value = _codObj.value;

	codObj = _codObj;
	nmObj = document.getElementById(nmId);
	if (hidId != null) {
		hidObj = document.getElementById(hidId);
	} else {
		hidObj = null;
	}
	// 名称以外の表示項目をセット
	setShoOtObj(_codObj, nmId, hidId);

	if (value == "") {
		setNm("");
		return;
	}

	/*
	SanshoShoService.searchByShoBng(
		value
		, {
		callback:respGetShoByDwr,
		errorHandler:respGetByDwrOnError,
		warningHandler:respGetByDwrOnWarning,
		exceptionHandler:respGetByDwrOnException
	});
	*/
	var mSho = { 
			shoBng: value,
			title: "タイトル"+value,
			shukeiCRebate2bunrui: "10-1"
			};
	respGetShoByDwr(mSho);
}

/**
* 商品 コード検索・名称表示2(FROM-TOのTO項目等)
* waveFlgにtrueを渡すと、名称の前に　"半角スペース" "～" "半角スペース" が付与される。
*/
function searchSho2(_codObj, nmId, hidId, waveFlg) {
	var value = _codObj.value;

	codObj2 = _codObj;
	nmObj2 = document.getElementById(nmId);
	if (hidId != null) {
		hidObj2 = document.getElementById(hidId);
	} else {
		hidObj2 = null;
	}
	// 名称以外の表示項目をセット
	setShoOtObj(_codObj, nmId, hidId, waveFlg);

	//～を出すかどうか
	waveFlgObj2 = waveFlg;
	if(waveFlgObj2 == null) {
		waveFlgObj2 = false;
	}

	if (value == "") {
		setNm2("");
		return;
	}

	/*
	SanshoShoService.searchByShoBng(
		value
		, {
		callback:respGetShoByDwr2,
		errorHandler:respGetByDwrOnError,
		warningHandler:respGetByDwrOnWarning,
		exceptionHandler:respGetByDwrOnException
	});
	*/
	var mSho = { 
			shoBng: value,
			title: "タイトル"+value,
			shukeiCRebate2bunrui: "10-1"
			};
	respGetShoByDwr2(mSho);
}

function respGetShoByDwr(resp) {
	if (resp==null) {
		setNm("該当無し", true);
		setShoOtCol(resp, true);	// 名称以外の表示
	} else {
		codObj.value = (resp.shoBng);
		setNm(resp.title);
		setShoOtCol(resp);	// 名称以外の表示
	}
}

function respGetShoByDwr2(resp) {
	if (resp==null) {
		setNm2("該当無し", true);
		setShoOtCol(resp, true);	// 名称以外の表示
	} else {
		codObj2.value = (resp.shoBng);
		setNm2(resp.title);
		setShoOtCol(resp);	// 名称以外の表示
	}
}

/**
 * 商品
 * 名称以外の表示項目をセット
 * 必要な場合は各画面で実装すること
 * @param _codObj
 * @param nmId
 * @param hidId
 */
function setShoOtObj(_codObj, nmId, hidId, waveFlg) {
	// 無処理
}

/**
 * 商品
 * 名称以外の表示
 * 必要な場合は各画面で実装すること
 * @param resp
 */
function setShoOtCol(resp) {
	// 無処理
}

/**
* 科目 コード検索・名称表示
*/
function searchKamoku(_codObj, nmId, hidId) {
	var value = _codObj.value;

	codObj = _codObj;
	nmObj = document.getElementById(nmId);
	if (hidId != null) {
		hidObj = document.getElementById(hidId);
	} else {
		hidObj = null;
	}
	// 名称以外の表示項目をセット
	setKamokuOtObj(_codObj, nmId, hidId);

	if (value == "") {
		setNm("");
		return;
	}

	/*
	SanshoKamokuService.searchByKamokuCd(
		value
		, {
		callback:respGetKamokuByDwr,
		errorHandler:respGetByDwrOnError,
		warningHandler:respGetByDwrOnWarning,
		exceptionHandler:respGetByDwrOnException
	});
	*/
	// 以下、モック用の仮 サーバ処理の替わり
	var tmpKazeiKbn = "1";
	var tmpShohizeiFlg = "0";
	var tmpShohizeiRate = "0";
	if (value != null && value != "") {
		tmpKazeiKbn = value.charAt(0);
		if (value.length >= 2) {
			tmpShohizeiFlg = value.charAt(1);
		}
		if (value.length >= 3) {
			if (value.length == 3) {
				tmpShohizeiRate = value.charAt(2);
			} else {
				tmpShohizeiRate = value.substr(2,2);
				if (tmpShohizeiRate.charAt(0) == "0") {
					tmpShohizeiRate = tmpShohizeiRate.substr(1);
				}
			}
		}
	}
	// 以上、モック用の仮 サーバ処理の替わり
	var mKamoku = { 
			kamokuCd: value,
			kamokuNm: "科目名"+value,
			shohizeiKazeiKbn: tmpKazeiKbn,
			shohizeiFlg: tmpShohizeiFlg,
			shohizeiRate: tmpShohizeiRate
			};
	respGetKamokuByDwr(mKamoku);
}
/**
* 摘要 コード検索・名称表示
*/
function searchTekiyo(_codObj, nmId, hidId) {
	var value = _codObj.value;

	codObj = _codObj;
	nmObj = document.getElementById(nmId);
	if (hidId != null) {
		hidObj = document.getElementById(hidId);
	} else {
		hidObj = null;
	}
	// 名称以外の表示項目をセット
	setTekiyoOtObj(_codObj, nmId, hidId);

	if (value == "") {
		setNm("");
		return;
	}

	/*
	SanshoTekiyoService.searchByTekiyoCd(
		value
		, {
		callback:respGetTekiyoByDwr,
		errorHandler:respGetByDwrOnError,
		warningHandler:respGetByDwrOnWarning,
		exceptionHandler:respGetByDwrOnException
	});
	*/
	var mTekiyo = { 
			tekiyoCd: value,
			tekiyoNm: "摘要名"+value
			};
	respGetTekiyoByDwr(mTekiyo);
}/**
* 科目 コード検索・名称表示2(FROM-TOのTO項目等)
*/
function searchKamoku2(_codObj, nmId, hidId) {
	var value = _codObj.value;

	codObj2 = _codObj;
	nmObj2 = document.getElementById(nmId);
	if (hidId != null) {
		hidObj2 = document.getElementById(hidId);
	} else {
		hidObj2 = null;
	}
	// 名称以外の表示項目をセット
	setKamokuOtObj(_codObj, nmId, hidId);

	if (value == "") {
		setNm2("");
		return;
	}

	/*
	SanshoKamokuService.searchByKamokuCd(
		value
		, {
		callback:respGetKamokuByDwr2,
		errorHandler:respGetByDwrOnError,
		warningHandler:respGetByDwrOnWarning,
		exceptionHandler:respGetByDwrOnException
	});
	*/
	var mKamoku = { 
			kamokuCd: value,
			kamokuNm: "科目名"+value
			};
	respGetKamokuByDwr2(mKamoku);
}


function respGetKamokuByDwr(resp) {
	if (resp==null) {
		setNm("該当無し", true);
		setKamokuOtCol(resp, true);	// 名称以外の表示
	} else {
		codObj.value = (resp.kamokuCd);
		setNm(resp.kamokuNm);
		setKamokuOtCol(resp);	// 名称以外の表示
	}
}
function respGetKamokuByDwr2(resp) {
	if (resp==null) {
		setNm2("該当無し", true);
		setKamokuOtCol(resp, true);	// 名称以外の表示
	} else {
		codObj2.value = (resp.kamokuCd);
		setNm2(resp.kamokuNm);
		setKamokuOtCol(resp);	// 名称以外の表示
	}
}
function respGetTekiyoByDwr(resp) {
	if (resp==null) {
		setNm("該当無し", true);
		setTekiyoOtCol(resp, true);	// 名称以外の表示
	} else {
		codObj.value = (resp.tekiyoCd);
		setNm(resp.tekiyoNm);
		setTekiyoOtCol(resp);	// 名称以外の表示
	}
}
function respGetTekiyoByDwr2(resp) {
	if (resp==null) {
		setNm2("該当無し", true);
		setTekiyoOtCol(resp, true);	// 名称以外の表示
	} else {
		codObj2.value = (resp.tekiyoCd);
		setNm2(resp.tekiyoNm);
		setTekiyoOtCol(resp);	// 名称以外の表示
	}
}

/**
 * 科目
 * 名称以外の表示項目をセット
 * 必要な場合は各画面で実装すること
 * @param _codObj
 * @param nmId
 * @param hidId
 */
function setKamokuOtObj(_codObj, nmId, hidId, waveFlg) {
	// 無処理
}

/**
 * 摘要
 * 名称以外の表示
 * 必要な場合は各画面で実装すること
 * @param resp
 */
function setTekiyoOtCol(resp) {
	// 無処理
}
/**
 * 摘要
 * 名称以外の表示項目をセット
 * 必要な場合は各画面で実装すること
 * @param _codObj
 * @param nmId
 * @param hidId
 */
function setTekiyoOtObj(_codObj, nmId, hidId, waveFlg) {
	// 無処理
}

/**
 * 科目
 * 名称以外の表示
 * 必要な場合は各画面で実装すること
 * @param resp
 */
function setKamokuOtCol(resp) {
	// 無処理
}
//--   以下、共通処理
//------------------------------------------------------------------------------------------//
/**
* 共通処理 コード検索・名称表示
*/
function respGetByDwrOnError(message, error) {
	setNm(message, true);
}
function respGetByDwrOnWarning(message, warning) {
    if (warning.name == "dwr.engine.missingData") {
        // ログオンチェックエラー、IPアドレスチェックエラーの場合は、ServletFilterで空の戻りをしている。
        message = "ログオンしてください。";
    }
	setNm(message, true);
}
function respGetByDwrOnException(message, exception) {
	setNm(message, true);
}

//デフォルトの名称設定処理(通常はこれを呼び出せばよい)
function setNm(str, isError) {
	setComnNm(str, isError, codObj, nmObj, hidObj, null);
}

//名称設定処理(FROM-TOのTO項目等を想定)
function setNm2(str, isError) {
	setComnNm(str, isError, codObj2, nmObj2, hidObj2, waveFlgObj2);
}

// 共通の名称設定処理
function setComnNm(str, isError, paramCodeObj, paramNmObj, paramHidObj, paramWaveFlgObj) {
	if (isError == null) {
		isError = false;
	}

	if (paramWaveFlgObj == null) {
		paramWaveFlgObj = false;
	}

	if(paramWaveFlgObj) {
		str = " ～ " + str;
	}

	if (isError) {
		paramNmObj.style.color = "red";
		paramNmObj.innerHTML = str;
		if (paramHidObj != null) {
			paramHidObj.value = "";
		}
		// なぜかIDセレクタではうまくいかない
		$(":text[name='" + paramCodeObj.name + "']").addClass("validation-error");
	} else {
		paramNmObj.style.color = "black";
		paramNmObj.innerHTML = str;
		if (paramHidObj != null) {
			paramHidObj.value = str;
		}
		$(":text[name='" + paramCodeObj.name + "']").removeClass("validation-error");
	}
}


