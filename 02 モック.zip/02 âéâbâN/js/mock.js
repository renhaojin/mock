var mockSubMenu = null;
$(function() {
	var screenNameTmp = "画面名";
	try {
		screenNameTmp = MOCK_SCREEN_NAME;
	} catch (ex) {
	}
	// ヘッダ部
	// 本当はJSPでインクルード
	// Google cromeの場合、オプション--allow-file-access-from-filesで起動しないとloadは動作しない
	var headerName = "header.html";
	try {
		if (MOCK_IS_CHILD == true) {
			headerName = "header_for_child.html";
		}
	} catch (ex) {
	}

	setMockSubMenu(window.location);

	$("#header").load(
			// "header.html",
			headerName,
			function() {
				$("#screen_name").text(screenNameTmp);
				var sysdate = new Date();
				$("#clock").text(
						sysdate.getFullYear() + "/" + (sysdate.getMonth() + 1)
								+ "/" + sysdate.getDate() + " "
								+ sysdate.getHours() + ":"
								+ sysdate.getMinutes());
				try {
					var menuLinks = document.getElementsByName("menuLink");
					if (menuLinks) {
						var menuLink = null;
						for (i = 0; i < menuLinks.length; i++) {
							var name = menuLinks[i].innerHTML;
							if (name == MOCK_MY_MENU_NAME) {
								menuLink = menuLinks[i];
								break;
							}
						}
						if (menuLink) {
							menuLink.style.color = "yellow";
						}
					}
				} catch (ex) {
//				alert(ex);
				}
				try {
					if (MOCK_ICHIRANHYO_ADD_ROW_COUNT > 0) {
						addIchiranRow(MOCK_ICHIRANHYO_NAME,
								MOCK_ICHIRANHYO_ADD_ROW_COUNT);
					}
				} catch (ex) {
//				alert("load" +ex);
				}
			});
	// 一覧表のページャー
	$("#pager_header").load("pager_header.html");
	$("#pager_footer").load("pager_footer.html");
	$("#fileDownload").load("fileDownload.html");
	$("#codeKensakuInzei").load("SanshoInzei.html");
	$("#codeKensakuShohin").load("SanshoShohin.html");
	$("#codeKensakuTokuyakuten").load("SanshoTokuyakuten.html");
	$("#codeKensakuProject").load("SanshoProject.html");
	$("#codeKensakuKikaku").load("SanshoKikaku.html");
	$("#codeKensakuArtist").load("SanshoArtist.html");
	$("#codeKensakuHaishin").load("SanshoHaishin.html");
	$("#codeKensakuShiharai").load("SanshoShiharai.html");
	$("#codeKensakuKenrisha").load("SanshoKenrisha.html");
	$("#codeKensakuKeiyaku").load("SanshoKeiyaku.html");
	$("#codeKensakuKeiyakuEda").load("SanshoKeiyakuEda.html");
	$("#codeKensakuAdvance").load("SanshoAdvance.html");
	$("#codeKensakuJds").load("SanshoJds.html");

    // オンロード処理
    $(document).ready(function(){
    	// カンマ編集テキストボックス存在時、カンマ付与
    	$(".comma").each( function() {
        	$(this).val(removeComma($(this).val()));
        	$(this).val(formatComma($(this).val()));
        });
    });

    // カンマ編集テキストボックスフォーカス時、カンマ除去
	$(".comma").focus(function(){
		this.value = removeComma(this.value);
		this.select();
	})

    // カンマ編集テキストボックスロストフォーカス時、カンマ付与
	$(".comma").blur(function(){
		// カンマ付きテキストの貼り付け対応
		var txt = removeComma(this.value)
		this.value = formatComma(txt);
	})

    // 科目 ハイフン編集テキストボックスフォーカス時、ハイフン除去
	$(".kamoku").focus(function(){
		this.value = removeHyphen(this.value);
		this.select();
	})

    // 科目 ハイフン編集テキストボックスロストフォーカス時、ハイフン付与
	$(".kamoku").blur(function(){
		// カンマ付きテキストの貼り付け対応
		var txt = removeHyphen(this.value)
		this.value = formatKamokuHyphen(txt);
	})

    // 摘要 ハイフン編集テキストボックスフォーカス時、ハイフン除去
	$(".tekiyo").focus(function(){
		this.value = removeHyphen(this.value);
		this.select();
	})

    // 摘要 ハイフン編集テキストボックスロストフォーカス時、ハイフン付与
	$(".tekiyo").blur(function(){
		// カンマ付きテキストの貼り付け対応
		var txt = removeHyphen(this.value)
		this.value = formatTekiyoHyphen(txt);
	})


/*
	// ドロップダウン
	$(".fixed-select-css").ieSelectWidth
		({
			containerClassName : 'select-container',
			overlayClassName : 'select-overlay'
		});
*/
});
function mockBodyOnLoad() {
	// alert("mockBodyOnLoad(). hash=" + window.location.hash);
	mockChangeState(window.location.hash);
}
function mockDoClear() {
	mockChangeState("#init");
}
function mockDoHyoji() {
	mockChangeState(null);
}
function mockGamenseni(gamen) {
	window.location.href = gamen;
}
var mockSubArrayShinpu = new Array('新譜');
var mockSubArraySaiken = new Array('債権','回収','リベート','振替');
var mockSubArrayMaster = new Array('商品マスター','アーティストマスター','得意先マスター','配達先マスター');
var mockSubArrayOther = new Array('担当者','汎用','スケジュール');
function setMockSubMenu(loca) {
	//alert(loca);
	var str = new String(loca);
	if (str.match(/メニュー.html/)) {
		mockSubMenu = null;
	} if (str.match(/メニュー_サブシステム毎.html/)) {
		mockSubMenu = window.location.hash;
	} else {
		for (var index = 0; index < mockSubArrayShinpu.length; index++) {
			if(str.indexOf(mockSubArrayShinpu[index]) >= 0) {
				mockSubMenu = "#shinpu";
				return;
			}
		}
		for (var index = 0; index < mockSubArrayMaster.length; index++) {
			if(str.indexOf(mockSubArrayMaster[index]) >= 0) {
				mockSubMenu = "#master";
				return;
			}
		}
		for (var index = 0; index < mockSubArraySaiken.length; index++) {
			if(str.indexOf(mockSubArraySaiken[index]) >= 0) {
				mockSubMenu = "#saiken";
				return;
			}
		}
		for (var index = 0; index < mockSubArrayOther.length; index++) {
			if(str.indexOf(mockSubArrayOther[index]) >= 0) {
				mockSubMenu = "#other";
				return;
			}
		}
		mockSubMenu = null;
	}
}
function mockGotoSubMenu() {
	if (mockSubMenu == null) {
		window.location.href = "./メニュー.html";
	} else {
		window.location.href = "./メニュー_サブシステム毎.html"+mockSubMenu;
	}
}

/**
 * 一覧表に行を追加する ヘッダ行、明細行、フッタ行があることが前提
 *
 * @param ichiranhyoId
 *            一覧表のテーブルのID
 * @param addRowCnt
 *            追加する行数
 */
function addIchiranRow(ichiranhyoId, addRowCnt) {

	var ichiran = document.getElementById(ichiranhyoId);
	var headerRowCount = 1;
	var FooterRowCount = 1;
	var isMeisaiRow2 = false; // 明細行が2行で1組か
	try {
		if (MOCK_ICHIRANHYO_HEADER_COUNT != 1) {
			headerRowCount = MOCK_ICHIRANHYO_HEADER_COUNT;
		}
	} catch (ex) {
				alert("addIchiranRow 1" + ex);
	}
	try {
		if (MOCK_ICHIRANHYO_FOOTER_COUNT != 1) {
			FooterRowCount = MOCK_ICHIRANHYO_FOOTER_COUNT;
		}
	} catch (ex) {
				alert("addIchiranRow 2" + ex);
	}

	if (!ichiran || !ichiran.rows
			|| ichiran.rows.length < (headerRowCount + FooterRowCount + 1)) {
		return;
	}
	try {
		// 明細行が2行で1組か
		if (MOCK_ICHIRANHYO_MEISAI_COUNT_IS_2) {
			isMeisaiRow2 = true;
		}
	} catch (ex) {
	}
	// 既存の明細行の行数
	var meisaiCnt = ichiran.rows.length - (headerRowCount + FooterRowCount);

	var meisaiRowIdx = headerRowCount;
	// 既存の明細行のHTML
	var rowHtmlText = $(ichiran.rows[meisaiRowIdx]).html(); // 明細1行目
	var rowHtmlText2 = null;
	if (isMeisaiRow2) {
		rowHtmlText2 = $(ichiran.rows[meisaiRowIdx+1]).html();  // 明細2行目
	}
	// 1列目は行番号か
	//var isNo = (ichiran.rows[meisaiRowIdx].cells[0].innerHTML == "1");
	var isNo = false;
	try {
		if (ichiran.rows[meisaiRowIdx].cells[0].innerHTML == "1") {
			isNo = true;
		} else {
			var num = parseInt(ichiran.rows[meisaiRowIdx].cells[0].innerHTML);
			if (!isNaN(num)) {
				isNo = true;
			}
		}
	} catch (ex) {
				alert("addIchiranRow 3" + ex);
		isNo = false;
	}

	for ( var idx = 0; idx < addRowCnt; idx++) {
		// 行を追加。フッタ行の直上に。

		var rowNew = ichiran.insertRow(ichiran.rows.length - FooterRowCount);

		$(rowNew).html(rowHtmlText);

		if (isNo) {
			// 行番号を設定
			var rowNo = meisaiCnt + idx + 1;
			if (isMeisaiRow2) {
				rowNo = rowNo - 1;
			}
			$(rowNew.cells[0]).html(rowNo);
		}
		if (isMeisaiRow2) {
			// 明細行の2行目を追加。フッタ行の直上に。
			var rowNew2 = ichiran.insertRow(ichiran.rows.length - FooterRowCount);
			$(rowNew2).html(rowHtmlText2);
		}
	}
}
/**
 * 画面の状態変化により画面のメイン部分を見せる／隠す
 *
 * @param state
 *            画面の状態
 */
function mockChangeState(state) {
	// alert("mockChangeState(). state="+state);
	if (state != null && state == "#init") {
		if (document.getElementById("content_middle1")) {
			document.getElementById("content_middle1").style.display = "none";
		}
		document.getElementById("content_middle").style.display = "none";
		document.getElementById("command_bottom").style.display = "none";
		mockClearMessage();
	} else {
		if (document.getElementById("content_middle1")) {
			document.getElementById("content_middle1").style.display = "";
		}
		document.getElementById("content_middle").style.display = "";
		document.getElementById("command_bottom").style.display = "";
		if (state == "#save") {
			mockShowMessage('登録しました。',false);
		} else if (state == "#delete") {
			mockShowMessage('削除しました。',false);
		}
	}
}

function mockClearMessage() {
	var messages = document.getElementById("message");
	while (messages.firstChild) {
		messages.removeChild(messages.firstChild);
	}
}
function mockShowMessage(message, isError) {
	var messages = document.getElementById("message");
	while (messages.firstChild) {
		messages.removeChild(messages.firstChild);
	}
	var obj = document.createElement("div");
	obj.innerHTML = message;
	if (isError == true) {
		obj.className = "message_error";
	} else {
		obj.className = "message_info";
	}
	messages.appendChild(obj);
}
function mockCloseThis() {
	close();
}
function mockOpenChild(childUrl) {
	var sizeX = 430;
	var sizeY = 550;
        if (childUrl == './（子画面）印税検索.html#init') {
		sizeX = 590;
	}
	if (childUrl == './（子画面）商品検索.html#init') {
		sizeX = 590;
	}
//	if (childUrl.indexOf('./（子画面）附属品発注貼り付け.html') == 0) {
//		sizeX = 850;
//	}
//	if (childUrl.indexOf('./（子画面）在庫詳細.html') == 0) {
//		sizeX = 590;
//		sizeY = 540;
//	}
//
//	if (childUrl.indexOf('./（子画面）在庫詳細.html') == 0) {
//		sizeX = 590;
//		sizeY = 540;
//	}
	return childWin = window.open(childUrl, 'jvcmusichanbaichild',
			'left=0,top=0,width=' + sizeX + 'px,height=' + sizeY + 'px');
}
function mockOpenChildInzei() {
	return childWin = mockOpenChild('./（子画面）印税検索.html#init');
}
function mockOpenChildShohin() {
	return childWin = mockOpenChild('./（子画面）商品検索.html#init');
}
/* 以下、ファイルダウンロード画面用  */
function openFileDownload() {
	var spnObj = document.getElementById("boxFileDownload");
	if (!spnObj) {
		return;
	}
	//alert(spnObj.style.display );
	if (spnObj.style.display == "none") {
		spnObj.style.display = "";
	} else {
		spnObj.style.display = "none";
	}
}
function fileDownloadExec() {
	if (document.forms["formFileDownload"].elements["chkAutoClose"].checked) {
		openFileDownload();
	}
}
function fileDownloadClear() {

	document.forms["formFileDownload"].elements["fldFileDownloadSakuseiFrom"].value="20140623";
	document.forms["formFileDownload"].elements["fldFileDownloadSakuseiTo"].value="20140624";
	document.forms["formFileDownload"].elements["chkAutoClose"].checked = true;
	document.forms["formFileDownload"].elements["fldFileDownloadOnly"].value = "accid";

	document.forms["formFileDownload"].elements["system"].value="all";
	document.forms["formFileDownload"].elements["shubetsu"].value="all";

	document.getElementById("saiken").style.display="none";
	document.getElementById("master").style.display="none";
	document.getElementById("shinpu").style.display="none";
	document.getElementById("all").style.display="block";
	document.getElementById("saikencsv").style.display="none";
	document.getElementById("saikenpdf").style.display="none";


}
function fileDownloadNew() {

}
function fileDownloadCancel() {
	openFileDownload();
}
function fileDownloadSelectAll(obj) {
	var objs = document.forms["formFileDownload"].elements["fd選択"];
	//alert(objs.length);
	//alert(obj.checked);
	for (i =0; i<objs.length; i++) {
		objs[i].checked = obj.checked;
	}
}
/* 以上、ファイルダウンロード画面用  */
/** ユーザーの販売会社コード モック用 正しくはsessionにある*/
var userHanbaigaishaCode = "001";

function fileDownloadChangePrint(obj) {

	if(obj.value == "saiken") {
		document.getElementById("saiken").style.display="block";
		document.getElementById("master").style.display="none";
		document.getElementById("shinpu").style.display="none";
		document.getElementById("all").style.display="none";
		document.getElementById("saikencsv").style.display="none";
		document.getElementById("saikenpdf").style.display="none";
	} else if(obj.value == "shinpu") {
		document.getElementById("saiken").style.display="none";
		document.getElementById("master").style.display="none";
		document.getElementById("shinpu").style.display="block";
		document.getElementById("all").style.display="none";
		document.getElementById("saikencsv").style.display="none";
		document.getElementById("saikenpdf").style.display="none";
	} else if(obj.value == "master") {
		document.getElementById("saiken").style.display="none";
		document.getElementById("master").style.display="block";
		document.getElementById("shinpu").style.display="none";
		document.getElementById("all").style.display="none";
		document.getElementById("saikencsv").style.display="none";
		document.getElementById("saikenpdf").style.display="none";
	} else if(obj.value == "all") {
		document.getElementById("saiken").style.display="none";
		document.getElementById("master").style.display="none";
		document.getElementById("shinpu").style.display="none";
		document.getElementById("all").style.display="block";
		document.getElementById("saikencsv").style.display="none";
		document.getElementById("saikenpdf").style.display="none";
	}
	document.getElementById("div_body").style.height = (340 - document.getElementById("prints").clientHeight) + "px";

}

function fileDownloadChangePrintShubetsu(obj) {

	var print = document.getElementById("system");
	if(print.value=="saiken") {
	if(obj.value == "all") {
		document.getElementById("saiken").style.display="block";
		document.getElementById("saikencsv").style.display="none";
		document.getElementById("saikenpdf").style.display="none";
	} else if(obj.value == "csv") {
		document.getElementById("saiken").style.display="none";
		document.getElementById("saikencsv").style.display="block";
		document.getElementById("saikenpdf").style.display="none";
	} else if(obj.value == "pdf") {
		document.getElementById("saiken").style.display="none";
		document.getElementById("saikencsv").style.display="none";
		document.getElementById("saikenpdf").style.display="block";
	}
	} else {
		//債権以外はモックでは種別切り替え未対応
	}
	document.getElementById("div_body").style.height = (340 - document.getElementById("prints").clientHeight) + "px";


}


/*==================================================*
/* カンマ編集解除
/* 引数：変換元
/* 戻り値：変換後
/*==================================================*/
function removeComma(str)
{
  rtnValue = str.replace(/,/g, "");
  rtnValue = rtnValue.replace("*", "");

  return rtnValue;
}

/*==================================================*
/* カンマ編集
/* 引数：変換元
/* 戻り値：変換後
/*==================================================*/
function formatComma(str)
{
  rtnValue = "";
  strLen = str.length;

  iPoint = 0;
  if (str.substring(0, 1) == "-") {
  	rtnValue = str.substring(0, 1);
  	str = str.substring(1);
  	strLen = strLen - 1;
  }

  if (strLen > 3) {
    iMod = strLen % 3;
    if (iMod != 0) {
	  rtnValue = rtnValue + str.substring(0, iMod) + ",";
	}
	for (i = 0; i < (strLen - iMod) / 3; i++) {
	  rtnValue = rtnValue + str.substring(iMod + (3 * i), iMod + (3 * (i + 1)));
	  if (iMod + 3 * (i + 1) != strLen) {
	    rtnValue = rtnValue + ",";
	  }
	}
  } else {
    rtnValue = rtnValue + str;
  }

  return rtnValue;
}

/*==================================================*
/* 科目 ハイフン編集解除
/* 引数：変換元
/* 戻り値：変換後
/*==================================================*/
function removeHyphen(str)
{
  rtnValue = str.replace(/-/g, "");
  rtnValue = rtnValue.replace("*", "");

  return rtnValue;
}

/*==================================================*
/* 科目 ハイフン編集
/* 引数：変換元
/* 戻り値：変換後
/*==================================================*/
function formatKamokuHyphen(str)
{
  rtnValue = "";
  strLen = str.length;

  if(strLen == 8) {
  	rtnValue = str.substring(0,4)
  			 + "-"
  			 + str.substring(4,6)
  			 + "-"
  			 + str.substring(6,8);
  } else {
  	rtnValue = str;
  }

  return rtnValue;
}

/*==================================================*
/* 摘要 ハイフン編集
/* 引数：変換元
/* 戻り値：変換後
/*==================================================*/
function formatTekiyoHyphen(str)
{
  rtnValue = "";
  strLen = str.length;

  if(strLen == 8) {
  	rtnValue = str.substring(0,2)
  			 + "-"
  			 + str.substring(2,4)
  			 + "-"
  			 + str.substring(4,8);
  } else {
  	rtnValue = str;
  }

  return rtnValue;
}



/*
   明細行数がスクロールバー必須の時、左側にスクロールバーを追加する。
   ※一覧表とそれを含むdivを "tbl_scroll"で定義していることが前提。
*/
function addScrollOnLoad() {

	// 一覧表とそれを含むdiv
 	var div = document.getElementById("tbl_scroll");
 	if (div == null) {
 		return;
 	}
 	var tbl = document.getElementById("ichiranhyo");
 	if (tbl == null) {
 		return;
 	}
	//alert("addScrollOnLoad. 1 div="+div.offsetHeight+", tbl="+tbl.offsetHeight);
	//alert("addScrollOnLoad. 1 div="+div.height+", tbl="+tbl.height);
	//alert("addScrollOnLoad. 1 div="+div.style.height+", tbl="+tbl.style.height);

	// スクロールが不要の場合は終わり
	if (div.offsetHeight >= tbl.offsetHeight) {
		return;
	}

	// 左のスクロールのdivとその中身
 	var tbl_scroll_left_obj = document.getElementById("tbl_scroll_left");
 	if (tbl_scroll_left_obj == null) {
 		return;
 	}
 	var tbl_scroll_left_contents_obj = document.getElementById("tbl_scroll_left_contents");
 	if (tbl_scroll_left_contents_obj == null) {
 		return;
 	}
	//alert("addScrollOnLoad. 2 div="+div.style.height+",tbl="+tbl.style.height+",tbl="+tbl.height);
	//alert("addScrollOnLoad. div.offsetWidth="+div.offsetWidth+", div.offsetHeight="+div.offsetHeight+",tbl.offsetHeight="+tbl.offsetHeight+",div.top="+div.top+", div.left="+div.left+",div.style.top="+div.style.top+", div.style.left="+div.style.left+",div.offsetTop="+div.offsetTop+", div.offsetLeft="+div.offsetLeft);

	// 左にスクロールバー分の隙間をあける
	document.getElementById("content_middle").style.marginLeft = "25px";

	// 隙間にスクロールバーを置く
 	tbl_scroll_left_obj.style.height = div.offsetHeight + "px";
 	tbl_scroll_left_contents_obj.style.height = tbl.offsetHeight + "px";
 	tbl_scroll_left_obj.style.position = "absolute";
 	tbl_scroll_left_obj.style.top = div.offsetTop + "px";
 	tbl_scroll_left_obj.style.left = "2px";
 	tbl_scroll_left_obj.style.display = "";
//	alert("addScrollOnLoad. height="+ obj2.style.height+","+obj3.style.height);

	// これでイベントは追加できるが…
    tbl_scroll_left_obj.addEventListener('scroll', function() {
	 	var div = document.getElementById("tbl_scroll");
	 	var obj2 = document.getElementById("tbl_scroll_left");
	 	if (div == null) {
	 		return;
	 	}
	 	if (obj2 == null) {
	 		return;
	 	}
		div.scrollTop = tbl_scroll_left.scrollTop;
    }
    , false);

    div.addEventListener('scroll', function() {
	 	var div = document.getElementById("tbl_scroll");
	 	var obj2 = document.getElementById("tbl_scroll_left");
	 	if (div == null) {
	 		return;
	 	}
	 	if (obj2 == null) {
	 		return;
	 	}
		obj2.scrollTop = div.scrollTop;
    }
    , false);

}
function insertTab(o, e)
{
	var kC = e.keyCode ? e.keyCode : e.charCode ? e.charCode : e.which;
	if (kC == 9 && !e.shiftKey && !e.ctrlKey && !e.altKey)
	{
		var oS = o.scrollTop;
		if (o.setSelectionRange)
		{
			var sS = o.selectionStart;
			var sE = o.selectionEnd;
			o.value = o.value.substring(0, sS) + "\t" + o.value.substr(sE);
			o.setSelectionRange(sS + 1, sS + 1);
			o.focus();
		}
		else if (o.createTextRange)
		{
			document.selection.createRange().text = "\t";
			e.returnValue = false;
		}
		o.scrollTop = oS;
		if (e.preventDefault)
		{
			e.preventDefault();
		}
		return false;
	}
	return true;
}

/*==============================================================*/
/* スクロールDIVの高さを設定
 * （bodyタグのonloadでコール）
/*==============================================================*/
function changeHeight(fixHeight) {
	var height = document.documentElement.clientHeight || document.body.clientHeight;
	if (document.getElementById("content_middle")) {
		var tblHeight = document.getElementById("content_middle").offsetHeight;
		var msgHeight = document.getElementById("message").offsetHeight;
		var errHeight = 0;
		if (document.getElementById("content_err")) {
			errHeight = document.getElementById("content_err").offsetHeight;
		}
		if (msgHeight > 0) msgHeight = msgHeight + 5;
		var divHeight = parseInt(height) - parseInt(fixHeight) - msgHeight - parseInt(errHeight);
		if (height >= fixHeight + parseInt(tblHeight)) return;
		document.getElementById("content_middle").style.height = divHeight + "px";
	}
}
