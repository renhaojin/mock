$(function() {
	var screenNameTmp = "画面名";
	try {
		screenNameTmp = MOCK_SCREEN_NAME;
	} catch (ex) {
	}
	// ヘッダ部
	// 本当はJSPでインクルード
	// Google cromeの場合、オプション--allow-file-access-from-filesで起動しないとloadは動作しない
	var headerName = "header_sample.html";
	try {
		if (MOCK_IS_CHILD == true) {
			headerName = "header_for_child.html";
		}
	} catch (ex) {
	}

	$("#header").load(
			// "header.html",
			headerName,
			function() {
				$("#screen_name").text(screenNameTmp);
				var sysdate = new Date();
				$("#clock").text(
						sysdate.getFullYear() + "/" + (sysdate.getMonth() + 1)
								+ "/" + sysdate.getDate() + " "
								+ sysdate.getHours() + ":"
								+ sysdate.getMinutes());
				try {
					var menuLinks = document.getElementsByName("menuLink");
					if (menuLinks) {
						var menuLink = null;
						for (i = 0; i < menuLinks.length; i++) {
							var name = menuLinks[i].innerHTML;
							if (name == MOCK_MY_MENU_NAME) {
								menuLink = menuLinks[i];
								break;
							}
						}
						if (menuLink) {
							menuLink.style.color = "yellow";
						}
					}
				} catch (ex) {
				}
				try {
					if (MOCK_ICHIRANHYO_ADD_ROW_COUNT > 0) {
						addIchiranRow(MOCK_ICHIRANHYO_NAME,
								MOCK_ICHIRANHYO_ADD_ROW_COUNT);
					}
				} catch (ex) {
				}
			});
	// 一覧表のページャー
	$("#pager_header").load("pager_header.html");
	$("#pager_footer").load("pager_footer.html");
});
function mockBodyOnLoad() {
//	 alert("mockBodyOnLoad(). hash=" + window.location.hash);
	mockChangeState(window.location.hash);
}
function mockDoClear() {
	mockChangeState("#init");
}
function mockDoHyoji() {
	mockChangeState(null);
}
function mockGamenseni(gamen) {
	window.location.href = gamen;
}
/**
 * 一覧表に行を追加する ヘッダ行、明細行、フッタ行があることが前提
 * 
 * @param ichiranhyoId
 *            一覧表のテーブルのID
 * @param addRowCnt
 *            追加する行数
 */
function addIchiranRow(ichiranhyoId, addRowCnt) {
	var ichiran = document.getElementById(ichiranhyoId);
	var headerRowCount = 1;
	var FooterRowCount = 1;
	var isMeisaiRow2 = false; // 明細行が2行で1組か
	try {
		if (MOCK_ICHIRANHYO_HEADER_COUNT != 1) {
			headerRowCount = MOCK_ICHIRANHYO_HEADER_COUNT;
		}
	} catch (ex) {
	}
	try {
		if (MOCK_ICHIRANHYO_FOOTER_COUNT != 1) {
			FooterRowCount = MOCK_ICHIRANHYO_FOOTER_COUNT;
		}
	} catch (ex) {
	}
	if (!ichiran || !ichiran.rows
			|| ichiran.rows.length < (headerRowCount + FooterRowCount + 1)) {
		return;
	}
	try {
		// 明細行が2行で1組か
		if (MOCK_ICHIRANHYO_MEISAI_COUNT_IS_2) {
			isMeisaiRow2 = true;
		}
	} catch (ex) {
	}
	// 既存の明細行の行数
	var meisaiCnt = ichiran.rows.length - (headerRowCount + FooterRowCount);
	var meisaiRowIdx = headerRowCount;
	// 既存の明細行のHTML
	var rowHtmlText = ichiran.rows[meisaiRowIdx].innerHTML; // 明細1行目
	var rowHtmlText2 = null;
	if (isMeisaiRow2) {
		rowHtmlText2 = ichiran.rows[meisaiRowIdx+1].innerHTML;  // 明細2行目
	}
	// 1列目は行番号か
	//var isNo = (ichiran.rows[meisaiRowIdx].cells[0].innerHTML == "1");
	var isNo = false;
	try {
		if (ichiran.rows[meisaiRowIdx].cells[0].innerHTML == "1") {
			isNo = true;
		} else {
			var num = parseInt(ichiran.rows[meisaiRowIdx].cells[0].innerHTML);
			if (!isNaN(num)) {
				isNo = true;
			}
		}
	} catch (ex) {
		isNo = false;
	}
	// alert("meisaiCnt="+meisaiCnt+",isNo="+isNo);
	for ( var idx = 0; idx < addRowCnt; idx++) {
		// 行を追加。フッタ行の直上に。
		var rowNew = ichiran.insertRow(ichiran.rows.length - FooterRowCount);
		rowNew.innerHTML = rowHtmlText;
		if (isNo) {
			// 行番号を設定
			var rowNo = meisaiCnt + idx + 1;
			if (isMeisaiRow2) {
				rowNo = rowNo - 1;
			}
			rowNew.cells[0].innerHTML = rowNo;
		}
		if (isMeisaiRow2) {
			// 明細行の2行目を追加。フッタ行の直上に。
			var rowNew2 = ichiran.insertRow(ichiran.rows.length - FooterRowCount);
			rowNew2.innerHTML = rowHtmlText2;
		}
	}
}
/**
 * 画面の状態変化により画面のメイン部分を見せる／隠す
 * 
 * @param state
 *            画面の状態
 */
function mockChangeState(state) {
//	 alert("mockChangeState(). state="+state);
	if (state != null && state == "#init") {
		document.getElementById("content_middle").style.display = "none";
		document.getElementById("command_bottom").style.display = "none";
	} else {
		document.getElementById("content_middle").style.display = "";
		document.getElementById("command_bottom").style.display = "";
	}
}

function mockClearMessage() {
	var messages = document.getElementById("message");
	while (messages.firstChild) {
		messages.removeChild(messages.firstChild);
	}
}
function mockShowMessage(message, isError) {
	var messages = document.getElementById("message");
	while (messages.firstChild) {
		messages.removeChild(messages.firstChild);
	}
	var obj = document.createElement("div");
	obj.innerHTML = message;
	if (isError == true) {
		obj.className = "message_error";
	} else {
		obj.className = "message_info";
	}
	messages.appendChild(obj);
}
function mockCloseThis() {
	close();
}
function mockOpenChild(childUrl) {
	var sizeX = 430;
	var sizeY = 550;
	if (childUrl == './（子画面）商品検索.html#init') {
		sizeX = 590;
	}
	if (childUrl.indexOf('./（子画面）附属品発注貼り付け.html') == 0) {
		sizeX = 850;
	}
	return childWin = window.open(childUrl, 'jvcmusichanbaichild',
			'left=0,top=0,width=' + sizeX + 'px,height=' + sizeY + 'px');
}
function mockOpenChildTokuisaki() {
	return childWin = mockOpenChild('./（子画面）得意先検索.html#init');
}
function mockOpenChildShohin() {
	return childWin = mockOpenChild('./（子画面）商品検索.html#init');
}
