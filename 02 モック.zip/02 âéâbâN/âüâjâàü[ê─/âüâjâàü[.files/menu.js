$(function() {
	init_menu();
});

function init_menu() {

	$('#navigator li').click(function() {
		$(this).find('ul').slideDown(200);
	});
	$('#navigator li').hover(function() {
	}, function() {
		$(this).find('ul').hide();
	});
}
