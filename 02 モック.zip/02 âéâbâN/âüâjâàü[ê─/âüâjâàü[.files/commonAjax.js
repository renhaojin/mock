$(function() {
	/**
	 * layout.htmlから取得したコンテキストパス.
	 */
//	const contextPath = $('#contextPath').val();
});

(function() {
	$.ajaxSetup({
		cache : false,
		/**一度使用したAjax通信のレスポンスをキャッシュさせない. */
		timeout : 15000,
		/**タイムアウト設定（暫定） */
		beforeSend : function(xhr, settings) {
			/**通信開始直前の処理 */
			setCsrfTokenToAjaxHeader();
		},
		success : function(data, status, xhr) {
			/**通信成功時の処理 */
		},
		error : function(XMLHttpRequest, textStatus, errorThrown) {
			/**通信失敗時の処理 */
			console.log("ajax通信に失敗しました");
			console.log("XMLHttpRequest : " + XMLHttpRequest.status);
			console.log("textStatus     : " + textStatus);
			console.log("errorThrown    : " + errorThrown.message);
		},
		complete : function(xhr, status) {
			/**通信完了時の処理（エラーか否かに関わらず） */
		},
	});
})();

/**
 * Spring SecurityのCSRF対策によるトークンをajax通信のヘッダに埋め込める関数.
 * 利用するAjax通信の直前に呼び出す形で利用してください.
 */
function setCsrfTokenToAjaxHeader() {
	const token = $("meta[name='_csrf']").attr("content");
	const header = $("meta[name='_csrf_header']").attr("content");
	$(document).ajaxSend(function(e, xhr, options) {
		xhr.setRequestHeader(header, token);
	});
}