$(function() {

	const contextPath = $('#contextPath').val();
	
	$(".datepicker").datepicker({
		showOn : 'button',
		buttonImage : contextPath + '/image/calendar_3.png',
		buttonText : 'Open Calendar',
		buttonImageOnly : true,
		dateFormat : 'yymmdd',
		beforeShowDay : function(day) {
			var result;
			switch (day.getDay()) {
			case 0: // 日曜日か？
				result = [ true, "date-sunday" ];
				break;
			case 6: // 土曜日か？
				result = [ true, "date-saturday" ];
				break;
			default:
				result = [ true, "" ];
				break;
			}
			return result;
		}
	});

	// カンマ編集テキストボックスフォーカス時、カンマ除去
	$(".comma").focus(function() {
		this.value = removeComma(this.value);
		this.select();
	})

	// カンマ編集テキストボックスロストフォーカス時、カンマ付与
	$(".comma").blur(function() {
		this.value = formatComma(this.value);
	})

	// 科目 ハイフン編集テキストボックスフォーカス時、ハイフン除去
	$(".kamoku").focus(function() {
		this.value = removeHyphen(this.value);
		this.select();
	})

	// 科目 ハイフン編集テキストボックスロストフォーカス時、ハイフン付与
	$(".kamoku").blur(function() {
		// カンマ付きテキストの貼り付け対応
		this.value = formatKamokuHyphen(this.value);
	})

	// 摘要 ハイフン編集テキストボックスフォーカス時、ハイフン除去
	$(".tekiyo").focus(function() {
		this.value = removeHyphen(this.value);
		this.select();
	})

	// 摘要 ハイフン編集テキストボックスロストフォーカス時、ハイフン付与
	$(".tekiyo").blur(function() {
		// カンマ付きテキストの貼り付け対応
		this.value = formatTekiyoHyphen(this.value);
	})

	if ($(".tmsg").height() > 0 || $(".terr").height() > 0) {
		$("#header_menu").css("display", "none")
	}

	// Enterキー押下で最初のボタンを送信させない
	$(window).keypress(
			function(ev) {
				if ((ev.which && ev.which == 13)
						|| (ev.keyCode && ev.keyCode == 13)) {
					if (document.activeElement.type == "submit"
							|| document.activeElement.type == "button") {

						if (isLoadingViewDisplayNone()) {
							return true;
						} else {
							return false;
						}

					} else if (document.activeElement.type == "textarea") {
						//textarea内のEnterで改行を可能にする。
						return true;
					} else if(getSearchButtonId() != ""){
						document.getElementById(getSearchButtonId()).click();
						return true;
					} else {
						return false;
					}
				} else {
					return true;
				}
			});
	
	// 編集フラグを立てる
	$('#content').change(function() {
		setEditFlg();
	});

	// 編集フラグを立てる
	$('#editItem').change(function() {
		setEditAlertFlg();
	});

	// オンロード処理
	$(document).ready(function() {
		// カンマ編集テキストボックス存在時、カンマ付与
		$(".comma").each(function() {
			$(this).val(formatComma($(this).val()));
		});
		// 科目編集テキストボックス存在時、ハイフン付与
		$(".kamoku").each(function() {
			$(this).val(formatKamokuHyphen($(this).val()));
		});
		// 摘要編集テキストボックス存在時、ハイフン付与
		$(".tekiyo").each(function() {
			$(this).val(formatTekiyoHyphen($(this).val()));
		});
	});

	// カンマ編集テキストが存在する場合、submitボタンのクリックイベントでカンマ除去
	if ($(".comma").length > 0) {
		$(':submit').click(function() {
			$(".comma").each(function() {
				$(this).val(removeComma($(this).val()));
			});
		})
	}
	/*
	// 科目編集テキストが存在する場合、submitボタンのクリックイベントでハイフン除去
	if ($(".kamoku").size() > 0) {
		$(':submit').click(function() {
			$(".kamoku").each(function() {
				$(this).val(removeHyphen($(this).val()));
			});
		})
	}
	// 摘要編集テキストが存在する場合、submitボタンのクリックイベントでハイフン除去
	if ($(".tekiyo").size() > 0) {
		$(':submit').click(function() {
			$(".tekiyo").each(function() {
				$(this).val(removeHyphen($(this).val()));
			});
		})
	}
*/
	// Formサブミット時に処理中を出す。
	$("form").submit(function() {

		let inputObjectArray = [];
		const inputObject = document.getElementsByClassName("inputObject");

		$.each(inputObject, function(i, value) {
			const obj = inputObject[i];
			
			if(obj.type === "radio") {
				console.log(obj.name);
				if($.inArray(obj.name, inputObjectArray) == -1) {
					inputObjectArray.push(obj.name);
				}
				
			} else {
				console.log(obj.id);
				if($.inArray(obj.id, inputObjectArray) == -1) {
					inputObjectArray.push(obj.id);
				}
			}
		});

		
		console.log("取得した入力要素一覧");
		let inputObjectHidden = "";
		$.each(inputObjectArray, function(i, value) {
			console.log(value);
			inputObjectHidden += value + ",";
		});
		
		console.log(inputObjectHidden);
		$("#inputObjects").val(inputObjectHidden);
		
		if (isLoadingViewDisplayNone()) {
			addLoadingView();

			return true;
		} else {
			return false;
		}

	});

	// 処理中表示を削除
	removeLoadingView();

});

/**
 * Enterキーで検索可能な時、検索ボタンのスタイルIDを返す。<br />
 * 必要に応じて、各画面のjspで実装する。
 * @return 検索ボタンのプロパティ名
 */
function getSearchButtonId() {
	return "";
}

/**
 * Enterキーで検索
 *
 * @param searchNm
 *            検索ボタンのプロパティ名
 */
function enterSearch(searchNm) {
	var event = null;
	if (window.event) {
		event = window.event
	} else {
		event = getEvent(KeyboardEvent);
	}
	if (event.keyCode == 13 && oneSubmit()) {
		var form = document.forms[0];
		var nowAction = form.action;

		form.elements[searchNm].focus();
		form.action = form.action + searchNm;
		form.method = "post";
		form.submit();
		form.action = nowAction; // actionを戻す

	}
}

/**
 * submit
 *
 * @param url
 */
function formSubmit(url) {
	var form = document.forms[0];
	if (isLoadingViewDisplayNone()) {

		form.action = url;
		form.method = "post";
		form.submit();
	}
	return false;
}

/**
 * submit
 *
 * @param url
 */
function formSubmitForSearchNm(searchNm) {
	var form = document.forms[0];
	var nowAction = form.action;
	if (isLoadingViewDisplayNone()) {
		addLoadingView();
		form.action = form.action + searchNm;
		form.method = "post";
		form.submit();
		form.action = nowAction; // actionを戻す
	}
	return false;
}



/**
 * メニューバーからの遷移
 *
 * @param url
 */
function menuBarSubmit(url, menuId) {
	var form = document.forms[0];
	if (isLoadingViewDisplayNone()) {
		addLoadingView();
		var gymMenuId = $("#gymMenuId").val();
		location.href = url + "?menuId=" + menuId + "&gymMenuId=" + gymMenuId
				+ "&forwardMenuBarFlg=1"
	}
	return false;
}

/**
 * 処理中チェック無しでFormをsubmitする。 ※通常は使用不可
 *
 * @param url
 */
function formSubmitCompel(url) {
	var form = document.forms[0];

	form.action = url;
	form.method = "post";
	form.submit();

	return true;
}

/**
 * 処理中チェック無しでFormをsubmitする。 ※通常は使用不可
 *
 * @param url
 */
function formGetSubmitCompel(url) {
	var form = document.forms[0];

	form.action = url;
	form.method = "get";
	form.submit();

	return true;
}

/** 最初のサブミットのみ有効 */
var submitFlg = false;

/**
 * 通常submit
 *
 * @return
 */
function oneSubmit() {
	if (isLoadingViewDisplayNone()) {
		return true;
	}
	return false;
}

/**
 * ﾘﾝｸクリック時の送信可／不可判定
 *
 * @return
 */
function linkSubmit() {
	if (isLoadingViewDisplayNone()) {
		if (getEditFlgValue() == "1") {
			if (confirm('編集内容は保存されません。よろしいですか？') == false) {
				return false;
			}
		}
		addLoadingView();
		return true;
	}
	return false;
}

/**
 * ﾘﾝｸクリック時の送信可／不可判定
 *
 * @return
 */
function linkSubmitAddQuery(url, query) {
	if (isLoadingViewDisplayNone()) {
		if (getEditFlgValue() == "1") {
			if (confirm('編集内容は保存されません。よろしいですか？') == false) {
				return false;
			}
		}
		if (query != null && query.length > 0) {
			url = url + document.getElementById(query).value;
		}
		location.href = url;
	}
	return false;
}

function deleteConfirm() {
	return oneSubmitConfirm('削除します。よろしいですか？');
}

function clearConfirm() {
	return oneSubmitConfirm('クリアします。よろしいですか？');
}

function editConfirm() {
	if (isLoadingViewDisplayNone()) {
		if (getEditFlgValue() == "1") {
			if (confirm('編集内容は保存されません。よろしいですか？') == false) {
				return false;
			}
		}
		return true;
	} else {
		return false;
	}
}

function editAlertConfirm() {
	if (isLoadingViewDisplayNone()) {
		if (getEditAlertFlgValue() == "1") {
			if (confirm('編集内容は保存されません。よろしいですか？') == false) {
				return false;
			}
		}
		return true;
	} else {
		return false;
	}
}

function csvConfirm() {
	return oneSubmitConfirm("CSVファイルを作成します。よろしいでしょうか？\n\n画面の表示内容でCSVファイルを作成します。\n検索条件を変更後に検索ボタンを押していない場合、再検索してからCSV作成ボタンを押して下さい。");
}

function excelConfirm() {
	return oneSubmitConfirm("EXCELファイルを作成します。よろしいでしょうか？\n\n画面の表示内容でEXCELファイルを作成します。\n検索条件を変更後に検索ボタンを押していない場合、再検索してからEXCEL作成ボタンを押して下さい。");
}

/**
 * confirm付きsubmit
 *
 * @param msg
 * @return
 */
function oneSubmitConfirm(msg) {
	if (isLoadingViewDisplayNone()) {
		return confirm(msg);
	} else {
		return false;
	}
}

// 処理中ダイアログが表示されているかどうかを判定する。
function isLoadingViewDisplayNone() {

	if (loadingView.style.display == 'none') {
		return true;
	} else {
		return false;
	}

}

// 処理中ダイアログを表示する。
function addLoadingView() {

	loadingView.style.display = '';
	return true;
}

// 処理中ダイアログを削除する
function removeLoadingView() {
	loadingView.style.display = 'none';
	return true;
}

// ファイルダウンロード時、2回目のサブミットを行う
function realDownload(objNm) {
	var flg = document.forms[0].elements[objNm];
	if (flg == null) {
	} else if (flg.value == "1") {

		document.forms[0].submit();
		document.forms[0].elements[objNm].value = "";
	}
}

/**
 * フォーカスセット（単一項目）
 *
 * @param objNm
 *            フォーカスをセットするオブジェクト名
 */
function focusEventSingle(objNm) {
	var form = document.forms[0];
	var obj = document.getElementById(objNm);
	if (obj == undefined) {
		obj = form.elements[objNm];
	}

	if (obj != undefined) {
		obj.focus();
	}
}

/**
 * フォーカスセット（複数項目）<br>
 * 1つ目が駄目だったら2つ目以降を試す
 *
 * @param objNm
 *            フォーカスをセットするオブジェクト名の配列
 */
function focusEvent(objNm) {
	var objNmArray = objNm;
	if (typeof (objNm) == 'string') {
		objNmArray = new Array(objNm);
	}
	var form = document.forms[0];
	for (var i = 0; i < objNmArray.length; i++) {
		var obj = document.getElementById(objNmArray[i]);
		if (obj == undefined) {
			obj = form.elements[objNmArray[i]];
		}
		try {
			if (obj != undefined && !obj.disabled && obj.type != "hidden") {
				obj.focus();
				break;
			}
		} catch (ex) {
		}
	}
}

/**
 * 一括選択チェックボックス処理
 *
 * @param all
 *            一括選択チェックボックスID
 * @param dist
 *            各行チェックボックス名
 */
function allChecked(all, dist) {
	var check = document.getElementById(all).checked;
	for (var i = 0; i < document.getElementsByName(dist).length; i++) {
		document.getElementsByName(dist)[i].checked = check;
	}
}

/**
 * 一括選択チェックボックス処理（リスト明細チェックボックス）
 *
 * （注意）IDをnameの生成結果同様、 「リスト名[インデックス].プロパティ名」とする必要がある
 *
 * @param all
 *            一括選択チェックボックスID
 * @param dist
 *            各行チェックボックス名
 * @param cnt
 *            件数
 *
 * function allCheckedList(all, lstNm, dist, cnt) { var check =
 * document.getElementById(all).checked; for (var i = 0; i < cnt; i++) {
 * document.getElementById(lstNm + "[" + i + "]." + dist).checked = check; } }
 */

/**
 * 編集フラグを立てる<br>
 * 存在しない場合は無処理
 */
function setEditFlg() {
	if (document.getElementById("editFlg")) {
		document.getElementById("editFlg").value = "1";
	}
}

/**
 * 編集フラグの値を取得する<br>
 * 存在しない場合は、"0"（編集なし）とする
 *
 * @returns 編集フラグの値
 */
function getEditFlgValue() {
	var value = null;
	if (document.getElementById("editFlg")) {
		value = document.getElementById("editFlg").value;
	} else {
		value = "0"; // 編集なし
	}
	return value;
}

/**
 * 編集アラートフラグを立てる<br>
 * 存在しない場合は無処理
 */
function setEditAlertFlg() {
	if (document.getElementById("editAlertFlg")) {
		document.getElementById("editAlertFlg").value = "1";
	}
}

/**
 * 編集アラートフラグの値を取得する<br>
 * 存在しない場合は、"0"（編集なし）とする
 *
 * @returns 編集フラグの値
 */
function getEditAlertFlgValue() {
	var value = null;
	if (document.getElementById("editAlertFlg")) {
		value = document.getElementById("editAlertFlg").value;
	} else {
		value = "0"; // 編集なし
	}
	return value;
}

/*
 * 明細行数がスクロールバー必須の時、左側にスクロールバーを追加する。 ※一覧表とそれを含むdivを "tbl_scroll"で定義していることが前提。
 */
var setTimeoutId = null ;	/* setTimeout()を管理 */

function addScrollOnLoad() {

	// 一覧表とそれを含むdiv
	var div = document.getElementById("tbl_scroll");
	if (div == null) {
		return;
	}
	var tbl = document.getElementById("ichiranhyo");
	if (tbl == null) {
		return;
	}
	// alert("addScrollOnLoad. 1 div="+div.offsetHeight+",
	// tbl="+tbl.offsetHeight);
	// alert("addScrollOnLoad. 1 div="+div.height+", tbl="+tbl.height);
	// alert("addScrollOnLoad. 1 div="+div.style.height+",
	// tbl="+tbl.style.height);

	// スクロールが不要の場合は終わり
	if (div.offsetHeight >= tbl.offsetHeight) {
		return;
	}

	// 左のスクロールのdivとその中身
	var tbl_scroll_left_obj = document.getElementById("tbl_scroll_left");
	if (tbl_scroll_left_obj == null) {
		return;
	}
	var tbl_scroll_left_contents_obj = document
			.getElementById("tbl_scroll_left_contents");
	if (tbl_scroll_left_contents_obj == null) {
		return;
	}
	// alert("addScrollOnLoad. 2
	// div="+div.style.height+",tbl="+tbl.style.height+",tbl="+tbl.height);
	// alert("addScrollOnLoad. div.offsetWidth="+div.offsetWidth+",
	// div.offsetHeight="+div.offsetHeight+",tbl.offsetHeight="+tbl.offsetHeight+",div.top="+div.top+",
	// div.left="+div.left+",div.style.top="+div.style.top+",
	// div.style.left="+div.style.left+",div.offsetTop="+div.offsetTop+",
	// div.offsetLeft="+div.offsetLeft);

	// 左にスクロールバー分の隙間をあける
	document.getElementById("content_middle").style.marginLeft = "25px";

	// 隙間にスクロールバーを置く
	tbl_scroll_left_obj.style.height = div.offsetHeight + "px";
	tbl_scroll_left_contents_obj.style.height = tbl.offsetHeight + "px";
	tbl_scroll_left_obj.style.position = "absolute";
	tbl_scroll_left_obj.style.top = div.offsetTop + "px";
	tbl_scroll_left_obj.style.left = "2px";
	tbl_scroll_left_obj.style.display = "";
	// alert("addScrollOnLoad. height="+
	// obj2.style.height+","+obj3.style.height);

	// 左右スクロールバーを動かしたときに同期をとるようにイベントを追加
	tbl_scroll_left_obj.addEventListener('scroll', function() {
		var div = document.getElementById("tbl_scroll");
		var obj2 = document.getElementById("tbl_scroll_left");
		if (div == null) {
			return;
		}
		if (obj2 == null) {
			return;
		}

		if( setTimeoutId ) {
			return false ;
		}
		
		setTimeoutId = setTimeout( function() {
			div.scrollTop = tbl_scroll_left.scrollTop;
			setTimeoutId = null ;
		}, 200 ) ;
	
	}, false);

	div.addEventListener('scroll', function() {
		var div = document.getElementById("tbl_scroll");
		var obj2 = document.getElementById("tbl_scroll_left");
		if (div == null) {
			return;
		}
		if (obj2 == null) {
			return;
		}

		if( setTimeoutId ) {
			return false ;
		}

		setTimeoutId = setTimeout( function() {
			obj2.scrollTop = div.scrollTop;
			setTimeoutId = null ;
		}, 200 ) ;
		
	}, false);

}

/**
 *  テキストエリアでタブ入力可能にする
 * @param o
 * @param e
 * @returns {Boolean}
 */
function insertTab(o, e) {
	var kC = e.keyCode ? e.keyCode : e.charCode ? e.charCode : e.which;
	if (kC == 9 && !e.shiftKey && !e.ctrlKey && !e.altKey) {
		var oS = o.scrollTop;
		if (o.setSelectionRange) {
			var sS = o.selectionStart;
			var sE = o.selectionEnd;
			o.value = o.value.substring(0, sS) + "\t" + o.value.substr(sE);
			o.setSelectionRange(sS + 1, sS + 1);
			o.focus();
		} else if (o.createTextRange) {
			document.selection.createRange().text = "\t";
			e.returnValue = false;
		}
		o.scrollTop = oS;
		if (e.preventDefault) {
			e.preventDefault();
		}
		return false;
	}
	return true;
}

/**
 * 販売拠点のチェックボックスを制御する。 すべて（all)が選択されたときは、それ以外のチェックボックスを全て外す。
 * すべて（all)以外が選択されたときは、すべて（all)のチェックボックスを外す。
 *
 * @param obj
 *            クリックされたオブジェクト
 */
function hanbaiKyotenOnChange(obj) {

	var elements = document.getElementsByClassName("hanbaiKyotenCdCheck");

	for (i = 0; i < elements.length; i++) {

		if (obj.value == "all" && obj.checked) {

			if (elements[i].value != "all") {
				elements[i].checked = false;
			}

		} else if (obj.value != "all" && obj.checked) {
			if (elements[i].value == "all") {
				elements[i].checked = false;
			}
		}

	}

}

/**
 * 新規ウィンドウ（タブ）を開く<br>
 *
 * @param url 画面URL
 */
function openChildWindow(url) {
	//子画面を開く
	window.open(url);
}

/**
 * 債権バッチ処理が稼働中の時、画面に表示しているエラーメッセージをアラートでも表示します。
 */
function onAlertSaikenBatchKado() {

	var flgDisp = document.getElementById("saikenBatchKadoFlg");

	if (flgDisp != undefined && flgDisp.value == "1") {

		var errorMessage = document.getElementsByClassName("terr")[0];
		alert(errorMessage.innerText);
	}
}

/**
 * カンマ編集解除
 * @param str 編集対象の文字列
 * @returns カンマを取り除いた文字列
 */
function removeComma(str) {
	rtnValue = str.replace(/,/g, "");
	rtnValue = rtnValue.replace("*", "");

	return rtnValue;
}

/**
 * カンマ編集
 * @param str 編集対象の文字列
 * @returns カンマを付与した文字列
 */
function formatComma(str) {
	rtnValue = "";
	str = $.trim(str);
	strLen = str.length;
	iPoint = 0;
	if (str.substring(0, 1) == "-") {
		rtnValue = str.substring(0, 1);
		str = str.substring(1);
		strLen = strLen - 1;
	}

	if (strLen > 3) {
		iMod = strLen % 3;
		if (iMod != 0) {
			rtnValue = rtnValue + str.substring(0, iMod) + ",";
		}
		for (i = 0; i < (strLen - iMod) / 3; i++) {
			rtnValue = rtnValue
					+ str.substring(iMod + (3 * i), iMod + (3 * (i + 1)));
			if (iMod + 3 * (i + 1) != strLen) {
				rtnValue = rtnValue + ",";
			}
		}
	} else {
		rtnValue = rtnValue + str;
	}

	return rtnValue;
}

/*******************************************************************************
 * ================================================== /* 科目 ハイフン編集解除 /* 引数：変換元 /*
 * 戻り値：変換後 /*==================================================
 */
function removeHyphen(str) {
	rtnValue = str.replace(/-/g, "");
	rtnValue = rtnValue.replace("*", "");

	return rtnValue;
}

/*******************************************************************************
 * ================================================== /* 科目ハイフン編集 /* 引数：変換元 /*
 * 戻り値：変換後 /*==================================================
 */
function formatKamokuHyphen(str) {
	rtnValue = "";
	strLen = str.length;

	if (strLen == 8) {
		rtnValue = str.substring(0, 4) + "-" + str.substring(4, 6) + "-"
				+ str.substring(6, 8);
	} else {
		rtnValue = str;
	}

	return rtnValue;
}

/*******************************************************************************
 * ================================================== /* 摘要ハイフン編集 /* 引数：変換元 /*
 * 戻り値：変換後 /*==================================================
 */
function formatTekiyoHyphen(str) {
	rtnValue = "";
	strLen = str.length;

	if (strLen == 8) {
		rtnValue = str.substring(0, 2) + "-" + str.substring(2, 4) + "-"
				+ str.substring(4, 8);
	} else {
		rtnValue = str;
	}

	return rtnValue;
}

/*==============================================================*/
/* スクロールDIVの高さを設定
 * （bodyタグのonloadでコール）
 /*==============================================================*/
function changeHeight(fixHeight) {
	var height = document.documentElement.clientHeight
			|| document.body.clientHeight;
	if (document.getElementById("content_middle")) {
		var tblHeight = document.getElementById("content_middle").offsetHeight;
		var msgHeight = document.getElementById("message").offsetHeight;
		var errHeight = 0;
		if (document.getElementById("content_err")) {
			errHeight = document.getElementById("content_err").offsetHeight;
		}
		if (msgHeight > 0)
			msgHeight = msgHeight + 5;
		var divHeight = parseInt(height) - parseInt(fixHeight) - msgHeight
				- parseInt(errHeight);
		if (height >= fixHeight + parseInt(tblHeight))
			return;
		document.getElementById("content_middle").style.height = divHeight
				+ "px";
	}
}

/**
 * 日付TO項目にフォーカスが当たった時、日付FROM項目に正しい日付が入力されていたら日付TOにも同じ値を入れる。<br />
 * ただし、日付TOに既に値が入っている場合は何もしない。<br />
 * jspでは onfocus="focusDateTo('日付FROM項目のID','日付TO項目のID');" と書く。
 * @param fromObjName 日付FROMのID
 * @param toObjName 日付TOのID
 */
function focusDateTo(fromObjId, toObjId) {

	var fromObj = document.getElementById(fromObjId);
	if (fromObj == undefined || fromObj.value == '') {
		return;
	}

	var toObj = document.getElementById(toObjId);
	if (toObj == undefined || toObj.value != '') {
		return;
	}

	var fromObjValue = fromObj.value;

	if (isDate(fromObjValue)) {
		$('#' + selectorEscape(toObjId)).datepicker().datepicker("setDate", fromObjValue);

	}

}

function selectorEscape(val){
    return val.replace(/[ !"#$%&'()*+,.\/:;<=>?@\[\\\]^`{|}~]/g, '\\$&');
}

/**
 * 日付が妥当かチェックする。
 * @param inputDate チェック対象の日付
 * @returns {Boolean} 日付ならtrue、そうでないならfalse
 */
function isDate(inputDate) {
	var data = inputDate;
	if (data == '' || data.length < 8) {
		return false;
	}

	var rxDatePattern = /^(\d{4})(\d{1,2})(\d{1,2})$/;
	var dtArray = data.match(rxDatePattern);
	if (dtArray == null) {
		return false;
	}
	dtYear = dtArray[1];
	dtMonth = dtArray[2];
	dtDay = dtArray[3];
	if (dtMonth < 1 || dtMonth > 12) {
		return false;
	} else if (dtDay < 1 || dtDay > 31) {
		return false;
	} else if ((dtMonth == 4 || dtMonth == 6 || dtMonth == 9 || dtMonth == 11)
			&& dtDay == 31) {
		return false;
	} else if (dtMonth == 2) {
		var isleap = (dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0));
		if (dtDay > 29 || (dtDay == 29 && !isleap)) {
			return false;
		}
	}
	return true;
}


function convertShoBng(shoBng) {

	if(shoBng == undefined || shoBng == '' || shoBng.length > 11) {
		return;
	}

    var value1 = '';
    var value2 = '';

    // 一つ目の半角スペース位置取得
    var iPos = shoBng.indexOf(' ');
    if (iPos == -1) {
        // 半角スペースがない場合、一つ目のハイフン位置取得
        iPos = shoBng.indexOf('-');

        if (iPos > -1) {
            // 文字数が一致していて半角スペースがなく、途中にハイフンがある場合、半角スペースに変換
            if (shoBng.length == 11) {
                if (shoBng.length > iPos + 1) {
                    value1 = shoBng.substring(0, iPos).toUpperCase();
                    value2 = shoBng.substring(iPos + 1).toUpperCase();
                    return value1 + ' ' + value2;
                }
            }
        }
    }

    if (shoBng.length == 11) {
        // 文字数が一致している場合、大文字変換のみ行う
        return value.toUpperCase();
    }

    if (iPos > -1) {
        // 一つ目の半角スペース/ハイフンで品番を区切る
        value1 = shoBng.substring(0, iPos).trim().toUpperCase();
        if (shoBng.length > iPos) {
            value2 = shoBng.substring(iPos + 1).trim().toUpperCase();
        }
    }

    if (value1.length == 0 || value2.length == 0
            || value1.length + value2.length >= 11) {
        // 一つ目の半角スペース/ハイフンがない場合、右スペース埋め
        return paddingright(shoBng, ' ',11);
    }

    var editShoBng = value1 + paddingleft(value2,' ',11 - value1.length);
    return editShoBng;
}

/**
右埋めする処理
指定桁数になるまで対象文字列の右側に
指定された文字を埋めます。
@param val 右埋め対象文字列
@param char 埋める文字
@param n 指定桁数
@return 右埋めした文字列
**/
function paddingright(val,char,n){
	for(; val.length < n; val+=char);
	return val;
}

/**
左埋めする処理
指定桁数になるまで対象文字列の左側に
指定された文字を埋めます。
@param val 左埋め対象文字列
@param char 埋める文字
@param n 指定桁数
@return 左埋めした文字列
**/
function paddingleft(val,char,n){
	var leftval = "";
	for(;leftval.length < n;leftval+=char);
	return (leftval+val).slice(-n);
}