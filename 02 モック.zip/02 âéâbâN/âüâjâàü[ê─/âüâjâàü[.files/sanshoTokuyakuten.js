$(function() {

	console.log("parts/sansho");

	$("#sanshoTokuyakuten").draggable();

	$("#closeSanshoTokyakuten,#closeSanshoTokyakutenX").click(function() {
		closeSanshoTokuyakuten();
	});

	$("#searchSanshoTokuyakuten").click(
			function() {

				let param = {};
				param["vapTokuyakutenCdFrom"] = $(
						"#sanshoTokuyakuten_vapTokuyakutenCdFrom").val();
				param["vapTokuyakutenCdTo"] = $(
						"#sanshoTokuyakuten_vapTokuyakutenCdTo").val();
				param["jdsTokuyakutenCdFrom"] = $(
						"#sanshoTokuyakuten_jdsTokuyakutenCdFrom").val();
				param["jdsTokuyakutenCdTo"] = $(
						"#sanshoTokuyakuten_jdsTokuyakutenCdTo").val();
				param["tokuyakutenNm"] = $("#sanshoTokuyakuten_tokuyakutenNm")
						.val();

				const contextPath = $('#contextPath').val();

				$.ajax({
					type : "POST",
					url : contextPath + "/api/tokuyakuten/sansho",
					data : JSON.stringify(param),
					contentType : 'application/json',
					dataType : "json"
				}).then(function(data) {
					successSanshoTokuyakuten(data);
				}, function() {
					$("#sanshoTokuyakutenMessageArea").text("予期せぬエラーが発生しました。");
				});

			});

});

/**
 * Ajax通信に成功時の処理
 * 
 * @param data
 * @returns
 */
function successSanshoTokuyakuten(data) {

	const message = data["message"];

	$("#sanshoTokuyakutenMessageArea").text(message);

	$("#sanshoTokuyakutenTableArea table tbody tr").each(function(index, elm) {
		$(elm).remove();
	});

	const list = data["data"];
	let tbody = $("#sanshoTokuyakutenTableArea table tbody");
	for (let cnt = 0; cnt < list.length; cnt++) {

		const meisai = list[cnt];

		const vap = meisai["vapTokuyakutenCd"];
		const jds = meisai["jdsTokuyakutenCd"];
		const nm = meisai["tokuyakutenNm"];

		const html = '<tr>'
				+ '<td style="width: 20px;text-align:right;">'
				+ (cnt + 1)
				+ '</td>'
				+ '<td style="width: 70px;text-align:center;">'
				+ '<button type="button" style="width:45px";text-align:center; onclick="choiceSanshoTokuyakuten(\''
				+ vap + '\')" >選択</button>' + '</td>'
				+ '<td style="width: 115px;"><span id="sanshoTokuyakuten_vap_'
				+ (cnt + 1) + '">' + vap + '</span></td>'
				+ '<td style="width: 115px;">' + jds + '</td>'
				+ '<td style="width: 270px;">' + nm + '</td>' + '</tr>';

		tbody.append(html);

	}
}

/**
 * Ajax通信失敗時処理
 * 
 * @param XMLHttpRequest
 * @param textStatus
 * @param errorThrown
 * @returns
 */
function errorSanshoTokuyakuten(XMLHttpRequest, textStatus, errorThrown) {
	console.log("error:" + XMLHttpRequest);
	console.log("status:" + textStatus);
	console.log("errorThrown:" + errorThrown);
	$("#sanshoTokuyakutenMessageArea").text("予期せぬエラーが発生しました。");
}

/**
 * 特約店検索子画面を開く。
 * 
 * @param fieldId
 *            親画面の特約店コードのID
 */
function openSanshoTokuyakuten(fieldId) {

	$("#sanshoTokuyakuten").fadeIn();
	$("#sanshoTokuyakuten_callFieldId").val(fieldId);
	clearSanshoTokuyakuten();

}

/**
 * 選択した行のVAP特約店コードを親画面に渡す。
 */
function choiceSanshoTokuyakuten(vapTokuyakutenCd) {

	const callFieldId = $("#sanshoTokuyakuten_callFieldId").val();
	$("#" + callFieldId).val(vapTokuyakutenCd);
	$("#" + callFieldId).change();
	
	closeSanshoTokuyakuten();
}

/**
 * 特約店検索子画面を初期化する。
 */
function clearSanshoTokuyakuten() {
	$("#sanshoTokuyakuten_vapTokuyakutenCdFrom").val("");
	$("#sanshoTokuyakuten_vapTokuyakutenCdTo").val("");
	$("#sanshoTokuyakuten_jdsTokuyakutenCdFrom").val("");
	$("#sanshoTokuyakuten_jdsTokuyakutenCdTo").val("");
	$("#sanshoTokuyakuten_tokuyakutenNm").val("");

	let tr = $("#sanshoTokuyakutenTableArea table tbody tr");
	$("#sanshoTokuyakutenTableArea table tbody tr").each(function(index, elm) {
		$(elm).remove();
	});

	$("#sanshoTokuyakutenMessageArea").text("条件を入力し、検索ボタンを押してください。");

}

/**
 * 特約店検索子画面を閉じる。
 */
function closeSanshoTokuyakuten() {
	$("#sanshoTokuyakuten").fadeOut();
}

/**
 * 特約店コードを変更したとき、特約店名称を取得する。
 * 
 * @param tokuyakutenCdObject
 *            特約店コードが入っているオブジェクト
 * @param tokuyakutenNmDisplayAreaId
 *            特約店名を表示する場所
 * @param tokuyakutenNmHiddenId
 *            特約店名称を保持するhidden
 * @returns
 */
function searchTokuyakutenCd(tokuyakutenCdObject, tokuyakutenNmDisplayAreaId,
		tokuyakutenNmHiddenId) {

	const tokuyakutenCd = tokuyakutenCdObject.value;

	// 先に初期化
	$("#" + tokuyakutenNmDisplayAreaId).html("");
	$("#" + tokuyakutenNmHiddenId).val("");

	// 未入力時は処理終了
	if (!tokuyakutenCd) {
		return;
	}

	// TODO 名称取得 ajax呼び出し
	let param = {};
	param["tokuyakutenCd"] = tokuyakutenCd;

	const contextPath = $('#contextPath').val();

	$.ajax({
		type : "POST",
		url : contextPath + "/api/tokuyakuten/search",
		data : JSON.stringify(param),
		contentType : 'application/json',
		dataType : "json",
		success : function(data) {
			successSearchTokuyakutenCd(data, tokuyakutenNmDisplayAreaId,
					tokuyakutenNmHiddenId);
		},
		error : function(XMLHttpRequest, textStatus, errorThrown) {
			errorSearchTokuyakutenCd(XMLHttpRequest, textStatus, errorThrown);
		}
	});

}

/**
 * Ajax通信に成功時の処理
 * 
 * @param data
 *            受け取った値
 * @param tokuyakutenNmDisplayAreaId
 *            特約店名を表示する場所
 * @param tokuyakutenNmHiddenId
 *            特約店名称を保持するhidden
 * @returns
 */
function successSearchTokuyakutenCd(data, tokuyakutenNmDisplayAreaId,
		tokuyakutenNmHiddenId) {

	const list = data["data"];
	if(list.length == 0 ) {
		console.log("listのサイズがゼロ");
		return;
	}
	
	const meisai = list[0];
	
	$("#" + tokuyakutenNmDisplayAreaId).html(meisai["tokuyakutenNm"]);
	$("#" + tokuyakutenNmHiddenId).val(meisai["tokuyakutenNm"]);

}

/**
 * Ajax通信失敗時処理
 * 
 * @param XMLHttpRequest
 * @param textStatus
 * @param errorThrown
 * @returns
 */
function errorSearchTokuyakutenCd(XMLHttpRequest, textStatus, errorThrown) {
	console.log("error:" + XMLHttpRequest);
	console.log("status:" + textStatus);
	console.log("errorThrown:" + errorThrown);

}