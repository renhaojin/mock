$(function() {

	console.log("parts/sansho");

	$("#sanshoShohin").draggable();

	$("#closeSanshoShohin,#closeSanshoShohinX").click(function() {
		closeSanshoShohin();
	});

	$("#searchSanshoShohin")
			.click(
					function() {

						let param = {};
						param["shohinCdKikakuParts"] = $(
								"#sanshoShohin_shohinCdKikakuParts").val();
						param["shohinCdBangoPartsFrom"] = $(
								"#sanshoShohin_shohinCdBangoPartsFrom").val();
						param["shohinCdBangoPartsTo"] = $(
								"#sanshoShohin_shohinCdBangoPartsTo").val();
						param["hatsuDateFrom"] = $(
								"#sanshoShohin_hatsuDateFrom").val();
						param["hatsuDateTo"] = $(
								"#sanshoShohin_hatsuDateTo").val();
						param["title"] = $(
								"#sanshoShohin_title").val();
						param["artist"] = $(
								"#sanshoShohin_artist").val();

						const contextPath = $('#contextPath').val();

						$.ajax({
							type : "POST",
							url : contextPath + "/api/shohin/sansho",
							data : JSON.stringify(param),
							contentType : 'application/json',
							dataType : "json"
						}).then(
								function(data) {
									successSanshoShohin(data);
								},
								function() {
									$("#sanshoShohinMessageArea").text(
											"予期せぬエラーが発生しました。");
								});

					});

});

/**
 * Ajax通信に成功時の処理
 * 
 * @param data
 * @returns
 */
function successSanshoShohin(data) {

	const message = data["message"];

	$("#sanshoShohinMessageArea").text(message);

	$("#sanshoShohinTableArea table tbody tr").each(function(index, elm) {
		$(elm).remove();
	});

	const list = data["data"];
	let tbody = $("#sanshoShohinTableArea table tbody");
	for (let cnt = 0; cnt < list.length; cnt++) {

		const meisai = list[cnt];

		const shohinCd = meisai["shohinCd"];
		const title = meisai["title"];
		const artist = meisai["artist"];
		const hatsuDate = meisai["hatsuDateStr"];

		const html = '<tr>'
				+ '<td style="width: 20px;text-align:right;">'
				+ (cnt + 1)
				+ '</td>'
				+ '<td style="width: 70px;text-align:center;">'
				+ '<button type="button" style="width:45px";text-align:center; onclick="choiceSanshoShohin(\''
				+ shohinCd + '\')" >選択</button>' + '</td>'
				+ '<td style="width: 100px;"><span id="sanshoShohin_shohinCd_'
				+ (cnt + 1) + '">' + shohinCd + '</span></td>'
				+ '<td style="width: 250px;">' + title + '</td>'
				+ '<td style="width: 250px;">' + artist + '</td>'
				+ '<td style="width: 100px;">' + hatsuDate + '</td>' + '</tr>';

		tbody.append(html);

	}
}

/**
 * Ajax通信失敗時処理
 * 
 * @param XMLHttpRequest
 * @param textStatus
 * @param errorThrown
 * @returns
 */
function errorSanshoShohin(XMLHttpRequest, textStatus, errorThrown) {
	console.log("error:" + XMLHttpRequest);
	console.log("status:" + textStatus);
	console.log("errorThrown:" + errorThrown);
	$("#sanshoShohinMessageArea").text("予期せぬエラーが発生しました。");
}

/**
 * 商品コード検索子画面を開く。
 * 
 * @param fieldId
 *            親画面の特約店コードのID
 */
function openSanshoShohin(fieldId) {

	$("#sanshoShohin").fadeIn();
	$("#sanshoShohin_callFieldId").val(fieldId);
	clearSanshoShohin();

}

/**
 * 選択した行のVAP特約店コードを親画面に渡す。
 */
function choiceSanshoShohin(vapTokuyakutenCd) {

	const callFieldId = $("#sanshoShohin_callFieldId").val();
	$("#" + callFieldId).val(vapTokuyakutenCd);
	$("#" + callFieldId).change();

	closeSanshoShohin();
}

/**
 * 商品コード検索子画面を初期化する。
 */
function clearSanshoShohin() {
	$("#sanshoShohin_shohinCdKikakuParts").val("");
	$("#sanshoShohin_shohinCdBangoPartsFrom").val("");
	$("#sanshoShohin_shohinCdBangoPartsTo").val("");
	$("#sanshoShohin_hatsuDateFrom").val("");
	$("#sanshoShohin_hatsuDateTo").val("");
	$("#sanshoShohin_title").val("");
	$("#sanshoShohin_artist").val("");

	let tr = $("#sanshoShohinTableArea table tbody tr");
	$("#sanshoShohinTableArea table tbody tr").each(function(index, elm) {
		$(elm).remove();
	});

	$("#sanshoShohinMessageArea").text("条件を入力し、検索ボタンを押してください。");

}

/**
 * 商品コード検索子画面を閉じる。
 */
function closeSanshoShohin() {
	$("#sanshoShohin").fadeOut();
}

/**
 * 商品コードを変更したとき、タイトルを取得する。
 * 
 * @param shohinCdObject
 *            特約店コードが入っているオブジェクト
 * @param titleDisplayAreaId
 *            タイトルを表示する場所
 * @param titleHiddenId
 *            タイトル称を保持するhidden
 * @returns
 */
function searchShohinCd(shohinCdObject, titleDisplayAreaId, titleHiddenId) {

	const shohinCd = shohinCdObject.value;

	// 先に初期化
	$("#" + titleDisplayAreaId).html("");
	$("#" + titleHiddenId).val("");

	// 未入力時は処理終了
	if (!shohinCd) {
		return;
	}

	// TODO 名称取得 ajax呼び出し
	let param = {};
	param["shohinCd"] = shohinCd;

	const contextPath = $('#contextPath').val();

	$.ajax({
		type : "POST",
		url : contextPath + "/api/shohin/search",
		data : JSON.stringify(param),
		contentType : 'application/json',
		dataType : "json",
		success : function(data) {
			successSearchShohinCd(data, titleDisplayAreaId, titleHiddenId);
		},
		error : function(XMLHttpRequest, textStatus, errorThrown) {
			errorSearchShohinCd(XMLHttpRequest, textStatus, errorThrown);
		}
	});

}

/**
 * Ajax通信に成功時の処理
 * 
 * @param data
 *            受け取った値
 * @param titleDisplayAreaId
 *            タイトルを表示する場所
 * @param titleHiddenId
 *            タイトル称を保持するhidden
 * @returns
 */
function successSearchShohinCd(data, titleDisplayAreaId, titleHiddenId) {

	const list = data["data"];
	if (list.length == 0) {
		console.log("listのサイズがゼロ");
		return;
	}

	const meisai = list[0];

	$("#" + titleDisplayAreaId).html(meisai["title"]);
	$("#" + titleHiddenId).val(meisai["title"]);

}

/**
 * Ajax通信失敗時処理
 * 
 * @param XMLHttpRequest
 * @param textStatus
 * @param errorThrown
 * @returns
 */
function errorSearchShohinCd(XMLHttpRequest, textStatus, errorThrown) {
	console.log("error:" + XMLHttpRequest);
	console.log("status:" + textStatus);
	console.log("errorThrown:" + errorThrown);

}